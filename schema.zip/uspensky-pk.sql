-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 30 2014 г., 17:36
-- Версия сервера: 5.5.35
-- Версия PHP: 5.3.10-1ubuntu3.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `uspensky-pk`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalogs`
--

DROP TABLE IF EXISTS `catalogs`;
CREATE TABLE IF NOT EXISTS `catalogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `fields` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_parent_id` int(10) unsigned DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `categories_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories_group`
--

DROP TABLE IF EXISTS `categories_group`;
CREATE TABLE IF NOT EXISTS `categories_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `category_product`
--

DROP TABLE IF EXISTS `category_product`;
CREATE TABLE IF NOT EXISTS `category_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_product_category_id_index` (`category_id`),
  KEY `category_product_product_id_index` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'user', 'Пользователи', 'intranet', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'moderator', 'Модераторы', 'moderator', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `group_role`
--

DROP TABLE IF EXISTS `group_role`;
CREATE TABLE IF NOT EXISTS `group_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_role_group_id_index` (`group_id`),
  KEY `group_role_role_id_index` (`role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `group_role`
--

INSERT INTO `group_role` (`id`, `group_id`, `role_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 2, 6),
(13, 2, 8),
(14, 3, 3),
(15, 3, 1),
(16, 3, 2),
(17, 3, 6),
(18, 3, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `group_user`
--

DROP TABLE IF EXISTS `group_user`;
CREATE TABLE IF NOT EXISTS `group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_user_group_id_index` (`group_id`),
  KEY `group_user_user_id_index` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `group_user`
--

INSERT INTO `group_user` (`id`, `group_id`, `user_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `paths` text COLLATE utf8_unicode_ci,
  `attributes` text COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `images_module_id_index` (`module_id`),
  KEY `images_item_id_index` (`item_id`),
  KEY `images_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `default`, `created_at`, `updated_at`) VALUES
(1, 'ru', 'Русский', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_19_104802_create_users_table', 1),
('2014_01_19_104821_create_groups_table', 1),
('2014_01_19_104830_pivot_group_user_table', 1),
('2014_01_19_104934_create_roles_table', 1),
('2014_01_19_104954_pivot_group_role_table', 1),
('2014_01_19_105008_create_pages_table', 1),
('2014_02_08_123907_create_languages_table', 1),
('2014_02_10_125947_create_galleries_table', 1),
('2014_02_10_130103_create_photos_table', 1),
('2014_02_17_105422_create_settings_table', 1),
('2014_02_18_133757_create_news_table', 1),
('2014_02_20_094843_create_templates_table', 1),
('2014_03_03_201446_create_modules_table', 1),
('2014_04_08_142125_create_session_table', 1),
('2014_04_10_085237_create_permissions_table', 1),
('2014_04_10_090423_pivot_user_module_permission', 1),
('2014_04_14_101731_create_articles_table', 1),
('2014_04_18_103249_create_catalogs_table', 1),
('2014_04_21_133950_create_categories_group_table', 1),
('2014_04_22_070606_create_categories_table', 1),
('2014_04_22_143526_create_products_table', 1),
('2014_04_23_103825_create_images_table', 1),
('2014_04_25_101239_create_category_product_table', 1),
('2014_04_25_112828_create_manufacturers_table', 1),
('2014_04_28_115029_create_products_attributes_group_table', 1),
('2014_04_28_115149_create_products_attributes_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `permissions` varchar(255) COLLATE utf8_unicode_ci DEFAULT '[]',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `url`, `on`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'seo', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:44:57'),
(2, 'news', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'articles', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'pages', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'catalogs', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'users', 0, '[1,2,3]', '2014-04-29 09:43:10', '2014-04-29 09:45:09'),
(7, 'downloads', 1, '[3,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:11'),
(8, 'statistic', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'galleries', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(10, 'languages', 0, '[1,2,3,4]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(11, 'settings', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(12, 'templates', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `module_permissions`
--

DROP TABLE IF EXISTS `module_permissions`;
CREATE TABLE IF NOT EXISTS `module_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `module_id` int(10) unsigned DEFAULT NULL,
  `permission_id` int(10) unsigned DEFAULT NULL,
  `value` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `module_permissions_user_id_index` (`user_id`),
  KEY `module_permissions_module_id_index` (`module_id`),
  KEY `module_permissions_permission_id_index` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `sort`, `template`, `title`, `language`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `publication`, `created_at`, `updated_at`) VALUES
(3, 5, 'news', 'Регистрация компании-инициатора проекта', 'ru', '', '<p>\n	26.12.2012 года состоялась государственная регистрация ООО «Успенский перерабатывающий комплекс». Эта дата послужила началом реализации идеи о создании в Ростовской области универсального комплекса по переработке нестандартных темных нефтепродуктов. Данная дата является исторической для компании и олицетворяет первый шаг на пути к реализации проекта.\n</p>', 'oficialnyiy-start-proekta', 'Официальный старт проекта', '', '', '', 1, '2012-12-26 11:20:47', '2014-04-30 16:16:05'),
(5, 6, 'news', 'Официальный старт реализации проекта', 'ru', '', '<p>\n	Данная дата является началом серьезной работы по реализации, продвижению и позиционированию инвестиционного проекта  ООО «УПК», с целью привлечения финансирования. На данном этапе были определены основные направления и действия, необходимые для успешной реализации проекта.\n</p>', 'oficialnyiy-start-realizacii-proekta', 'Официальный старт реализации проекта', '', '', '', 1, '2013-09-01 16:16:40', '2014-04-30 16:16:40'),
(6, 7, 'news', 'Заключение договора на приобретение земельных участков под строительство комплекса.', 'ru', '', '<p>\n	23.09.2013 г. Состоялось подписание договора купли-продажи земельных участков  с  уже существующей инфраструктурой и железно-дорожной ветки, протяженностью 1,82 км. Земельные участки расположены вблизи с. Авило-Успенка Матвеево-Курганского района Ростовской области. Приобретение площадки под строительство послужило толчком к началу работ по сбору исходно-разрешительной документации на строительство комплекса, а также работ по подготовке предпроектной документации.\n</p>', 'zaklyuchenie-dogovora-na-priobretenie-zemelnyh-uchastkov-pod-stroitelstvo-kompleksa', 'Заключение договора на приобретение земельных участков под строительство комплекса.', '', '', '', 1, '2013-09-23 16:17:02', '2014-04-30 16:17:02'),
(7, 8, 'news', 'Участие и позиционирование проекта на XII Международном Инвестиционном форуме  «Сочи-2013»', 'ru', '', '<p>\n	С 26.09.2013 г. по 29.09.2013 г. ООО «УПК» посетило Международный Инвестиционный форум «Сочи-2013». На форуме руководству компании удалось представить свой проект, а также познакомиться лично со многими руководителями различных ведомств Ростовской области,  несколькими членами Совета Федерации, с депутатами Государственной думы, с представителями федерального бизнеса и руководителями ряда инвестиционных компаний.\n</p>', 'uchastie-i-pozicionirovanie-proekta-na-xii-mejdunarodnom-investicionnom-forume-sochi-2013', 'Участие и позиционирование проекта на XII Международном Инвестиционном форуме  «Сочи-2013»', '', '', '', 1, '2013-09-26 16:17:37', '2014-04-30 16:17:37'),
(8, 9, 'news', 'Согласование строительства комплекса в Администрации Матвеево-Курганского района Ростовской области', 'ru', '', '<p>\n	Администрацией Матвеево-Курганского района Ростовской области 08.10.2013 г. официально было согласовано строительство Успенского перерабатывающего комплекса. Как было отмечено Главой Матвеево-Курганского района  Рудковским А.А. – строительство комплекса будет способствовать дальнейшему экономическому  развитию района, созданию новых рабочих мест, укреплению налогооблагаемой базы. Кроме того было гарантировано содействие в реализации вопросов, связанных с реализацией проекта.\n</p>', 'soglasovanie-stroitelstva-kompleksa-v-administracii-matveevo-kurganskogo-raiyona-rostovskoiy-oblasti', 'Согласование строительства комплекса в Администрации Матвеево-Курганского района Ростовской области', '', '', '', 1, '2013-10-08 16:17:59', '2014-04-30 16:17:59'),
(9, 10, 'news', 'Включение проекта в реестр инвестиционных проектов Ростовской области', 'ru', '', '<p>\n	07.11.2013 г. состоялось совещание рабочей группы по вопросам инвестиционной деятельности, внедрению инновационной продукции инновационных разработок Министерства промышленности и энергетики Ростовской области, проводимом совместно с Департаментом инвестиционного развития Ростовской области. В ходе совещания, был рассмотрен инвестиционный проект ООО «УПК», который по результатам совещания был официально включен в реестр инвестиционных проектов  Ростовской области и взят под контроль профильным Министерством, что в свою очередь что позволит в дальнейшем воспользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы по налогообложению и компенсации по затратам на присоединение объекта к инженерным сетям газо-, электро- и водоснабжения.\n</p>', 'vklyuchenie-proekta-v-reestr-investicionnyh-proektov-rostovskoiy-oblasti', 'Включение проекта в реестр инвестиционных проектов Ростовской области', '', '', '', 1, '2013-11-07 16:18:17', '2014-04-30 16:18:17'),
(10, 11, 'news', 'Подписание договора на разработку предпроектных предложений', 'ru', '', '<p>\n	22.01.2014 года состоялось подписание договора и с ООО «НОУ ПРОМ» г. Краснодар о выполнении комплекса работ по предпроектной подготовке.\n</p>', 'podpisanie-dogovora-na-razrabotku-predproektnyh-predlojeniiy', 'Подписание договора на разработку предпроектных предложений', '', '', '', 1, '2014-01-22 16:18:34', '2014-04-30 16:18:34'),
(11, 12, 'news', 'Приобретение дополнительных земельных участков', 'ru', '', '<p>\n	Подписан договор купли-продажи земельных участков площадью 14 Га, примыкающих к ранее приобретенным участкам.\n</p>', 'priobretenie-dopolnitelnyh-zemelnyh-uchastkov', 'Приобретение дополнительных земельных участков', '', '', '', 1, '2014-01-24 16:18:52', '2014-04-30 16:18:52'),
(12, 13, 'news', 'Приобретение дополнительных земельных участков', 'ru', '', '<p>\n	Подписан договор купли-продажи земельных участков площадью 12 Га, примыкающих к ранее приобретенным участкам.  Подписанием данного договора площадь площадки под размещение Успенского перерабатывающего комплекса составила 40 Га.\n</p>', 'priobretenie-dopolnitelnyh-zemelnyh-uchastkov', 'Приобретение дополнительных земельных участков', '', '', '', 1, '2014-02-07 16:19:07', '2014-04-30 16:19:07'),
(13, 14, 'news', 'Проведение переговоров со Швейцарской инвестиционной компанией IFM AG', 'ru', '', '<p>\n	10.02.2014 года состоялись переговоры со Швейцарской инвестиционной компанией IFM AG по вопросам взаимовыгодного сотрудничества в сфере финансирования проекта «Успенский перерабатывающий комплекс».\n</p>', 'provedenie-peregovorov-so-shveiycarskoiy-investicionnoiy-kompanieiy-ifm-ag', 'Проведение переговоров со Швейцарской инвестиционной компанией IFM AG', '', '', '', 1, '2014-02-10 16:19:25', '2014-04-30 16:19:25'),
(14, 15, 'news', 'Участие в Международном инвестиционном форуме MIPIM 2014', 'ru', '', '<p>\n	С 11.03.2014 года по 14.03.2014 года руководство компании приняло участие в Международном инвестиционном форуме MIPIM 2014. В ходе данного мероприятия удалось презентовать проект компании на самом высоком международном уровне, познакомиться с иностранными и российскими инвесторами<strong>.</strong>\n</p>', 'uchastie-v-mejdunarodnom-investicionnom-forume-mipim-2014', 'Участие в Международном инвестиционном форуме MIPIM 2014', '', '', '', 1, '2014-03-11 16:19:48', '2014-04-30 16:19:48'),
(15, 16, 'news', 'Участие в программе повышения квалификации  руководителей  mini MBA', 'ru', '', '<p>\n	Руководство компании приняло участие в программе повышения квалификации  руководителей  mini MBA.\n</p>', 'uchastie-v-programme-povysheniya-kvalifikacii-rukovoditeleiy-mini-mba', 'Участие в программе повышения квалификации  руководителей  mini MBA', '', '', '', 1, '2014-03-27 16:21:01', '2014-04-30 16:21:01'),
(16, 18, 'news', 'Руководство компании завершило обучение в программе mini MBA', 'ru', '', '<p>\n	 Руководство компании завершило обучение в программе повышения квалификации  руководителей  miniMBA по блоку «Управление».\n</p>', 'rukovodstvo-kompanii-zavershilo-obuchenie-v-programme-minimba', 'Руководство компании завершило обучение в программе miniMBA', '', '', '', 1, '2014-04-28 16:21:55', '2014-04-30 17:10:46');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `in_menu`, `sort_menu`, `template`, `language`, `name`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `content`, `publication`, `start_page`, `created_at`, `updated_at`) VALUES
(1, 0, 40, 'index-page', 'ru', 'Главная', '', 'Главная', '', '', '', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	          Инвестиции в уникальные технологии\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			 [news path="news-on-main-page" limit="1"]\n		</div>\n		<a href="/news" class="block-hover">\n		<div class="block-hv-text">\n			          Все новости УПК\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				          Инвесторам\n			</div>\n			<div class="block-text">\n				                                   Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс».\n			</div>\n		</div>\n		<a href="/investors" class="block-hover">\n		<div class="block-hv-text">\n			          Подробнее\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				          Контакты\n			</div>\n			<div class="block-text">\n				                                   г. Ростов-на-Дону,<br>\n				           ул. Текучева, 162, офис 302<br>\n				           тел. +7 (863) 280-66-56, <br>\n				           E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		<a href="/contacts" class="block-hover">\n		<div class="block-hv-text">\n			          На карте\n		</div>\n		</a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n</section>', 1, 1, '2014-04-29 09:52:33', '2014-04-30 14:47:52'),
(2, 0, 33, 'default', 'ru', 'О компании', 'about', 'О компании', '', '', '', '<main class="container about">\n<h1>О компании</h1>\n<!--<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>-->\n<div class="content">\n	<div class="desc">\n		                         В России очень мало компаний, которые официально занимаются утилизацией                     и переработкой «темных нестандартных нефтепродуктов». Счет производств,                     которые профильно занимаются переработкой подобных нефтепродуктов                     и имеют лицензию на переработку идет на еденицы по всей стране.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                         Специалисты компании — инициатора проекта уже более 3-х лет занимаются исследованиями рынка «темных нестандартных нефтепродуктов», практической реализацией мелких проектов по переработке обводненного мазута.<br>\n			     В процессе накопленного практического опыта, глубокий анализ показал, что на Юге России нет ни одного официального производства по переработке вышеуказанных продуктов несмотря на то, что в России очень много предприятий, которые имеют потребность в заключении долгосрочных контрактов на утилизацию и переработку получаемых ими «темных нестандартных нефтепродуктов», но в силу отсутствия таковых, вынуждены утилизировать НТН, используя различные незаконные схемы сбыта, что влечет за собой огромные риски и снижение рентабельности.<br>\n			     Благодаря такому практическому опыту родилась идея создания <strong>универсального комплекса</strong> по переработке нестандартных темных нефтепродуктов.<br>\n		</div>\n	</div>\n	<h2>                     История                 </h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>                             Зарегистрирована компания                         </h3>\n		<div class="hist-desc">\n			                                  26.12.2012 в целях реализации возникшей идеи была зарегистрирована компания Общество с ограниченной ответственностью «Успенский перерабатывающий комплекс», которая в настоящий момент является инициатором проекта по строительству перерабатывающего комплекса.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="theme/img/icons/rocket.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Официальный старт проекта                         </h3>\n		<div class="hist-desc">\n			                                 В сентябре 2013 года проект официально стартовал, и начались первые шаги по реализации данного проекта.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Включение в реестр инвестиционных проектов Ростовской области                         </h3>\n		<div class="hist-desc">\n			                                 7 Ноября 2013 года в Министерстве промышленности и энергетики Ростовской области состоялось совещание рабочей группы по вопросам развития инвестиционной деятельности. По результатам указанного совещания инвестиционный проект ООО «Успенский перерабатывающий комплекс» был успешно включен в реестр инвестиционных проектов Ростовской области, что позволяет в дальнейшем пользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>                             Предпроектные работы                         </h3>\n		<div class="hist-desc">\n			                                 В настоящее время проект успешно находится в стадии реализации на этапе предпроектных работ и большими шагами движется к заданной цели.\n		</div>\n	</div>\n	</li>\n</ul>\n </main>', 1, 0, '2014-04-29 10:39:11', '2014-04-30 13:12:57'),
(3, 0, 45, 'default', 'ru', 'Пресс-центр', 'news', 'Пресс-центр', '', '', '', '<main class="container news">\n<h1>Новости</h1>\n<div class="press-about-us">\n	<div class="press-btn">\n		 Пресса о нас\n	</div>\n	<ul class="articles list-unstyled">\n		<li class="art-item" data-date="октябрь 2013"><a href="/uploads/1398875286_mwzgubEi2WgFTNvoL2eqJyRDc7f9IiDhWYRBhIyd.pdf" target="_blank">Реальный бизнес</a></li>\n		<li class="art-item" data-date="апрель 2014"><a href="/uploads/1398875285_V19bfWwYMUqalYV0aC9BgEWOjg0YiTIaFgQnSTVw.JPG" target="_blank">Реальный бизнес</a></li>\n	</ul>\n</div>\n     [news limit="10"] </main>', 1, 0, '2014-04-29 10:41:30', '2014-04-30 16:43:10'),
(4, 0, 34, 'default', 'ru', 'Услуги', 'services', 'Услуги', '', '', '', '<main class="container services">\n<h1>Услуги</h1>\n<div class="content">\n	<div class="desc">\n		                       Настоящий проект предполагает производство следующих                     продуктов и оказание услуг\n	</div>\n	<div>\n		<div class="col-50">\n			<h2>Производство</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Битум</li>\n				<li>Бензин прямогонный</li>\n				<li>Судовое маловязкое топливо</li>\n				<li>Мазут</li>\n				<li>Керосин</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Услуги</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Перевалка газа</li>\n				<li>Перевалка битума</li>\n				<li>Перевалка мазута</li>\n				<li>Обезвоживание мазута</li>\n				<li>Фильтрация мазута</li>\n				<li>Понижение вязкости и застывания мазута</li>\n				<li>Переработка нефти</li>\n			</ul>\n		</div>\n	</div>\n</div>\n </main>', 1, 0, '2014-04-29 10:44:31', '2014-04-30 13:15:32'),
(6, 0, 19, 'default', 'ru', 'Карьера', 'career', 'Карьера', '', '', '', '<main class="container services">\n            <h1>\n                Карьера\n            </h1>\n            <div class="content">\n                <div class="desc">\n                    Уважаемые соискатели!\n                </div>\n                <div class="more-desc">\n                    <div class="more-desc-part">\n                    <p>Проведение работ по отбору кандидатов на замещение вакантных должностей в ООО «УПК» будет проводиться в 3 квартале 2014 года.\nЗа информацией о списках рабочих мест и количестве необходимых сотрудников, следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.</p>\n                    </div>\n                </div>\n                </div>\n            </div>\n            \n        </main>', 1, 0, '2014-04-29 11:04:34', '2014-04-29 11:04:34'),
(5, 0, 46, 'investors', 'ru', 'Инвесторам', 'investors', 'Инвесторам', '', '', '', '<div class="desc">\n	                      Предлагаем Вам принять участие в реализации инвестиционного проекта                     «Успенский перерабатывающий комплекс». Целью создания комплекса является                     организация многопрофильного производства по переработке нефти и нестандартных                     темных нефтепродуктов, а также оказание большого спектра услуг в нефтяной сфере.\n</div>\n<div class="more-desc">\n	<div class="more-desc-part">\n		                          Для организации финансирования  и управления размещением сертификатов                         участия на рынке капитала наша компания заключила контракт со                         швейцарской компанией <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a>.                         По возникшим вопросам, касающимся размещения сертификатов участия, просим                         обращаться в данную компанию.\n	</div>\n	<div class="more-desc-part">\n		                          Для реализации проекта ООО «Успенский перерабатывающий комплекс»                         выпускает привилегированные сертификаты участия. Принятие участия                         представляет собой приобретение вышеуказанных сертификатов. Подробные                         условия изложены в эмиссионном проспекте. Для ознакомления                         введите логин и пароль.\n	</div>\n	<div class="more-desc-part">\n		                          Чтобы получить доступ к загрузке эмисионного проспекта,<br>\n		 <a href="/request-to-access">отправьте запрос.</a>\n	</div>\n</div>', 1, 0, '2014-04-29 10:45:30', '2014-04-30 16:50:19'),
(10, 0, 32, 'default', 'ru', 'Интранет', 'intranet', 'Интранет', '', '', '', '<main class="container investors">\n<h1>                 Эммисионный проспект             </h1>\n<div class="content">\n	<div class="desc">\n		                     Для ознакомления с эмиссионным проспектом, пожалуйста, скачайте файл по ссылке.\n	</div>\n	<div class="intranet-desc">\n		<a href="#" class="link-pdf">                         Скачать документ                     </a>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-30 04:07:23', '2014-04-30 12:27:59'),
(7, 0, 20, 'default', 'ru', 'Тендеры', 'tenders', 'Тендеры', '', '', '', '<main class="container services tenders">\n<h1>                 Тендеры             </h1>\n<div class="content">\n	<div class="desc">\n		                     Размещение информации  о работах, товарах и услугах, а также предварительному отбору поставщиков  товаров, услуг и подрядчиков, ООО «Успенский перерабатывающий комплекс» планирует  в конце 2 квартала 2014 года.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                     За информацией следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.<br>\n		</div>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-29 11:07:18', '2014-04-29 11:07:18'),
(8, 0, 43, 'contacts', 'ru', 'Контакты', 'contacts', 'Контакты', '', '', '', '<div class="more-desc">\n	<div class="more-desc-part">\n	ООО «Успенский перерабатывающий комплекс»<br>\n        Генеральный директор: Бабилоев Алексей Николаевич<br>\n        Адрес: 344013,  Россия,  Ростовская область,<br>\n        г. Ростов-на-Дону, ул. Текучева, 162, офис 302\n	</div>\n</div>\n <address>\n<div class="s-phones col-40">\n	 <a href="tel:+78632806656">+7 863 280 66 56</a>\n         <a href="tel:+78632345608">+7 863 234 56 08</a>\n         <a href="tel:+79282797309">+7 928 279 73 09</a>\n</div>\n<div class="mails col-40">\n	 <a href="mailto:rdo2009@mail.ru">rdo2009@mail.ru</a>\n</div>\n </address>', 1, 0, '2014-04-29 11:08:20', '2014-04-30 16:18:43'),
(9, 0, 38, 'default', 'ru', 'Карта сайта', 'sitemap', 'Карта сайта', '', '', '', '<main class="container about">\n<h1>                 Карта сайта             </h1>\n<ul class="sitemap">\n	<li class="sitemap-item"><a href="/">Главная</a></li>\n	<li class="sitemap-item"><a href="/about">О компании</a></li>\n	<li class="sitemap-item"><a href="/news">Пресс-центр</a></li>\n	<li class="sitemap-item"><a href="/services">Услуги</a></li>\n	<li class="sitemap-item"><a href="/career">Карьера</a></li>\n	<li class="sitemap-item"><a href="/investors">Инвесторам</a></li>\n	<li class="sitemap-item"><a href="/tenders">Тендеры</a></li>\n	<li class="sitemap-item"><a href="/contacts">Контакты</a></li>\n	<li class="sitemap-item"><a href="/request-to-access">Заявка на доступ к документам</a></li>\n</ul>\n</main>', 1, 0, '2014-04-29 11:09:32', '2014-04-30 14:39:02'),
(11, 0, 31, 'request-for-access-to-documents', 'ru', 'Заявка на доступ к документам', 'request-to-access', 'Заявка на доступ к документам', '', '', '', '<div class="desc">\n	                     Для ознакомления с эмиссионным проспектом, пожалуйста, заполните все поля формы. Мы направим вам логин и пароль на указанный адрес электронной почты.\n</div>', 1, 0, '2014-04-30 11:30:36', '2014-04-30 11:30:36');

-- --------------------------------------------------------

--
-- Структура таблицы `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `desc`, `default`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Создание', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'edit', 'Редактирование', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'delete', 'Удаление', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'publication', 'Публикация', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'download', 'Загрузка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'sort', 'Сортировка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catalog_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_user_id_index` (`user_id`),
  KEY `products_catalog_id_index` (`catalog_id`),
  KEY `products_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes`
--

DROP TABLE IF EXISTS `products_attributes`;
CREATE TABLE IF NOT EXISTS `products_attributes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `product_attribute_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `products_attributes_product_attribute_group_id_index` (`product_attribute_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes_group`
--

DROP TABLE IF EXISTS `products_attributes_group`;
CREATE TABLE IF NOT EXISTS `products_attributes_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'news', 'Управление новостими', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'articles', 'Управление статьями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'pages', 'Управление страницами', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'catalogs', 'Управление каталогами товаров', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'users', 'Управление пользователями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'downloads', 'Управление загрузками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'statistic', 'Управление статистикой', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'galleries', 'Управление галереями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'languages', 'Управление языками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(10, 'settings', 'Управление настройками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(11, 'templates', 'Управление шаблонами', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('f6042d0424d2de50a80b6d3fa9033a944a7ebd07', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNDkwZkNmMVpMUFhSVW1NbDJldFZncTZPRnJsSHhXN25RU3RCOHRYNyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3OTE0NztzOjE6ImMiO2k6MTM5ODg1NDM0MjtzOjE6ImwiO3M6MToiMCI7fX0=', 1398879147),
('29db08cf8ecfbcc5f0504f1028bfaf17f0f10a53', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUY1TTE2V1o1MlNtT3ptTkRvZ2NXVjcxNzcyZTNwcDE4ZzFiUHcwdiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Nzg5OTc7czoxOiJjIjtpOjEzOTg4Nzg5OTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398878997),
('2bb32cb9a276d4c053654bff20031a4612a8f1d9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiamNOc0FYMGRTQWMxV21reERyT25FR0tpS0xHZkRySXlCSTFSVTZYRCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3ODkyODtzOjE6ImMiO2k6MTM5ODg3NjU3NztzOjE6ImwiO3M6MToiMCI7fX0=', 1398878928),
('2fd657cf5e57d7066a96bf30cb12d081deb22714', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTQwVHpmdTh1UUtrOG41TVVRYUN3cHY1a3BkaHV3dzN5bUpNQ1hPMyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3Njk4ODtzOjE6ImMiO2k6MTM5ODg3Njc2MDtzOjE6ImwiO3M6MToiMCI7fX0=', 1398876988),
('31c5bd0b93e7160a98113488f8202a87c26a16dc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTktCVjNuNW0xSzV5UTFpR0ZYdlplM3I5Q0JQYWdvSW9IblE0cXp0SSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3OTI0ODtzOjE6ImMiO2k6MTM5ODg3ODAzMjtzOjE6ImwiO3M6MToiMCI7fX0=', 1398879249),
('bba706bfe03cd2eaca12ce73e8e2908a45cd3b6a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRktVQXlpR2ZhcDQ5QTFJUklUaUpuckJ6b09XY0tUZ2J3b1pmZEJkdiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzgwMzM7czoxOiJjIjtpOjEzOTg4NzgwMzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398878033),
('02834e310918804f45cb33573b0e43f17efb4a0b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0QzaXNtZ2pUMzF1VHExdFR1d3BTSWFTbWJqWlk4UkFGcGJwNDh1ZiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzkwMDA7czoxOiJjIjtpOjEzOTg4NzkwMDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398879000),
('5a6ea779b00675e2d6a84c9f0c69aeb0eae38414', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWRPUWI4RUNxdTVCNXo1NkQ1c0h2VXIxdURmVGhUVlRGUnU4QzhwMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzkwMDM7czoxOiJjIjtpOjEzOTg4NzkwMDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398879003),
('ef6dc5838f179f5c6d4ab08b4627f4231e31aa89', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTnhzUnl2V0paWm1JbDR4b05Hek1uZHZ1Nmp2ckR3ZHJYcHFVRDJuQyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzkwMDM7czoxOiJjIjtpOjEzOTg4NzkwMDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398879003),
('eedab27a97d0f0877100b0641a4e310a2fd1690d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ2lFZVdZTW1yVks2VWtWNk94NnJkSmxXd2EyQkNVTVFtc2xBdXhZUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzkwMzc7czoxOiJjIjtpOjEzOTg4NzkwMzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398879037),
('356a4e6b71936e7e6586cb32d6dec8bdcc756d15', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQnhxck05ZkdrdWkyZVpGWndubU0wVEJXdE03a0NWUzR4TkZmdW1ZbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzkxMzQ7czoxOiJjIjtpOjEzOTg4NzkxMzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398879134),
('1d38abefea24679df98270401123178fb9182c58', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzdjQVdNeDk5VkJxV2p1ZHQ1S0o0OEtFcVFVTVJUcENnYnhFUUViWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NzkxNzM7czoxOiJjIjtpOjEzOTg4NzkxNzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398879173),
('40b530e432ca450eafc85fca421cadab5e968e9f', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZ2txYXRzVmVSVmVhTHZQTDhPYmc4cTQwOEVhaG9zNngyazRMRnJYZiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIxIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3OTAzMTtzOjE6ImMiO2k6MTM5ODg3Mzc5MztzOjE6ImwiO3M6MToiMCI7fX0=', 1398879031),
('d90c9ddfc117896f5024c7d39d70a5945fa041a4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUZJeDZTSUUzYXpPaWxvUFBYV2hERmU3TEY3NlcyU2pWSGMycXFORiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3NTU1MDtzOjE6ImMiO2k6MTM5ODg3NTU0ODtzOjE6ImwiO3M6MToiMCI7fX0=', 1398875551),
('d5f616f49d00edbaed94d6642bb1f16410361d20', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlhXRHJpdXF4UXhJdnZjTmoxa2s4WGtoVDhGb0N6cGxHTjFtR3JMUiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3NjM5ODtzOjE6ImMiO2k6MTM5ODg3NjI1ODtzOjE6ImwiO3M6MToiMCI7fX0=', 1398876398),
('c306afd347d0ab458f20212b9799fb59e7584aa8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTm05eHJ5cEJuOHI5dGpqdE81S095c0hKN2Z1SlBOU29FZ1hhck9ZbyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg3ODgxODtzOjE6ImMiO2k6MTM5ODg2ODk0MztzOjE6ImwiO3M6MToiMCI7fX0=', 1398878818);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `templates`
--

DROP TABLE IF EXISTS `templates`;
CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `static` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `templates`
--

INSERT INTO `templates` (`id`, `name`, `content`, `static`, `created_at`, `updated_at`) VALUES
(1, 'default', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'catalog', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'news', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'articles', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'category', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'product', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'manufacturer', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'index-page', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="row content max-width-class" role="main">\n		@include(''templates.default.sidebar'')\n		<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">\n			@yield(''content'')\n			@if(isset($content))\n				{{ $content }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-29 09:45:45', '2014-04-29 09:45:59'),
(9, 'investors', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container investors">\n		<h1>{{ trans(''interface.PAGES_FOR_INVESTORS'') }}</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			@if(Auth::guest())\n				{{ Form::open(array(''route''=>''signin'',''role''=>''form'',''class''=>''auth-form'',''id''=>''signin-secure-page-form-2'')) }}\n					<div class="form-header">{{ trans(''interface.FORM_SIGNIN_SECURE_2_HEADER'') }}</div>\n					<input type="text" name="login" placeholder="{{ trans(''interface.FORM_INPUT_PLACEHOLDER_LOGIN'') }}">\n					<input type="password" name="password" placeholder="{{ trans(''interface.FORM_INPUT_PLACEHOLDER_PASSWORD'') }}">\n					<button type="submit">{{ trans(''interface.FORM_SIGNIN_SUBMIT'') }}</button>\n				{{ Form::close() }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 06:06:28', '2014-04-30 16:03:45'),
(10, 'contacts', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container services contacts">\n		<h1>Контакты</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:600px;"><div id="gmap_canvas" style="height:400px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(40.7056308,-73.9780035),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(40.7056308, -73.9780035)});infowindow = new google.maps.InfoWindow({content:"<b>УПК</b><br/>ул. Красных зорь, 123а<br/> Россия, Ростовская область, пос. Успенский" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, ''load'', init_map);\n            </script>\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 11:15:17', '2014-04-30 11:19:54'),
(11, 'request-for-access-to-documents', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container investors">\n		<h1>Заявка на доступ к документам</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			<div class="apply-form">\n			{{ Form::open(array(''route''=>''request-to-access'',''role''=>''form'',''id''=>''request-to-access-form'')) }}\n				<table class="apply-table">\n					<tr class="apply-row">\n						<td><label for="name">ФИО контактного лица</label></td>\n						<td><input type="text" name="name" id="name"></input></td>\n					</tr>\n						<tr class="apply-row">\n						<td><label for="organisation">Название организации</label></td>\n						<td><input type="text" name="organisation" id="organisation"></input></td>\n					</tr>\n					<tr class="apply-row">\n						<td><label for="email">Адрес@электронной.почты</label></td>\n						<td><input type="text" name="email" id="email"></input></td>\n					</tr>\n					<tr class="apply-row">\n						<td><label for="phone">Контактный телефон</label></td>\n						<td><input type="text" name="phone" id="phone"></input></td>\n					</tr>\n				</table>\n			<button class="apply-btn">Отправить заявку</button>\n			{{ Form::close() }}\n			</div>\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 11:23:04', '2014-04-30 11:29:35'),
(12, 'news-on-main-page', '@if(isset($news) && $news->count())\n@foreach($news as $new)\n<div class="block-w-logo" data-date="{{ myDateTime::getDayAndMonth($new->created_at) }}"></div>\n<div class="block-title">Новости</div>\n<div class="block-text">{{ Str::limit($new->content,200) }}</div>\n@endforeach\n@endif', 0, '2014-04-30 14:47:11', '2014-04-30 17:09:16');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Администратор', '', 'admin@uspensky-pk.ru', 1, '$2y$10$1hU9pK9AlpiZJzPGyET./.pUqIv2YJzbBTbMG432Tw2t6g3350ehS', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, 'GDFxo5qczOnAEsftdxB6AzCZeGhFaHE4FLS6YBvQa8yfh2h1GG8Z5LDCiXMy', '2014-04-30 05:05:40', '2014-04-30 17:22:06'),
(2, 'Пользователь', '', 'intranet', 1, '$2y$10$3vJkKa6SjZNHYJ/pOjoWMewssEQezo5iA5YjEiuR60GyqKHIq6gO2', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, '04U6o3nEWrwHUEmCdJz37vCe14FHf6WBdmO5s1zfi3X0z7UyDKdYnuQm4NRG', '2014-04-30 05:05:40', '2014-04-30 14:24:52');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
