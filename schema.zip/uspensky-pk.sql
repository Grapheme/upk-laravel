-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 05 2014 г., 08:08
-- Версия сервера: 5.5.35
-- Версия PHP: 5.3.10-1ubuntu3.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `uspensky-pk`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalogs`
--

DROP TABLE IF EXISTS `catalogs`;
CREATE TABLE IF NOT EXISTS `catalogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `fields` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_parent_id` int(10) unsigned DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `categories_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories_group`
--

DROP TABLE IF EXISTS `categories_group`;
CREATE TABLE IF NOT EXISTS `categories_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `category_product`
--

DROP TABLE IF EXISTS `category_product`;
CREATE TABLE IF NOT EXISTS `category_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_product_category_id_index` (`category_id`),
  KEY `category_product_product_id_index` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'user', 'Пользователи', 'intranet', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'moderator', 'Модераторы', 'moderator', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `group_role`
--

DROP TABLE IF EXISTS `group_role`;
CREATE TABLE IF NOT EXISTS `group_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_role_group_id_index` (`group_id`),
  KEY `group_role_role_id_index` (`role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `group_role`
--

INSERT INTO `group_role` (`id`, `group_id`, `role_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 2, 6),
(13, 2, 8),
(14, 3, 3),
(15, 3, 1),
(16, 3, 2),
(17, 3, 6),
(18, 3, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `group_user`
--

DROP TABLE IF EXISTS `group_user`;
CREATE TABLE IF NOT EXISTS `group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_user_group_id_index` (`group_id`),
  KEY `group_user_user_id_index` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `group_user`
--

INSERT INTO `group_user` (`id`, `group_id`, `user_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages`
--

DROP TABLE IF EXISTS `i18n_pages`;
CREATE TABLE IF NOT EXISTS `i18n_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `i18n_pages`
--

INSERT INTO `i18n_pages` (`id`, `slug`, `template`, `publication`, `start_page`, `in_menu`, `sort_menu`, `created_at`, `updated_at`) VALUES
(4, '', 'index-page', 1, 1, 0, 47, '2014-04-30 10:10:42', '2014-04-30 20:49:09'),
(5, 'about', 'default', 1, 0, 0, 47, '2014-04-30 12:34:23', '2014-04-30 21:07:42'),
(6, 'news', 'default', 1, 0, 0, 47, '2014-04-30 17:41:17', '2014-04-30 22:04:35'),
(7, 'services', 'default', 1, 0, 0, 47, '2014-04-30 17:42:14', '2014-04-30 21:06:13'),
(8, 'career', 'default', 1, 0, 0, 47, '2014-04-30 17:44:19', '2014-05-05 07:10:51'),
(9, 'investors', 'investors', 1, 0, 0, 47, '2014-04-30 17:45:36', '2014-04-30 21:48:24'),
(10, 'intranet', 'default', 1, 0, 0, 47, '2014-04-30 17:46:23', '2014-04-30 21:29:06'),
(11, 'tenders', 'default', 1, 0, 0, 47, '2014-04-30 17:48:36', '2014-04-30 21:33:24'),
(12, 'contacts', 'contacts', 1, 0, 0, 47, '2014-04-30 17:49:09', '2014-04-30 21:37:02'),
(13, 'sitemap', 'default', 1, 0, 0, 47, '2014-04-30 17:49:56', '2014-04-30 21:42:46'),
(14, 'request-to-access', 'request-for-access-to-documents', 1, 0, 0, 47, '2014-04-30 17:51:14', '2014-04-30 21:46:03');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages_meta`
--

DROP TABLE IF EXISTS `i18n_pages_meta`;
CREATE TABLE IF NOT EXISTS `i18n_pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_meta_page_id_index` (`page_id`),
  KEY `i18n_pages_meta_language_index` (`language`),
  KEY `i18n_pages_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=43 ;

--
-- Дамп данных таблицы `i18n_pages_meta`
--

INSERT INTO `i18n_pages_meta` (`id`, `page_id`, `language`, `name`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(10, 4, 'en', 'Uspenskiy Pocessing Complex', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	                       Uspenskiy Pocessing Complex\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo" data-date="28/04">\n			</div>\n			<div class="block-title">\n				        News\n			</div>\n			<div class="block-text">\n				          Top management of the company completed training on the professional development programme for top managers miniMBA, Management.<br>\n			</div>\n		</div>\n		 <a href="/en/news" class="block-hover">\n		<div class="block-hv-text">\n			                     All news\n		</div>\n		 </a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				                       Investors\n			</div>\n			<div class="block-text">\n				          We invite you to participate in implementation of investment project Uspenskiy Processing Complex.\n			</div>\n		</div>\n		 <a href="/en/investors" class="block-hover">\n		<div class="block-hv-text">\n			                        More info\n		</div>\n		 </a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				                       Contacts\n			</div>\n			<div class="block-text">\n				                        office 302, 162 Tekuchev street, <br>\n				                        Rostov-on-Don, Russia<br>\n				                        tel. +7 (863) 280-66-56, <br>\n				                        E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		 <a href="/en/contacts" class="block-hover">\n		<div class="block-hv-text">\n			                       View map\n		</div>\n		 </a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n</section>', '', 'Uspenskiy Pocessing Complex', 'Uspenskiy Pocessing Complex', 'Uspenskiy Pocessing Complex', '', '2014-04-30 10:10:42', '2014-04-30 20:49:09'),
(11, 4, 'ru', 'Успенский перерабатывающий комплекс', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	                   Инвестиции в уникальные технологии\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			          [news path="news-on-main-page" limit="1"]\n		</div>\n		 <a href="/news" class="block-hover">\n		<div class="block-hv-text">\n			                   Все новости УПК\n		</div>\n		 </a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				                   Инвесторам\n			</div>\n			<div class="block-text">\n				                                            Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс».\n			</div>\n		</div>\n		 <a href="/investors" class="block-hover">\n		<div class="block-hv-text">\n			                   Подробнее\n		</div>\n		 </a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				                   Контакты\n			</div>\n			<div class="block-text">\n				                                            г. Ростов-на-Дону,<br>\n				                    ул. Текучева, 162, офис 302<br>\n				                    тел. +7 (863) 280-66-56, <br>\n				                    E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		 <a href="/contacts" class="block-hover">\n		<div class="block-hv-text">\n			                   На карте\n		</div>\n		 </a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n </section>', '', 'Успенский перерабатывающий комплекс', 'Успенский перерабатывающий комплекс', 'Успенский перерабатывающий комплекс', '', '2014-04-30 10:10:42', '2014-04-30 20:49:09'),
(12, 4, 'de', 'Uspensker Verarbeitungskomplex', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	                        Uspensker Verarbeitungskomplex\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo" data-date="28/04">\n			</div>\n			<div class="block-title">\n				         Nachrichten\n			</div>\n			<div class="block-text">\n				           Die Geschäftsführung hat die Ausbildung im Program der Leiterhöherqualifizierung miniMBA im Block "Administration" abgeschlossen<br>\n			</div>\n		</div>\n		<a href="/de/news" class="block-hover">\n		<div class="block-hv-text">\n			                      Mehr\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				                        Investors\n			</div>\n			<div class="block-text">\n				           Wir laden Sie zur Teilnahme an der Realisierung des Investitionsprojektes „Uspensker Erdölraffinerie“ ein.\n			</div>\n		</div>\n		<a href="/de/investors" class="block-hover">\n		<div class="block-hv-text">\n			                         Mehr\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				                        Kontakt\n			</div>\n			<div class="block-text">\n				                         162 Tekuchev Strasse,<br>\n				                         Rostov-on-Don, Russia<br>\n				                         tel. +7 (863) 280-66-56, <br>\n				                         E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		<a href="/de/contacts" class="block-hover">\n		<div class="block-hv-text">\n			                        Mehr\n		</div>\n		</a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n </section>', '', 'Uspensker Verarbeitungskomplex', 'Uspensker Verarbeitungskomplex', 'Uspensker Verarbeitungskomplex', '', '2014-04-30 10:10:42', '2014-04-30 20:49:09'),
(13, 5, 'en', 'About us', '<main class="container about">\n<h1>About us</h1>\n<!--<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>-->\n<div class="content">\n	<div class="desc">\n		      In Russia there are very few companies that are officially engaged in disposal and processing of dark unconventional oil products.  In the whole country, the plants that specialize in processing of such oil products and that are licensed for processing and disposal can be counted on the fingers of one hand.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			  Specialists of the company – initiator of the project have investigated the market of "dark unconventional oil", practically implemented small projects on fuel oil emulsion processing for more than 3 years. In the process of the accumulated practical experience, a deep analysis has shown that in the South Russia there is not a single official plant for processing of the above-mentioned products despite the fact that in Russia there are very many enterprises that require long-term contracts for disposal  and processing of "dark unconventional oil products",  but for the reason of their absence these enterprises have to dispose DUO using different illegal marketing schemes, which entails enormous risks and reduced profitability. Thanks to such practical experience, an idea of creating a universal dark unconventional oil products processing complex appeared.\n		</div>\n	</div>\n	<h2>History</h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>Limited Liability Company Uspenskiy Processing Complex  was registered</h3>\n		<div class="hist-desc">\n			      On 26.12.2012, in order to implement the appeared idea Limited Liability Company Uspenskiy Processing Complex  was registered, which at present is the initiator of the project of constructing the processing complex.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="/theme/img/icons/rocket.png"><a href="#">2013</a>\n		</div>\n		<h3>The project officially commenced</h3>\n		<div class="hist-desc">\n			     In September 2013, the project officially commenced, and the first steps on implementation of the present project started.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>Investment project Uspenskiy Processing Complex was successfully registered in the Register of Investment Projects of Rostov region</h3>\n		<div class="hist-desc">\n			     On November 7, 2013, in the Ministry of Industry and Energy of Rostov region a meeting of the work group devoted to the matters of investment activity, was held. By results of the above-mentioned meeting, investment project  Uspenskiy Processing Complex was successfully registered in the Register of Investment Projects of Rostov region, which  will allow to use the system of public private partnership in the future, that provides for  extensive benefits.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>Present</h3>\n		<div class="hist-desc">\n			     At present the project is being successfully implemented at the stage of pre-project works and it   moves towards the goal with a sure step.\n		</div>\n	</div>\n	</li>\n</ul>\n </main>', 'about-us', 'About us', '', '', '', '2014-04-30 12:34:23', '2014-04-30 21:07:42'),
(14, 5, 'ru', 'О компании', '<main class="container about">\n<h1>О компании</h1>\n<!--<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>-->\n<div class="content">\n	<div class="desc">\n		                                 В России очень мало компаний, которые официально занимаются утилизацией                     и переработкой «темных нестандартных нефтепродуктов». Счет производств,                     которые профильно занимаются переработкой подобных нефтепродуктов                     и имеют лицензию на переработку идет на еденицы по всей стране.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                                 Специалисты компании — инициатора проекта уже более 3-х лет занимаются исследованиями рынка «темных нестандартных нефтепродуктов», практической реализацией мелких проектов по переработке обводненного мазута.<br>\n			             В процессе накопленного практического опыта, глубокий анализ показал, что на Юге России нет ни одного официального производства по переработке вышеуказанных продуктов несмотря на то, что в России очень много предприятий, которые имеют потребность в заключении долгосрочных контрактов на утилизацию и переработку получаемых ими «темных нестандартных нефтепродуктов», но в силу отсутствия таковых, вынуждены утилизировать НТН, используя различные незаконные схемы сбыта, что влечет за собой огромные риски и снижение рентабельности.<br>\n			             Благодаря такому практическому опыту родилась идея создания <strong>универсального комплекса</strong> по переработке нестандартных темных нефтепродуктов.<br>\n		</div>\n	</div>\n	<h2>                     История                 </h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>                             Зарегистрирована компания                         </h3>\n		<div class="hist-desc">\n			                                          26.12.2012 в целях реализации возникшей идеи была зарегистрирована компания Общество с ограниченной ответственностью «Успенский перерабатывающий комплекс», которая в настоящий момент является инициатором проекта по строительству перерабатывающего комплекса.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="/theme/img/icons/rocket.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Официальный старт проекта                         </h3>\n		<div class="hist-desc">\n			                                         В сентябре 2013 года проект официально стартовал, и начались первые шаги по реализации данного проекта.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Включение в реестр инвестиционных проектов Ростовской области                         </h3>\n		<div class="hist-desc">\n			                                         7 Ноября 2013 года в Министерстве промышленности и энергетики Ростовской области состоялось совещание рабочей группы по вопросам развития инвестиционной деятельности. По результатам указанного совещания инвестиционный проект ООО «Успенский перерабатывающий комплекс» был успешно включен в реестр инвестиционных проектов Ростовской области, что позволяет в дальнейшем пользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>                             Предпроектные работы                         </h3>\n		<div class="hist-desc">\n			                                         В настоящее время проект успешно находится в стадии реализации на этапе предпроектных работ и большими шагами движется к заданной цели.\n		</div>\n	</div>\n	</li>\n</ul>\n </main>', 'o-kompanii', 'О компании', '', '', '', '2014-04-30 12:34:23', '2014-04-30 21:07:42'),
(15, 5, 'de', 'Über uns', '<main class="container about">\n<h1>Über uns</h1>\n<!--<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>-->\n<div class="content">\n	<div class="desc">\n		  In Russland gibt es nur wenige Unternehmen, die sich auf einem offiziellen Weg mit Verwertung und Verarbeitung von «unkonventionellen dunklen Erdölprodukten» beschäftigen.  Firmen, die zum Schwerpunkt ihrer Tätigkeit Verarbeitung solcher Erdölprodukte erklärten und über entsprechende Lizenzen verfügen, kann man im ganzen Land an den Fingern einer Hand abzählen.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			   Über 3 Jahre führen Spezialisten unserer Firma – des Projektanregers – Marktforschungen auf dem Gebiet unkonventionelle dunkle Erdölprodukte durch und realisieren kleine Projekte zur Verarbeitung von Naßöl. Bei der Sammlung der praktischen Erfahrungen zeigte eine tiefschürfende Analyse, dass in Südrussland keine offizielle Produktion in der. o.e. Branche existiert. Zugleich gibt es in Russland viele Unternehmen, die bereit sind, langfristige Verträge zur Verwertung und Verarbeitung von gewonnenen «unkonventionellen dunklen Erdölprodukten» zu schließen.  Aufgrund des bestehenden Mangels sind sie jedoch gezwungen, diese Produkte auf einem illegalen Wege zu verwerten, was zu großen Risiken und Gewinnverlusten führen kann. Dank dieser praktischen Erfahrung kam uns die Idee zur Gründung  einer universellen Raffinerie für die Verarbeitung von unkonventionellen dunklen Erdölprodukten.\n		</div>\n	</div>\n	<h2>Geschichte</h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>Registrierung der Gesellschaft</h3>\n		<div class="hist-desc">\n			  Für die Realisierung dieser Idee wurde am 26.12.2012 die Gesellschaft mit beschränkter Haftung Uspenskij pererabatywajuschtschij komplex gegründet, welche derzeit als Projektanreger bei der Errichtung der Erdölraffinerie fungiert.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="/theme/img/icons/rocket.png"><a href="#">2013</a>\n		</div>\n		<h3>Der offizielle Projektstart</h3>\n		<div class="hist-desc">\n			   Im September 2013 erfolgte der offizielle Projektstart und wurden erste Schritte zu seiner Realisierung  vorgenommen.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>Investitionsprojekt erfolgreich ins amtliche Register der Investitionsprojekte des Gebiets Rostow am Don aufgenommen</h3>\n		<div class="hist-desc">\n			   Am 07. November 2013 fand im Ministerium für Industrie und Energie des Gebiets Rostow am Don eine Sitzung der Arbeitsgruppe für Angelegenheiten der Investitionstätigkeiten statt. Im Rahmen dieser Sitzung wurde das Investitionsprojekt der OOO „UPK“ erfolgreich ins amtliche Register der Investitionsprojekte des Gebiets Rostow am Don aufgenommen, was in der Zukunft die Beanspruchung des Systems der öffentlich-privaten Partnerschaft mit umfangreichen Begünstigungen ermöglicht.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="/theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>Realisierungsphase</h3>\n		<div class="hist-desc">\n			   Derzeit befindet sich das Projekt in der Realisierungsphase - Vorplanungsarbeiten -  und geht zügig zum vorgegebenen Ziel voran.\n		</div>\n	</div>\n	</li>\n</ul>\n </main>', 'ber-uns', 'Über uns', '', '', '', '2014-04-30 12:34:23', '2014-04-30 21:07:42'),
(16, 6, 'ru', 'Пресс-центр', '<main class="container news">\n<h1>Новости</h1>\n<div class="press-about-us">\n	<div class="press-btn">\n		             Пресса о нас\n	</div>\n	<ul class="articles list-unstyled">\n		<li class="art-item" data-date="октябрь 2013"><a href="/uploads/1398875286_mwzgubEi2WgFTNvoL2eqJyRDc7f9IiDhWYRBhIyd.pdf" target="_blank">Реальный бизнес</a></li>\n		<li class="art-item" data-date="апрель 2014"><a href="/uploads/1398875285_V19bfWwYMUqalYV0aC9BgEWOjg0YiTIaFgQnSTVw.JPG" target="_blank">Реальный бизнес</a></li>\n	</ul>\n</div>\n                 [news limit="10"] </main>', 'press-centr', 'Пресс-центр', '', '', '', '2014-04-30 17:41:17', '2014-04-30 22:04:35'),
(17, 6, 'en', 'Press-center', '<main class="container news">\n<h1>News</h1>\n </main>', 'press-center', 'Press-center', '', '', '', '2014-04-30 17:41:17', '2014-04-30 22:04:35'),
(18, 6, 'de', 'Presse', '<main class="container news">\n<h1>Nachrichten</h1>\n</main>', 'presse', 'Presse', '', '', '', '2014-04-30 17:41:17', '2014-04-30 22:04:35'),
(19, 7, 'ru', 'Услуги', '<main class="container services">\n<h1>Услуги</h1>\n<div class="content">\n	<div class="desc">\n		                           Настоящий проект предполагает производство следующих                     продуктов и оказание услуг\n	</div>\n	<div>\n		<div class="col-50">\n			<h2>Производство</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Битум</li>\n				<li>Бензин прямогонный</li>\n				<li>Судовое маловязкое топливо</li>\n				<li>Мазут</li>\n				<li>Керосин</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Услуги</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Перевалка газа</li>\n				<li>Перевалка битума</li>\n				<li>Перевалка мазута</li>\n				<li>Обезвоживание мазута</li>\n				<li>Фильтрация мазута</li>\n				<li>Понижение вязкости и застывания мазута</li>\n				<li>Переработка нефти</li>\n			</ul>\n		</div>\n	</div>\n</div>\n </main>', 'uslugi', 'Услуги', '', '', '', '2014-04-30 17:42:14', '2014-04-30 21:06:13'),
(20, 7, 'en', '', '<main class="container services">\n<h1>Services</h1>\n<div class="content">\n	<div class="desc">\n		                             This project provides for production of the following products and provision of the following services:\n	</div>\n	<div>\n		<div class="col-50">\n			<h2> Production:</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Bitumen</li>\n				<li>Straight run gasoline</li>\n				<li>Low-viscosity marine fuel</li>\n				<li>Diesel oil</li>\n				<li>Kerosene oil</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Services:</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Transshipment of gas</li>\n				<li>Transshipment of bitumen</li>\n				<li>Transshipment of fuel oil</li>\n				<li>Fuel oil dehydration</li>\n				<li>Fuel oil filtration</li>\n				<li>Viscosity breaking and reduction of  fuel oil setting point</li>\n				<li>Oil processing</li>\n			</ul>\n		</div>\n	</div>\n</div>\n </main>', '', '', '', '', '', '2014-04-30 17:42:14', '2014-04-30 21:06:13'),
(21, 7, 'de', 'Dienste', '<main class="container services">\n<h1>Dienste</h1>\n<div class="content">\n	<div class="desc">\n		 Das Projekt sieht Herstellung von folgenden Produkten und Erbringung von folgenden Leistungen vor:\n	</div>\n	<div>\n		<div class="col-50">\n			<h2>Produktion:</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Bitumen</li>\n				<li>Primärbenzin</li>\n				<li>dünnflüssiger Schiffskraftstoff</li>\n				<li>Masut</li>\n				<li>Kerosin</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Leistungen:</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Umschlag von Gas</li>\n				<li>Umschlag von Bitumen</li>\n				<li>Umschlag von Masut</li>\n				<li>Masutentwässerung</li>\n				<li>Masutfiltration</li>\n				<li>Reduzierung der Viskosität und Erhärtung des Masuts</li>\n				<li>Erdölverarbeitung</li>\n			</ul>\n		</div>\n	</div>\n</div>\n </main>', 'dienste', 'Dienste', '', '', '', '2014-04-30 17:42:14', '2014-04-30 21:06:13'),
(22, 8, 'ru', 'Карьера', '<main class="container services tenders">\n<h1>                 Карьера             </h1>\n<div class="content">\n	<div class="desc">\n		                        Уважаемые соискатели!\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                        Проведение работ по отбору кандидатов на замещение вакантных должностей в ООО «УПК» будет проводиться в 3 квартале 2014 года. За информацией о списках рабочих мест и количестве необходимых сотрудников, следите на нашем сайте в разделе <a class="typical-link" href="/ru/news">«новости»</a>.<br>\n		</div>\n	</div>\n</div>\n </main>', 'karera', 'Карьера', '', '', '', '2014-04-30 17:44:19', '2014-05-05 07:10:51'),
(23, 8, 'en', 'Career', '<main class="container services">\n<h1>Career</h1>\n<div class="content">\n	<div class="desc">\n		  Dear candidates!\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			 The work on applicants selection to fill vacancies at LLC UPC will be held in the 3rd quarter of 2014.   Track the information about the list of work places and the number of the required employees on our website in section <a class="typical-link" href="/en/news" news<="" a="">.  </a>\n		</div>\n		 <a class="typical-link" href="/en/news" news<="" a=""> </a>\n	</div>\n	 <a class="typical-link" href="/en/news" news<="" a=""> </a>\n</div>\n <a class="typical-link" href="/en/news" news<="" a=""></a></main>', 'career', 'Career', '', '', '', '2014-04-30 17:44:19', '2014-05-05 07:10:51'),
(24, 8, 'de', 'Karriere', '<main class="container services">\n<h1>Karriere</h1>\n<div class="content">\n	<div class="desc">\n		  Liebe Bewerber!\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			  Auswahl von Kandidaten für Stellenbesetzung bei OOO «UPK» erfolgt im 3. Quartal 2014. Informationen zu offenen Stellen mit benötigter Personalzahl finden Sie auf unserer Webseite in der Rubrik <a class="typical-link" href="/de/news">Nachrichten</a>.\n		</div>\n	</div>\n</div>\n </main>', 'karriere', 'Karriere', '', '', '', '2014-04-30 17:44:19', '2014-05-05 07:10:51'),
(25, 9, 'ru', 'Инвесторам', '<div class="desc">\n	                                Предлагаем Вам принять участие в реализации инвестиционного проекта                     «Успенский перерабатывающий комплекс». Целью создания комплекса является                     организация многопрофильного производства по переработке нефти и нестандартных                     темных нефтепродуктов, а также оказание большого спектра услуг в нефтяной сфере.\n</div>\n<div class="more-desc">\n	<div class="more-desc-part">\n		                                    Для организации финансирования  и управления размещением сертификатов                         участия на рынке капитала наша компания заключила контракт со                         швейцарской компанией <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a>.                         По возникшим вопросам, касающимся размещения сертификатов участия, просим                         обращаться в данную компанию.\n	</div>\n	<div class="more-desc-part">\n		                                    Для реализации проекта ООО «Успенский перерабатывающий комплекс»                         выпускает привилегированные сертификаты участия. Принятие участия                         представляет собой приобретение вышеуказанных сертификатов. Подробные                         условия изложены в эмиссионном проспекте. Для ознакомления                         введите логин и пароль.\n	</div>\n	<div class="more-desc-part">\n		                                    Чтобы получить доступ к загрузке эмисионного проспекта,<br>\n		 <a href="/ru/request-to-access">отправьте запрос.</a>\n	</div>\n</div>', 'investoram', 'Инвесторам', '', '', '', '2014-04-30 17:45:36', '2014-04-30 21:48:24'),
(26, 9, 'en', 'Investors', '<div class="desc">\n	                                  We invite you to participate in implementation of investment project Uspenskiy Processing Complex. The goal of creating the complex is to organize a diversified enterprise of oil and dark unconventional oil products processing, as well as to create a wide range of services in the oil field.\n</div>\n<div class="more-desc">\n	<div class="more-desc-part">\n		        To arrange financing and management of placement of participation certificates on the capital market our company concluded a contract with the Swiss company <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a>. On any questions regarding placement of certificates of participation, please, contact the above-mentioned company.\n	</div>\n	<div class="more-desc-part">\n		        In order to implement the project, LLC Uspenskiy Processing Plant issues preferred certificates of participation. Taking part is acquisition of the above-mentioned certificates. The terms are specified in the emission prospect.\n	</div>\n	<div class="more-desc-part">\n		                                      To get access to emission prospect, please <a href="/en/request-to-access">fill the form.</a>\n	</div>\n</div>', 'investors', 'Investors', '', '', '', '2014-04-30 17:45:36', '2014-04-30 21:48:24'),
(27, 9, 'de', 'Investors', '<div class="desc">\n	      Wir laden Sie zur Teilnahme an der Realisierung des Investitionsprojektes „Uspensker Erdölraffinerie“ ein. Angestrebtes Ziel bei der Errichtung der Raffinerie ist die Organisation eines Mehrzweck-Produktionsbetriebs zur Verarbeitung von Erdöl und dunklen Erdölprodukten, sowie umfangreiche Palette an Dienstleistungen in der Erdölbranche.\n</div>\n<div class="more-desc">\n	<div class="more-desc-part">\n		      Zu Zwecken der Finanzierung  und Kontrolle über die Unterbringung der Partizipationsscheine auf dem Kapitalmarkt haben wir einen Vertrag mit der Schweizer Firma <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a> abgeschlossen. Bei weiteren Fragen bezüglich der Unterbringung von Partizipationsscheinen wenden Sie sich bitte an diese Firma.\n	</div>\n	<div class="more-desc-part">\n		      Für die Projektrealisierung emittiert  die OOO «Uspenskij pererabatywajuschtschij komplex» Vorzugspartizipationsscheine. Die Beteiligung  erfolgt durch den Erwerb von o.g. Wertpapieren.\n	</div>\n	<div class="more-desc-part">\n		    Zu Emisionnsrospekt zugreifen, füllen Sie bitte <a href="/en/request-to-access">das Formular aus</a>.\n	</div>\n</div>', 'investors', 'Investors', '', '', '', '2014-04-30 17:45:36', '2014-04-30 21:48:24'),
(28, 10, 'ru', 'Интранет', '<main class="container investors">\n<h1>                 Эммисионный проспект             </h1>\n<div class="content">\n	<div class="desc">\n		                           Для ознакомления с эмиссионным проспектом, пожалуйста, скачайте файл по ссылке.\n	</div>\n	<div class="intranet-desc">\n		<a href="#" class="link-pdf">                         Скачать документ                     </a>\n	</div>\n</div>\n</main>', 'intranet', 'intranet', '', '', '', '2014-04-30 17:46:23', '2014-04-30 21:29:06'),
(29, 10, 'en', 'Intranet', '<main class="container investors">\n<h1>Emission prospect</h1>\n<div class="content">\n	<div class="desc">\n		   In order to implement the project, LLC Uspenskiy Processing Plant issues preferred certificates of participation. Taking part is acquisition of the above-mentioned certificates. The terms are specified in the emission prospect.\n	</div>\n	<div class="intranet-desc">\n		 <a href="#" class="link-pdf">Download</a>\n	</div>\n</div>\n </main>', 'intranet', 'Intranet', '', '', '', '2014-04-30 17:46:23', '2014-04-30 21:29:06'),
(30, 10, 'de', 'Intranet', '<main class="container investors">\n<h1>Emissionsprospekt</h1>\n<div class="content">\n	<div class="desc">\n		     Für die Projektrealisierung emittiert  die OOO «Uspenskij pererabatywajuschtschij komplex» Vorzugspartizipationsscheine. Die Beteiligung  erfolgt durch den Erwerb von o.g. Wertpapieren. Nähere Informationen hierzu finden Sie im beigefügten Emissionsprospekt.\n	</div>\n	<div class="intranet-desc">\n		<a href="/uploads/1398883488_qk5jC5yw032eUZRQvmZVnWOCQMQddnTzb8OdrqSS.pdf" class="link-pdf" target="_blank">Klicken sie hier</a>\n	</div>\n</div>\n</main>', 'intranet', 'Intranet', '', '', '', '2014-04-30 17:46:23', '2014-04-30 21:29:06'),
(31, 11, 'ru', 'Тендеры', '<main class="container services tenders">\n<h1>                 Тендеры             </h1>\n<div class="content">\n	<div class="desc">\n		                            Размещение информации  о работах, товарах и услугах, а также предварительному отбору поставщиков  товаров, услуг и подрядчиков, ООО «Успенский перерабатывающий комплекс» планирует  в конце 2 квартала 2014 года.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                            За информацией следите на нашем сайте в разделе <a class="typical-link" href="/ru/news">«новости»</a>.<br>\n		</div>\n	</div>\n</div>\n </main>', 'tendery', 'Тендеры', '', '', '', '2014-04-30 17:48:36', '2014-04-30 21:33:24'),
(32, 11, 'en', 'Tenders', '<main class="container services tenders">\n<h1>Tenders</h1>\n<div class="content">\n	<div class="desc">\n		    LLC Uspenskiy Processing Complex  plans to place the information about the works, goods and services, as well as  preliminary selection of goods and services suppliers and  contractors in the end of the 2nd quarter of year 2014.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			    Track the information on our website in section <a class="typical-link" href="/en/news">News</a>.<br>\n		</div>\n	</div>\n</div>\n</main>', 'tenders', 'Tenders', '', '', '', '2014-04-30 17:48:36', '2014-04-30 21:33:24'),
(33, 11, 'de', 'Angebote', '<main class="container services tenders">\n<h1>Angebote</h1>\n<div class="content">\n	<div class="desc">\n		  Informationen zu Waren und Leistungen, sowie vorläufige Ausschreibungen für Lieferanten von Waren und Leistungen und Auftragnehmer werden voraussichtlich zum Ende des 2. Quartals 2014 bekanntgegeben.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			   Die Informationen finden Sie auf unserer Webseite in der Rubrik <a class="typical-link" href="/de/news">Nachrichten</a>.\n		</div>\n	</div>\n</div>\n</main>', 'angebote', 'Angebote', '', '', '', '2014-04-30 17:48:36', '2014-04-30 21:33:24'),
(34, 12, 'ru', 'Контакты', '<div class="more-desc">\n	<div class="more-desc-part">\n		    ООО «Успенский перерабатывающий комплекс»<br>\n		            Генеральный директор: Бабилоев Алексей Николаевич<br>\n		            Адрес: 344013,  Россия,  Ростовская область,<br>\n		            г. Ростов-на-Дону, ул. Текучева, 162, офис 302\n	</div>\n</div>\n <address>\n<div class="s-phones col-40">\n	 <a href="tel:+78632806656">+7 (863) 280-66-56</a><a href="tel:+78632345608">+7 (863) 234-56-08</a><a href="tel:+79282797309">+7 (928) 279-73-09</a>\n</div>\n<div class="mails col-40">\n	 <a href="mailto:rdo2009@mail.ru">rdo2009@mail.ru</a>\n</div>\n </address>', 'kontakty', 'Контакты', '', '', '', '2014-04-30 17:49:09', '2014-04-30 21:37:02'),
(35, 12, 'en', 'Contacts', '<div class="more-desc">\n	<div class="more-desc-part">\n		     Uspenskiy Pocessing Complex LLC<br>\n		  CEO Babiloev Alexey Nikolaevich<br>\n		              office 302, 162 Tekuchev street,<br>\n		             Rostov-on-Don, Russia, 344013\n	</div>\n</div>\n<address>\n<div class="s-phones col-40">\n	<a href="tel:+78632806656">+7 (863) 280-66-56</a><a href="tel:+78632345608">+7 (863) 234-56-08</a><a href="tel:+79282797309">+7 (928) 279-73-09</a>\n</div>\n<div class="mails col-40">\n	<a href="mailto:rdo2009@mail.ru">rdo2009@mail.ru</a>\n</div>\n</address>', 'contacts', 'Contacts', '', '', '', '2014-04-30 17:49:09', '2014-04-30 21:37:02'),
(36, 12, 'de', 'Kontakt', '<div class="more-desc">\n	<div class="more-desc-part">\n		      Uspensker Verarbeitungskomplex Gmbh<br>\n		    162 Tekuchev Strasse, Rostov-on-Don, Russia<br>\n		                Mr Babiloev Alexey Nikolaevich\n	</div>\n</div>\n<address>\n<div class="s-phones col-40">\n	<a href="tel:+78632806656">+7 (863) 280-66-56</a><a href="tel:+78632345608">+7 (863) 234-56-08</a><a href="tel:+79282797309">+7 (928) 279-73-09</a>\n</div>\n<div class="mails col-40">\n	<a href="mailto:rdo2009@mail.ru">rdo2009@mail.ru</a>\n</div>\n</address>  , 344013  fon.  +7 (863) 280-66-56, fon./fax + 7(863)234-56-08, mobil. +7 (928) 614-47-74 E-mail: rdo2009@mail.ru', 'kontakt', 'Kontakt', '', '', '', '2014-04-30 17:49:09', '2014-04-30 21:37:02'),
(37, 13, 'ru', 'Карта сайта', '<main class="container about">\n<h1>                 Карта сайта             </h1>\n<ul class="sitemap">\n	<li class="sitemap-item"><a href="/ru/">Главная</a></li>\n	<li class="sitemap-item"><a href="/ru/about">О компании</a></li>\n	<li class="sitemap-item"><a href="/ru/news">Пресс-центр</a></li>\n	<li class="sitemap-item"><a href="/ru/services">Услуги</a></li>\n	<li class="sitemap-item"><a href="/ru/career">Карьера</a></li>\n	<li class="sitemap-item"><a href="/ru/investors">Инвесторам</a></li>\n	<li class="sitemap-item"><a href="/ru/tenders">Тендеры</a></li>\n	<li class="sitemap-item"><a href="/ru/contacts">Контакты</a></li>\n</ul>\n </main>', 'karta-saiyta', 'Карта сайта', '', '', '', '2014-04-30 17:49:56', '2014-04-30 21:42:46'),
(38, 13, 'en', 'Sitemap', '<main class="container about">\n<h1>Sitemap</h1>\n<ul class="sitemap">\n	<li class="sitemap-item"><a href="/en/">Main page</a></li>\n	<li class="sitemap-item"><a href="/en/about">About us</a></li>\n	<li class="sitemap-item"><a href="/en/news">Press center</a></li>\n	<li class="sitemap-item"><a href="/en/services">Services</a></li>\n	<li class="sitemap-item"><a href="/en/career">Career</a></li>\n	<li class="sitemap-item"><a href="/en/investors">For investors</a></li>\n	<li class="sitemap-item"><a href="/en/tenders">Tenders</a></li>\n	<li class="sitemap-item"><a href="/en/contacts">Contacts</a></li>\n</ul>\n</main>', 'sitemap', 'Sitemap', '', '', '', '2014-04-30 17:49:56', '2014-04-30 21:42:46'),
(39, 13, 'de', 'Sitemap', '<main class="container about">\n<h1>Sitemap</h1>\n<ul class="sitemap">\n	<li class="sitemap-item"><a href="/de/">Home</a></li>\n	<li class="sitemap-item"><a href="/de/about">Übur uns</a></li>\n	<li class="sitemap-item"><a href="/de/news">Presse</a></li>\n	<li class="sitemap-item"><a href="/de/services">Dienste</a></li>\n	<li class="sitemap-item"><a href="/de/career">Karriere</a></li>\n	<li class="sitemap-item"><a href="/de/investors">Investors</a></li>\n	<li class="sitemap-item"><a href="/de/tenders">Angebote</a></li>\n	<li class="sitemap-item"><a href="/de/contacts">Kontakt</a></li>\n</ul>\n</main>', 'sitemap', 'Sitemap', '', '', '', '2014-04-30 17:49:56', '2014-04-30 21:42:46'),
(40, 14, 'ru', 'Заявка на доступ к документам', '<div class="desc">\n	                          Для ознакомления с эмиссионным проспектом, пожалуйста, заполните все поля формы. Мы направим вам логин и пароль на указанный адрес электронной почты.\n</div>', 'zayavka-na-dostup-k-dokumentam', 'Заявка на доступ к документам', '', '', '', '2014-04-30 17:51:14', '2014-04-30 21:46:03'),
(41, 14, 'en', 'Request for access to documents', '<div class="desc">\n	  To get access to emission prospect, please fill the form. We will send you email with login and password.\n</div>', 'request-for-access-to-documents', 'Request for access to documents', '', '', '', '2014-04-30 17:51:14', '2014-04-30 21:46:03'),
(42, 14, 'de', 'Emisionnsrospekt', '<div class="desc">\n	Zu Emisionnsrospekt zugreifen, füllen Sie bitte das Formular aus.\n</div>', 'request-for-access-to-documents', 'Emisionnsrospekt', '', '', '', '2014-04-30 17:51:14', '2014-04-30 21:46:03');

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `paths` text COLLATE utf8_unicode_ci,
  `attributes` text COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `images_module_id_index` (`module_id`),
  KEY `images_item_id_index` (`item_id`),
  KEY `images_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `default`, `created_at`, `updated_at`) VALUES
(1, 'ru', 'Русский', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_19_104802_create_users_table', 1),
('2014_01_19_104821_create_groups_table', 1),
('2014_01_19_104830_pivot_group_user_table', 1),
('2014_01_19_104934_create_roles_table', 1),
('2014_01_19_104954_pivot_group_role_table', 1),
('2014_01_19_105008_create_pages_table', 1),
('2014_02_08_123907_create_languages_table', 1),
('2014_02_10_125947_create_galleries_table', 1),
('2014_02_10_130103_create_photos_table', 1),
('2014_02_17_105422_create_settings_table', 1),
('2014_02_18_133757_create_news_table', 1),
('2014_02_20_094843_create_templates_table', 1),
('2014_03_03_201446_create_modules_table', 1),
('2014_04_08_142125_create_session_table', 1),
('2014_04_10_085237_create_permissions_table', 1),
('2014_04_10_090423_pivot_user_module_permission', 1),
('2014_04_14_101731_create_articles_table', 1),
('2014_04_18_103249_create_catalogs_table', 1),
('2014_04_21_133950_create_categories_group_table', 1),
('2014_04_22_070606_create_categories_table', 1),
('2014_04_22_143526_create_products_table', 1),
('2014_04_23_103825_create_images_table', 1),
('2014_04_25_101239_create_category_product_table', 1),
('2014_04_25_112828_create_manufacturers_table', 1),
('2014_04_28_115029_create_products_attributes_group_table', 1),
('2014_04_28_115149_create_products_attributes_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `permissions` varchar(255) COLLATE utf8_unicode_ci DEFAULT '[]',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `url`, `on`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'seo', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:44:57'),
(2, 'news', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'articles', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'pages', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'catalogs', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'users', 0, '[1,2,3]', '2014-04-29 09:43:10', '2014-04-29 09:45:09'),
(7, 'downloads', 1, '[3,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:11'),
(8, 'statistic', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'galleries', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(10, 'languages', 0, '[1,2,3,4]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(11, 'settings', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(12, 'templates', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `module_permissions`
--

DROP TABLE IF EXISTS `module_permissions`;
CREATE TABLE IF NOT EXISTS `module_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `module_id` int(10) unsigned DEFAULT NULL,
  `permission_id` int(10) unsigned DEFAULT NULL,
  `value` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `module_permissions_user_id_index` (`user_id`),
  KEY `module_permissions_module_id_index` (`module_id`),
  KEY `module_permissions_permission_id_index` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `sort`, `template`, `title`, `language`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `publication`, `created_at`, `updated_at`) VALUES
(3, 5, 'news', 'Регистрация компании-инициатора проекта', 'ru', '', '<p>\n	26.12.2012 года состоялась государственная регистрация ООО «Успенский перерабатывающий комплекс». Эта дата послужила началом реализации идеи о создании в Ростовской области универсального комплекса по переработке нестандартных темных нефтепродуктов. Данная дата является исторической для компании и олицетворяет первый шаг на пути к реализации проекта.\n</p>', 'oficialnyiy-start-proekta', 'Официальный старт проекта', '', '', '', 1, '2012-12-26 11:20:47', '2014-04-30 16:16:05'),
(5, 6, 'news', 'Официальный старт реализации проекта', 'ru', '', '<p>\n	Данная дата является началом серьезной работы по реализации, продвижению и позиционированию инвестиционного проекта  ООО «УПК», с целью привлечения финансирования. На данном этапе были определены основные направления и действия, необходимые для успешной реализации проекта.\n</p>', 'oficialnyiy-start-realizacii-proekta', 'Официальный старт реализации проекта', '', '', '', 1, '2013-09-01 16:16:40', '2014-04-30 16:16:40'),
(6, 7, 'news', 'Заключение договора на приобретение земельных участков под строительство комплекса.', 'ru', '', '<p>\n	23.09.2013 г. Состоялось подписание договора купли-продажи земельных участков  с  уже существующей инфраструктурой и железно-дорожной ветки, протяженностью 1,82 км. Земельные участки расположены вблизи с. Авило-Успенка Матвеево-Курганского района Ростовской области. Приобретение площадки под строительство послужило толчком к началу работ по сбору исходно-разрешительной документации на строительство комплекса, а также работ по подготовке предпроектной документации.\n</p>', 'zaklyuchenie-dogovora-na-priobretenie-zemelnyh-uchastkov-pod-stroitelstvo-kompleksa', 'Заключение договора на приобретение земельных участков под строительство комплекса.', '', '', '', 1, '2013-09-23 16:17:02', '2014-04-30 16:17:02'),
(7, 8, 'news', 'Участие и позиционирование проекта на XII Международном Инвестиционном форуме  «Сочи-2013»', 'ru', '', '<p>\n	С 26.09.2013 г. по 29.09.2013 г. ООО «УПК» посетило Международный Инвестиционный форум «Сочи-2013». На форуме руководству компании удалось представить свой проект, а также познакомиться лично со многими руководителями различных ведомств Ростовской области,  несколькими членами Совета Федерации, с депутатами Государственной думы, с представителями федерального бизнеса и руководителями ряда инвестиционных компаний.\n</p>', 'uchastie-i-pozicionirovanie-proekta-na-xii-mejdunarodnom-investicionnom-forume-sochi-2013', 'Участие и позиционирование проекта на XII Международном Инвестиционном форуме  «Сочи-2013»', '', '', '', 1, '2013-09-26 16:17:37', '2014-04-30 16:17:37'),
(8, 9, 'news', 'Согласование строительства комплекса в Администрации Матвеево-Курганского района Ростовской области', 'ru', '', '<p>\n	Администрацией Матвеево-Курганского района Ростовской области 08.10.2013 г. официально было согласовано строительство Успенского перерабатывающего комплекса. Как было отмечено Главой Матвеево-Курганского района  Рудковским А.А. – строительство комплекса будет способствовать дальнейшему экономическому  развитию района, созданию новых рабочих мест, укреплению налогооблагаемой базы. Кроме того было гарантировано содействие в реализации вопросов, связанных с реализацией проекта.\n</p>', 'soglasovanie-stroitelstva-kompleksa-v-administracii-matveevo-kurganskogo-raiyona-rostovskoiy-oblasti', 'Согласование строительства комплекса в Администрации Матвеево-Курганского района Ростовской области', '', '', '', 1, '2013-10-08 16:17:59', '2014-04-30 16:17:59'),
(9, 10, 'news', 'Включение проекта в реестр инвестиционных проектов Ростовской области', 'ru', '', '<p>\n	07.11.2013 г. состоялось совещание рабочей группы по вопросам инвестиционной деятельности, внедрению инновационной продукции инновационных разработок Министерства промышленности и энергетики Ростовской области, проводимом совместно с Департаментом инвестиционного развития Ростовской области. В ходе совещания, был рассмотрен инвестиционный проект ООО «УПК», который по результатам совещания был официально включен в реестр инвестиционных проектов  Ростовской области и взят под контроль профильным Министерством, что в свою очередь что позволит в дальнейшем воспользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы по налогообложению и компенсации по затратам на присоединение объекта к инженерным сетям газо-, электро- и водоснабжения.\n</p>', 'vklyuchenie-proekta-v-reestr-investicionnyh-proektov-rostovskoiy-oblasti', 'Включение проекта в реестр инвестиционных проектов Ростовской области', '', '', '', 1, '2013-11-07 16:18:17', '2014-04-30 16:18:17'),
(10, 11, 'news', 'Подписание договора на разработку предпроектных предложений', 'ru', '', '<p>\n	22.01.2014 года состоялось подписание договора и с ООО «НОУ ПРОМ» г. Краснодар о выполнении комплекса работ по предпроектной подготовке.\n</p>', 'podpisanie-dogovora-na-razrabotku-predproektnyh-predlojeniiy', 'Подписание договора на разработку предпроектных предложений', '', '', '', 1, '2014-01-22 16:18:34', '2014-04-30 16:18:34'),
(11, 12, 'news', 'Приобретение дополнительных земельных участков', 'ru', '', '<p>\n	Подписан договор купли-продажи земельных участков площадью 14 Га, примыкающих к ранее приобретенным участкам.\n</p>', 'priobretenie-dopolnitelnyh-zemelnyh-uchastkov', 'Приобретение дополнительных земельных участков', '', '', '', 1, '2014-01-24 16:18:52', '2014-04-30 16:18:52'),
(12, 13, 'news', 'Приобретение дополнительных земельных участков', 'ru', '', '<p>\n	Подписан договор купли-продажи земельных участков площадью 12 Га, примыкающих к ранее приобретенным участкам.  Подписанием данного договора площадь площадки под размещение Успенского перерабатывающего комплекса составила 40 Га.\n</p>', 'priobretenie-dopolnitelnyh-zemelnyh-uchastkov', 'Приобретение дополнительных земельных участков', '', '', '', 1, '2014-02-07 16:19:07', '2014-04-30 16:19:07'),
(13, 14, 'news', 'Проведение переговоров со Швейцарской инвестиционной компанией IFM AG', 'ru', '', '<p>\n	10.02.2014 года состоялись переговоры со Швейцарской инвестиционной компанией IFM AG по вопросам взаимовыгодного сотрудничества в сфере финансирования проекта «Успенский перерабатывающий комплекс».\n</p>', 'provedenie-peregovorov-so-shveiycarskoiy-investicionnoiy-kompanieiy-ifm-ag', 'Проведение переговоров со Швейцарской инвестиционной компанией IFM AG', '', '', '', 1, '2014-02-10 16:19:25', '2014-04-30 16:19:25'),
(14, 15, 'news', 'Участие в Международном инвестиционном форуме MIPIM 2014', 'ru', '', '<p>\n	С 11.03.2014 года по 14.03.2014 года руководство компании приняло участие в Международном инвестиционном форуме MIPIM 2014. В ходе данного мероприятия удалось презентовать проект компании на самом высоком международном уровне, познакомиться с иностранными и российскими инвесторами<strong>.</strong>\n</p>', 'uchastie-v-mejdunarodnom-investicionnom-forume-mipim-2014', 'Участие в Международном инвестиционном форуме MIPIM 2014', '', '', '', 1, '2014-03-11 16:19:48', '2014-04-30 16:19:48'),
(15, 16, 'news', 'Участие в программе повышения квалификации  руководителей  mini MBA', 'ru', '', '<p>\n	Руководство компании приняло участие в программе повышения квалификации  руководителей  mini MBA.\n</p>', 'uchastie-v-programme-povysheniya-kvalifikacii-rukovoditeleiy-mini-mba', 'Участие в программе повышения квалификации  руководителей  mini MBA', '', '', '', 1, '2014-03-27 16:21:01', '2014-04-30 16:21:01'),
(16, 20, 'news', 'Руководство компании завершило обучение в программе mini MBA', 'ru', '', '<p>\n	 <img src="http://uspensky-pk.ru/uploads/1399272697_AZGUARxE3ECfxTxU7UjfuE9KSEIzmmZ1FmlXgpVK.jpg">\n</p>\n<p>\n	   Руководство компании завершило обучение в программе повышения квалификации  руководителей  miniMBA по блоку «Управление».\n</p>', 'rukovodstvo-kompanii-zavershilo-obuchenie-v-programme-minimba', 'Руководство компании завершило обучение в программе miniMBA', '', '', '', 1, '2014-04-28 16:21:55', '2014-05-05 06:52:31');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `in_menu`, `sort_menu`, `template`, `language`, `name`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `content`, `publication`, `start_page`, `created_at`, `updated_at`) VALUES
(1, 0, 40, 'index-page', 'ru', 'Главная', '', 'Главная', '', '', '', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	          Инвестиции в уникальные технологии\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			 [news path="news-on-main-page" limit="1"]\n		</div>\n		<a href="/news" class="block-hover">\n		<div class="block-hv-text">\n			          Все новости УПК\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				          Инвесторам\n			</div>\n			<div class="block-text">\n				                                   Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс».\n			</div>\n		</div>\n		<a href="/investors" class="block-hover">\n		<div class="block-hv-text">\n			          Подробнее\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				          Контакты\n			</div>\n			<div class="block-text">\n				                                   г. Ростов-на-Дону,<br>\n				           ул. Текучева, 162, офис 302<br>\n				           тел. +7 (863) 280-66-56, <br>\n				           E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		<a href="/contacts" class="block-hover">\n		<div class="block-hv-text">\n			          На карте\n		</div>\n		</a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n</section>', 1, 1, '2014-04-29 09:52:33', '2014-04-30 14:47:52'),
(2, 0, 33, 'default', 'ru', 'О компании', 'about', 'О компании', '', '', '', '<main class="container about">\n<h1>О компании</h1>\n<!--<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>-->\n<div class="content">\n	<div class="desc">\n		                         В России очень мало компаний, которые официально занимаются утилизацией                     и переработкой «темных нестандартных нефтепродуктов». Счет производств,                     которые профильно занимаются переработкой подобных нефтепродуктов                     и имеют лицензию на переработку идет на еденицы по всей стране.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                         Специалисты компании — инициатора проекта уже более 3-х лет занимаются исследованиями рынка «темных нестандартных нефтепродуктов», практической реализацией мелких проектов по переработке обводненного мазута.<br>\n			     В процессе накопленного практического опыта, глубокий анализ показал, что на Юге России нет ни одного официального производства по переработке вышеуказанных продуктов несмотря на то, что в России очень много предприятий, которые имеют потребность в заключении долгосрочных контрактов на утилизацию и переработку получаемых ими «темных нестандартных нефтепродуктов», но в силу отсутствия таковых, вынуждены утилизировать НТН, используя различные незаконные схемы сбыта, что влечет за собой огромные риски и снижение рентабельности.<br>\n			     Благодаря такому практическому опыту родилась идея создания <strong>универсального комплекса</strong> по переработке нестандартных темных нефтепродуктов.<br>\n		</div>\n	</div>\n	<h2>                     История                 </h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>                             Зарегистрирована компания                         </h3>\n		<div class="hist-desc">\n			                                  26.12.2012 в целях реализации возникшей идеи была зарегистрирована компания Общество с ограниченной ответственностью «Успенский перерабатывающий комплекс», которая в настоящий момент является инициатором проекта по строительству перерабатывающего комплекса.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="theme/img/icons/rocket.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Официальный старт проекта                         </h3>\n		<div class="hist-desc">\n			                                 В сентябре 2013 года проект официально стартовал, и начались первые шаги по реализации данного проекта.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Включение в реестр инвестиционных проектов Ростовской области                         </h3>\n		<div class="hist-desc">\n			                                 7 Ноября 2013 года в Министерстве промышленности и энергетики Ростовской области состоялось совещание рабочей группы по вопросам развития инвестиционной деятельности. По результатам указанного совещания инвестиционный проект ООО «Успенский перерабатывающий комплекс» был успешно включен в реестр инвестиционных проектов Ростовской области, что позволяет в дальнейшем пользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>                             Предпроектные работы                         </h3>\n		<div class="hist-desc">\n			                                 В настоящее время проект успешно находится в стадии реализации на этапе предпроектных работ и большими шагами движется к заданной цели.\n		</div>\n	</div>\n	</li>\n</ul>\n </main>', 1, 0, '2014-04-29 10:39:11', '2014-04-30 13:12:57'),
(3, 0, 45, 'default', 'ru', 'Пресс-центр', 'news', 'Пресс-центр', '', '', '', '<main class="container news">\n<h1>Новости</h1>\n<div class="press-about-us">\n	<div class="press-btn">\n		 Пресса о нас\n	</div>\n	<ul class="articles list-unstyled">\n		<li class="art-item" data-date="октябрь 2013"><a href="/uploads/1398875286_mwzgubEi2WgFTNvoL2eqJyRDc7f9IiDhWYRBhIyd.pdf" target="_blank">Реальный бизнес</a></li>\n		<li class="art-item" data-date="апрель 2014"><a href="/uploads/1398875285_V19bfWwYMUqalYV0aC9BgEWOjg0YiTIaFgQnSTVw.JPG" target="_blank">Реальный бизнес</a></li>\n	</ul>\n</div>\n     [news limit="10"] </main>', 1, 0, '2014-04-29 10:41:30', '2014-04-30 16:43:10'),
(4, 0, 34, 'default', 'ru', 'Услуги', 'services', 'Услуги', '', '', '', '<main class="container services">\n<h1>Услуги</h1>\n<div class="content">\n	<div class="desc">\n		                       Настоящий проект предполагает производство следующих                     продуктов и оказание услуг\n	</div>\n	<div>\n		<div class="col-50">\n			<h2>Производство</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Битум</li>\n				<li>Бензин прямогонный</li>\n				<li>Судовое маловязкое топливо</li>\n				<li>Мазут</li>\n				<li>Керосин</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Услуги</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Перевалка газа</li>\n				<li>Перевалка битума</li>\n				<li>Перевалка мазута</li>\n				<li>Обезвоживание мазута</li>\n				<li>Фильтрация мазута</li>\n				<li>Понижение вязкости и застывания мазута</li>\n				<li>Переработка нефти</li>\n			</ul>\n		</div>\n	</div>\n</div>\n </main>', 1, 0, '2014-04-29 10:44:31', '2014-04-30 13:15:32'),
(6, 0, 19, 'default', 'ru', 'Карьера', 'career', 'Карьера', '', '', '', '<main class="container services">\n            <h1>\n                Карьера\n            </h1>\n            <div class="content">\n                <div class="desc">\n                    Уважаемые соискатели!\n                </div>\n                <div class="more-desc">\n                    <div class="more-desc-part">\n                    <p>Проведение работ по отбору кандидатов на замещение вакантных должностей в ООО «УПК» будет проводиться в 3 квартале 2014 года.\nЗа информацией о списках рабочих мест и количестве необходимых сотрудников, следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.</p>\n                    </div>\n                </div>\n                </div>\n            </div>\n            \n        </main>', 1, 0, '2014-04-29 11:04:34', '2014-04-29 11:04:34'),
(5, 0, 46, 'investors', 'ru', 'Инвесторам', 'investors', 'Инвесторам', '', '', '', '<div class="desc">\n	                      Предлагаем Вам принять участие в реализации инвестиционного проекта                     «Успенский перерабатывающий комплекс». Целью создания комплекса является                     организация многопрофильного производства по переработке нефти и нестандартных                     темных нефтепродуктов, а также оказание большого спектра услуг в нефтяной сфере.\n</div>\n<div class="more-desc">\n	<div class="more-desc-part">\n		                          Для организации финансирования  и управления размещением сертификатов                         участия на рынке капитала наша компания заключила контракт со                         швейцарской компанией <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a>.                         По возникшим вопросам, касающимся размещения сертификатов участия, просим                         обращаться в данную компанию.\n	</div>\n	<div class="more-desc-part">\n		                          Для реализации проекта ООО «Успенский перерабатывающий комплекс»                         выпускает привилегированные сертификаты участия. Принятие участия                         представляет собой приобретение вышеуказанных сертификатов. Подробные                         условия изложены в эмиссионном проспекте. Для ознакомления                         введите логин и пароль.\n	</div>\n	<div class="more-desc-part">\n		                          Чтобы получить доступ к загрузке эмисионного проспекта,<br>\n		 <a href="/request-to-access">отправьте запрос.</a>\n	</div>\n</div>', 1, 0, '2014-04-29 10:45:30', '2014-04-30 16:50:19'),
(10, 0, 32, 'default', 'ru', 'Интранет', 'intranet', 'Интранет', '', '', '', '<main class="container investors">\n<h1>                 Эммисионный проспект             </h1>\n<div class="content">\n	<div class="desc">\n		                     Для ознакомления с эмиссионным проспектом, пожалуйста, скачайте файл по ссылке.\n	</div>\n	<div class="intranet-desc">\n		<a href="#" class="link-pdf">                         Скачать документ                     </a>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-30 04:07:23', '2014-04-30 12:27:59'),
(7, 0, 20, 'default', 'ru', 'Тендеры', 'tenders', 'Тендеры', '', '', '', '<main class="container services tenders">\n<h1>                 Тендеры             </h1>\n<div class="content">\n	<div class="desc">\n		                     Размещение информации  о работах, товарах и услугах, а также предварительному отбору поставщиков  товаров, услуг и подрядчиков, ООО «Успенский перерабатывающий комплекс» планирует  в конце 2 квартала 2014 года.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                     За информацией следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.<br>\n		</div>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-29 11:07:18', '2014-04-29 11:07:18'),
(8, 0, 43, 'contacts', 'ru', 'Контакты', 'contacts', 'Контакты', '', '', '', '<div class="more-desc">\n	<div class="more-desc-part">\n	ООО «Успенский перерабатывающий комплекс»<br>\n        Генеральный директор: Бабилоев Алексей Николаевич<br>\n        Адрес: 344013,  Россия,  Ростовская область,<br>\n        г. Ростов-на-Дону, ул. Текучева, 162, офис 302\n	</div>\n</div>\n <address>\n<div class="s-phones col-40">\n	 <a href="tel:+78632806656">+7 863 280 66 56</a>\n         <a href="tel:+78632345608">+7 863 234 56 08</a>\n         <a href="tel:+79282797309">+7 928 279 73 09</a>\n</div>\n<div class="mails col-40">\n	 <a href="mailto:rdo2009@mail.ru">rdo2009@mail.ru</a>\n</div>\n </address>', 1, 0, '2014-04-29 11:08:20', '2014-04-30 16:18:43'),
(9, 0, 38, 'default', 'ru', 'Карта сайта', 'sitemap', 'Карта сайта', '', '', '', '<main class="container about">\n<h1>                 Карта сайта             </h1>\n<ul class="sitemap">\n	<li class="sitemap-item"><a href="/">Главная</a></li>\n	<li class="sitemap-item"><a href="/about">О компании</a></li>\n	<li class="sitemap-item"><a href="/news">Пресс-центр</a></li>\n	<li class="sitemap-item"><a href="/services">Услуги</a></li>\n	<li class="sitemap-item"><a href="/career">Карьера</a></li>\n	<li class="sitemap-item"><a href="/investors">Инвесторам</a></li>\n	<li class="sitemap-item"><a href="/tenders">Тендеры</a></li>\n	<li class="sitemap-item"><a href="/contacts">Контакты</a></li>\n	<li class="sitemap-item"><a href="/request-to-access">Заявка на доступ к документам</a></li>\n</ul>\n</main>', 1, 0, '2014-04-29 11:09:32', '2014-04-30 14:39:02'),
(11, 0, 31, 'request-for-access-to-documents', 'ru', 'Заявка на доступ к документам', 'request-to-access', 'Заявка на доступ к документам', '', '', '', '<div class="desc">\n	                     Для ознакомления с эмиссионным проспектом, пожалуйста, заполните все поля формы. Мы направим вам логин и пароль на указанный адрес электронной почты.\n</div>', 1, 0, '2014-04-30 11:30:36', '2014-04-30 11:30:36');

-- --------------------------------------------------------

--
-- Структура таблицы `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `desc`, `default`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Создание', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'edit', 'Редактирование', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'delete', 'Удаление', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'publication', 'Публикация', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'download', 'Загрузка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'sort', 'Сортировка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catalog_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_user_id_index` (`user_id`),
  KEY `products_catalog_id_index` (`catalog_id`),
  KEY `products_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes`
--

DROP TABLE IF EXISTS `products_attributes`;
CREATE TABLE IF NOT EXISTS `products_attributes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `product_attribute_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `products_attributes_product_attribute_group_id_index` (`product_attribute_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes_group`
--

DROP TABLE IF EXISTS `products_attributes_group`;
CREATE TABLE IF NOT EXISTS `products_attributes_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'news', 'Управление новостими', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'articles', 'Управление статьями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'pages', 'Управление страницами', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'catalogs', 'Управление каталогами товаров', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'users', 'Управление пользователями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'downloads', 'Управление загрузками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'statistic', 'Управление статистикой', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'galleries', 'Управление галереями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'languages', 'Управление языками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(10, 'settings', 'Управление настройками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(11, 'templates', 'Управление шаблонами', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('0781a73b9524f7f86f16db469ab0c86b7bdbf356', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQnF2NHRiaEdhbFFxMjlzWUdLR29sN3NKWk9RangwNE43TjVFd3BqZyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIyIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3NDczOTtzOjE6ImMiO2k6MTM5OTI3MjA4MTtzOjE6ImwiO3M6MToiMCI7fX0=', 1399274739),
('50bc5c6f63bbedda74fa8b9e9b6cc129fce910cb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGwwNnhWMTBnckpRRVJtNkdBcFozVTBjUlMxNGQ1c3hqVktMVjhWbSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3Mzc5MztzOjE6ImMiO2k6MTM5OTI3Mzc5MDtzOjE6ImwiO3M6MToiMCI7fX0=', 1399273793),
('71eaf2a4e4cc0393317f0ac7481b8f4d75d8f245', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoid1RlNmkzQTVTR2Fub0FzMzlnZjRKdlVheWI4Y1JmNTVORng3aXhuWiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIxIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3NjgwNztzOjE6ImMiO2k6MTM5OTI3MDY2NTtzOjE6ImwiO3M6MToiMCI7fX0=', 1399276807),
('4c271e2a877af4a40982442040daa5fe09ca29b2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRmJwODdDckZldlpHejhnRGZFWjhvcFg5QU55dDJSNmxDTDR4NU9lTCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3MjAwMztzOjE6ImMiO2k6MTM5OTI2OTk4MjtzOjE6ImwiO3M6MToiMCI7fX0=', 1399272003),
('01b64c8633c35ad8800d4af84bd38c7f7bf9975b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiblpPa0swNGNISWxLWW53d3dQanlvbDRkb3U4Skp6MHlDTmFCWW8zWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNjk5Nzg7czoxOiJjIjtpOjEzOTkyNjk5Nzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399269978),
('9a43e82e67ec1e59555b43d53f71b41ac1e7a359', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTThhMG12SkM0V3dibEc5V3lwZkdPeVBNeng1TEpZR0dSOXJJbEhQZSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3NDI2NjtzOjE6ImMiO2k6MTM5OTI2OTkzMDtzOjE6ImwiO3M6MToiMCI7fX0=', 1399274266),
('627da2eb130c8fe816aab4307aca36336b795d81', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWZaQ1JxQjV4eGRqRFNhSWZIMUpWRWZZSVkwbFBtZG9HbzlVT1JJSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNjg2MDY7czoxOiJjIjtpOjEzOTkyNjg2MDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399268606),
('77f5311014412856a8213997c0d5d2e2d7c5af2d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidGlYdjBzV2JZck5NQ3VObFJFWFJDbGpYRWl6cmVHYnVvWFVmZldkNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQyNzM7czoxOiJjIjtpOjEzOTkyNzQyNzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274273),
('5fe33d66a7ff70d8d068cf1c65a5e1d15eee3322', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQjZobTB1R3dRSXBobEw1NlE3NHZRUjlvdGdMTGRLMjB6TnU5SWQ5MSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQyOTI7czoxOiJjIjtpOjEzOTkyNzQyOTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274292),
('61f44fea0638150bfc3bf28951b0cba7ea6656bb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzhxN0c2Rzg0UkZrS2FXQkdQVmpwdDRYUHltWFRUb2l1SGJ1ZG9LRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQyOTM7czoxOiJjIjtpOjEzOTkyNzQyOTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274293),
('08fe89aa11d66fa9496c3f7779c7fbb2e20be2b0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2x4SmhJQVdmMWM1TjU3MXVoYnVZd0hENHF6UVFQcGNkMWYySzBPZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQyOTk7czoxOiJjIjtpOjEzOTkyNzQyOTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274299),
('f1c33958daaf12bd507d633db3b909f17526efb4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidGgwMTdqUXQwMUZGMDhPc3E0a2dXVEJFRXY0STZqeUlMclhLY3pBSSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMDA7czoxOiJjIjtpOjEzOTkyNzQzMDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274300),
('7468dc35c60b0245b5ab1341aced8f46f6d3479b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY3ZVZWxuQWRKVlVrclZLMXhCajBBeXFBdndmY1Y1VVcxdFd4R1JJNCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMDI7czoxOiJjIjtpOjEzOTkyNzQzMDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274302),
('8b925a55de3c9f9a8910f8c8150cc4ca5e286b07', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT1dmMFJvZnJmdEp2RjFHSVgwdzV1UEZhZnpMRm9haU00c2JvMWt4NiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMDM7czoxOiJjIjtpOjEzOTkyNzQzMDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274303),
('ec383e10522f57c0de1de6e69de3e24123a04569', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ1h2cU5XbTZLQ2VWQ2EwTU44b2pCbVl5c1lnYlBvSmVJdGE2RjY1MiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMDY7czoxOiJjIjtpOjEzOTkyNzQzMDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274306),
('aa414ff175416191017a11a1d9bf5df3c0aae003', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVFBRE5xNE9EbFN5NGVHa1MzaEIyYk1zOXVuYnRjRjdkRmlrWjkyNCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMDc7czoxOiJjIjtpOjEzOTkyNzQzMDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274307),
('6fc2325ea3de3040ce093a760792d7d9ea7807bd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUk5oMmtONUxsR25meGtzY1JrWlpVUEx5WFNUSzhGUE9wZ2tXQmFrMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMDg7czoxOiJjIjtpOjEzOTkyNzQzMDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274308),
('b82dae002a43d45e39f279bc6724478cbb0d1105', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiblVYd0xFWW1ub004WFFyTEZ2Yk0xOWJYSWRsOFc3Y09Ra2ZtUDVzQiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMTA7czoxOiJjIjtpOjEzOTkyNzQzMTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274310),
('c37c24c56eb2f1104799923a5e74afed128deac5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidDl3UmxzSklxZ1JEWW9UZTk4b1V2WGk2N0RVZXhFbjRzaUNRYlNsRCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMTE7czoxOiJjIjtpOjEzOTkyNzQzMTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274311),
('5d91200f0c972752143781b4a37090ebd92cbff4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVhBak9IbGtyOXppVFFBZE0wdnBNVVZmUUxNS204eWdzcGlyMTR3NSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMTI7czoxOiJjIjtpOjEzOTkyNzQzMTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274312),
('d956b5a34b7b3a812dd45ab77192b2678d1b3c93', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFV6OFE3d3pORXZiaHE0TzNNTkI4T3pFQ3NmMFA2RndWS21GQ01CdyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMTQ7czoxOiJjIjtpOjEzOTkyNzQzMTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274314),
('1fed9ae545a4869feab71989b692cdea766ca5a8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTJMdXRCSW42TTJLYVY0ZkMxQ3p5d1ZIS0V3VERtdWpwTVVBZXBHbiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQzMTQ7czoxOiJjIjtpOjEzOTkyNzQzMTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274315),
('e1ceace6ffab230dcf1d0022fb87bedfa12600ac', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaTNVd0xybmFudUJtVU1kYWljRENqR0RWYXRkZ0t0VkVxcWJ2bVphdyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NDI7czoxOiJjIjtpOjEzOTkyNzQ0NDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274442),
('1ac23cdff4ee8089172e464fc9b631924e78bece', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOWpkM0NUeFBVNVlqZWFwU241N0w4Nkd2bUtodFpYdmpZU1ZRTTRUQSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NDM7czoxOiJjIjtpOjEzOTkyNzQ0NDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274443),
('8cb344eb46713534e03c836a34b7db6e3118d545', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUVIQ25ESDc5elViWWpoOE94VURGcWdlQm55RGUxdHhLUVVBZ0dxZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NTA7czoxOiJjIjtpOjEzOTkyNzQ0NTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274450),
('a97062c0093373c58f88838fa2385c65a6a44fb5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaURVdEZVTlA1OEVQS1NscDRsRlI0TGU0blNGdHhmZGNEMlJpU2txMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NTI7czoxOiJjIjtpOjEzOTkyNzQ0NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274452),
('83c1258a2a50493ea6478254004fdb74a65af202', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUWVlSkR0bktGY3BQVFNvT3dpZXBzd091aFI0eThuREVJcWpsZkVtZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NTc7czoxOiJjIjtpOjEzOTkyNzQ0NTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274457),
('fb3a9dfb531958b0495eb950240c3273159dd7b6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2I5VWRaZ3hqTHJUNWw4VTQ4MXFmbFljUnpmWlhVWWExWkV6QWVNTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NTc7czoxOiJjIjtpOjEzOTkyNzQ0NTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274458),
('0c243184728c4a379d2b7a0aba05579c8a909334', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2Y4SlZ0QTAzenZFUFBENnA1VFdEcEhwRGRPa3Z0U2s5UTExUjJFcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NjA7czoxOiJjIjtpOjEzOTkyNzQ0NjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274460),
('25ad4e53930305760ebae9b7888b77c29c542af6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmNZWUc1VDRLYTdUSVh2alBwaVlJYnhtU0FmTTZGSGRwQmZMRjQ3SSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NjE7czoxOiJjIjtpOjEzOTkyNzQ0NjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274461),
('4abbf62df0e8aca9b81bea5d73c5d53879d8e9e0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT2hMQUhPVUZZUjFKUHJleDZJQkNydlJYNXB4b2tvTEFER01YMHNBQyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NjI7czoxOiJjIjtpOjEzOTkyNzQ0NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274462),
('e28f93cc50fb301d4df194e23fa4ed3e83b0bc64', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWEg3TTVYa21RcDFnSXpKOWRHcUtUcmwwcTJnQmZsQVpkdzdqck5ieCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NjM7czoxOiJjIjtpOjEzOTkyNzQ0NjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274463),
('fd32b90de68726c228301e0158663633915e6263', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicjBLR2tQU3diaHBGSnlWOEhtOEdvTkVkcUVwNXFucFpyYXU2ODQ1QSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NjQ7czoxOiJjIjtpOjEzOTkyNzQ0NjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274464),
('7c25f0d8bb2dac03147d4d370f3c7994c679d995', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT2xtc2lZak9KckptQlJPWmRWeTNQQTJvR1NrSDNTTm82MzJTVDNVWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0NjY7czoxOiJjIjtpOjEzOTkyNzQ0NjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274466),
('968c84d533cc17cbbc5de173a19841a27e986061', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGtoV2d1WWY5VDBjM2tIMVAwM0tSQkNvdld4RktVeXZ5MmpEVmtJZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0Njg7czoxOiJjIjtpOjEzOTkyNzQ0Njg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274468),
('d82da702df05d029a4663b67d6115511cfb53f97', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTG9SMDdOckY3cEdhWjV6T2RWRGhreGQ1QnYyWHJ0TmJJZERDTHRENyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQ0Njk7czoxOiJjIjtpOjEzOTkyNzQ0Njk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274469),
('cd628e854cdfb6b9b76be7b23e3cb2c5613cc6bf', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiazlmS1JPSnJEMElMbzB6ZUJlTlVjREVPakt4NTRPeFhJVUVBeGx5RiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNDY7czoxOiJjIjtpOjEzOTkyNzUzNDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275346),
('9bcf8c59b7581191f9e0fcd6f7f6d774fd7c432a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN3ltNGxrNmx2bTJaTWE3ZnVOR2RsUHBhZFdranRmZ1gzblltN1A0TiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNTI7czoxOiJjIjtpOjEzOTkyNzUzNTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275352),
('6ab212e5507e1a749c96a2f1cb4bc490840c9f6b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHhzYTVEYnJrMWpXV3dTMldkbWw2RktkMVlHNndWc084b2sxWmVJSyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNTQ7czoxOiJjIjtpOjEzOTkyNzUzNTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275354),
('69ddcc4f56245843a1cd531e8a8905b483f0d6c4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGY2eXhadkRPbnVNd1hsTDl2bnBFd2czSkNUeWVUVXFuVEVWZ1UwcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNTg7czoxOiJjIjtpOjEzOTkyNzUzNTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275358),
('c071f0dd27d56ff6ea03c1ee28bb53f340700ce9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHdxREpMenRVSU00RjlacEVFdjF2U0t2VnB4ZDgwRWJ6UEY0dVlJcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNjA7czoxOiJjIjtpOjEzOTkyNzUzNjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275360),
('2d531e1a83b66cde5a7ba108e5176aea0ad66d05', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTTFFUWl4R05Jc09ENUEySUdnSWFRU1VBellCWlg0SERRNUEwOHZVSSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNzk7czoxOiJjIjtpOjEzOTkyNzUzNzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275379),
('ebc9d461c0c59fa9c1a13a9a6b0f98c53a4a4e97', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnp6MjhqYmVoMmtsaDQ4Y2ZmTzVGSkw1MjRnQUpSTFRkN1g3ZlJkYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzUzNzk7czoxOiJjIjtpOjEzOTkyNzUzNzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275380),
('18f9eeaddd68bcf144fbd68d6337ba37b799af91', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid2xPY2JUTGNYS3lkUnU4Q0VmQlVaem9xUmdlZTVyU3BlWE8ybTl4YiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzU0MDA7czoxOiJjIjtpOjEzOTkyNzU0MDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275400),
('7867eabb751a01a82f542192633ce5d829295966', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic0xJdUQzS2VVbHI0ME1UdXBjMURqZ1BENDlsTUdFb24wb1lYUWxXSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzU0MDY7czoxOiJjIjtpOjEzOTkyNzU0MDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275407),
('739b49353a7fd8d72d34981f9156589e93f0969d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTk0cnBocHZsVWkyZkVzYkkzZW5RMGd1QmZ2UVZRRE5rZzhPYkNWRiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzU0MTE7czoxOiJjIjtpOjEzOTkyNzU0MTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275411),
('9d18cafc7cbd20ace747805b708635e188513f89', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicm1hNUNHSEo5U0R2Ym1IZFNPcjc4VUNWNUdLbHY2UDNEeFRwUG9CMiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3NTY2NTtzOjE6ImMiO2k6MTM5OTI3NTQxNDtzOjE6ImwiO3M6MToiMCI7fX0=', 1399275665),
('662c841caa7e0f45c3e4980a7696fb64cbd4b605', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoianF0allIRjdXTEpXZHZHQ1JKQ0FhWWJVYnJoWXNnYVRZOFpXdGdSTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzU0MjA7czoxOiJjIjtpOjEzOTkyNzU0MjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275420),
('daab1d29b2290f2ae2bf6d5e7bfd0283b89c0066', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV0hMcXZqMHUyWVNxaFdNVVloakRuU1A5YU1Db2RtYjRuMVVWMEtmbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzU0NDQ7czoxOiJjIjtpOjEzOTkyNzU0NDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399275444),
('141568197a03aaf4d2ea8f5e2cdbf56cdc747140', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMU14WHlXR3ZYTWlZVlV1djUxeFBNWHhkcWZvbHdoRTdEVXdneTU2OCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0MDg7czoxOiJjIjtpOjEzOTkyNzY0MDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276408),
('0256be29e40330f8e766dfdce57ac41b618588b3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ25YZDZXMlUyVmt6QkRiSGV2RkVtZWtieDlxNnRhbmxnQ3pVSXp6YiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0MDk7czoxOiJjIjtpOjEzOTkyNzY0MDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276409),
('d64d44b2478e8a3fa1ab0442714d6aeb40615d27', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiejl5ejA1ZTlpaFVYRFBscWNIUlphSjVhSFJ1czlEMXZGd0g1SDFPTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0MTI7czoxOiJjIjtpOjEzOTkyNzY0MTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276412),
('544204f85490a09822bd86dbad3816866a56a945', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTcyNnlUZWwxcGJuMm16QVdJc3ZlOWRRUWlRQjhpSm5DQXh2WklkZiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0MTM7czoxOiJjIjtpOjEzOTkyNzY0MTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276413),
('489712cad05272e765feb9b78ff63d8efaae6e9c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibDFwQmFSSFV6dXRIdlZlS2lVWnZyeW9jVVBVVmtJdFpONGRyTVYxcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0ODQ7czoxOiJjIjtpOjEzOTkyNzY0ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276484),
('9d57ab35d1d7c69adc7e98a5e8940c7945c4219e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidEpRVk8xN3h0a3prMUFrYXpTMjJZanNib2RCM0djTTczcXRMSlVZaCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0ODc7czoxOiJjIjtpOjEzOTkyNzY0ODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276487),
('5b471fb8b1ad79613006867cc42d3314452b5f94', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiem84elNBZ0RHWVVBY2VSVHhYZ2ZlSG4zdVhiSTJjbTNKRFZoVnlWRiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0OTA7czoxOiJjIjtpOjEzOTkyNzY0OTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276490),
('34fd19661c8c59e8ecf19cd9e16c3f7214046108', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYXFaZGo3YVBZTVlTdDU4RWRZZVFRN3lVQkgwUzNvTGp6ZkZaTW42YiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0OTE7czoxOiJjIjtpOjEzOTkyNzY0OTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276491),
('4894d387fb790600c4801457a3125ce3bad78a60', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRWg3QXdGbzE5anVLNnk5d3RVUDNmaEtMeW5Gb0VSNjd6MVlPT1FPbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY0OTM7czoxOiJjIjtpOjEzOTkyNzY0OTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276493),
('f216855b2c452d827739e3045a0712c80d5f5cbc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieWRwdFozaDlhZGVqWmROVmpZbWQ3RFZyYnRwY1FzaGp5ZFFZdUVvZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY1MDk7czoxOiJjIjtpOjEzOTkyNzY1MDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276509),
('cb8b570703cdf54993dc6e9e1be743d13c4ffa01', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHIzU1NEUWpZRVZobTdPM2Jhem9QZlZYUnl0a0JjWVBBdkl1ekxzRiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY1MDk7czoxOiJjIjtpOjEzOTkyNzY1MDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276509),
('22b51a9b5ddbf2dc87b3afbe3ffbe54c079450a0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkFtT0Z1a090YUhUS2RjT1BiRE5HV3IxdGlCSjFNTEtKdndHYTlFZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY1MjI7czoxOiJjIjtpOjEzOTkyNzY1MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276522),
('20fe32bce2b85925233b894390e1f38738fb036c', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaHJ4M0F1OHpTeGg4N0gzZllkazFFeHNueldzS1FuTHhhTHRhZjlBViI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIxIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5OTI3NzAzMDtzOjE6ImMiO2k6MTM5OTI3NjU3MTtzOjE6ImwiO3M6MToiMCI7fX0=', 1399277030),
('93d4bc9222e94078e68230dd008619c4b27cc0b9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieGFFM3phM0FHVXNhYWl2Q08wZXpOQUgzR2w1bWZzSzBIUFlJNk5rMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY2MDM7czoxOiJjIjtpOjEzOTkyNzY2MDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276603),
('d741c6c3cfd2ae418b38d3a9ba58762968d03488', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVZMMGNRUmNlWmxNcmtpZFUyMTBTeDVkTDRvbUtMOW1taVZUcUN0SCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY2MTA7czoxOiJjIjtpOjEzOTkyNzY2MTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276611),
('feb35695ad960ea081074d14c34fc4607f09560c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNEhEbGhBVTZZZEJGZ3pNT0ppUktDUWFlckdXY0VmTlc1UEIxWTY4UCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY2MTA7czoxOiJjIjtpOjEzOTkyNzY2MTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276611),
('a9bf86b3e720687d4a559d32e3f48143b41f1d1d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRE1CZEF0c3E4Z2RKSXQyMFBxdFVmT0pJTjBzVWZyblk3YTdVbVhBciI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzY2MTY7czoxOiJjIjtpOjEzOTkyNzY2MTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399276616),
('dec53323221f71c0c639260b238b423c79f5879c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSkVjTEFKOUF5WDBFYldpT1A2aEt1ekpYRXZkMjZCTXJxaWlYYWNqdiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQyNzI7czoxOiJjIjtpOjEzOTkyNzQyNzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274272),
('1ca0e45dd03bfe10b50a428bed11eefd9a326d09', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1l4YXZodlpoZjRVQkJpVHRnc2pMWlBod3ZUZFNOV2NDemkyalQ0TiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQxNTI7czoxOiJjIjtpOjEzOTkyNzQxNTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274152),
('919d68106b33ee580550ded1b9ea7a35342f3b85', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiclZKTm1SUkZLZklWdThvRkd4UUhLWVNTd1R5d1JSWTFOT3R5VVpLcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTkyNzQxNDk7czoxOiJjIjtpOjEzOTkyNzQxNDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1399274149);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `templates`
--

DROP TABLE IF EXISTS `templates`;
CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `static` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `templates`
--

INSERT INTO `templates` (`id`, `name`, `content`, `static`, `created_at`, `updated_at`) VALUES
(1, 'default', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'catalog', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'news', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'articles', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'category', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'product', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'manufacturer', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'index-page', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="row content max-width-class" role="main">\n		@include(''templates.default.sidebar'')\n		<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">\n			@yield(''content'')\n			@if(isset($content))\n				{{ $content }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-29 09:45:45', '2014-04-29 09:45:59'),
(9, 'investors', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container investors">\n		<h1>{{ trans(''interface.PAGES_FOR_INVESTORS'') }}</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			@if(Auth::guest())\n				{{ Form::open(array(''route''=>''signin'',''role''=>''form'',''class''=>''auth-form'',''id''=>''signin-secure-page-form-2'')) }}\n					<div class="form-header">{{ trans(''interface.FORM_SIGNIN_SECURE_2_HEADER'') }}</div>\n					<input type="text" name="login" placeholder="{{ trans(''interface.FORM_INPUT_PLACEHOLDER_LOGIN'') }}">\n					<input type="password" name="password" placeholder="{{ trans(''interface.FORM_INPUT_PLACEHOLDER_PASSWORD'') }}">\n					<button type="submit">{{ trans(''interface.FORM_SIGNIN_SUBMIT'') }}</button>\n				{{ Form::close() }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 06:06:28', '2014-04-30 16:03:45'),
(10, 'contacts', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container services contacts">\n		<h1>Контакты</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:600px;"><div id="gmap_canvas" style="height:400px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(40.7056308,-73.9780035),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(40.7056308, -73.9780035)});infowindow = new google.maps.InfoWindow({content:"<b>УПК</b><br/>ул. Красных зорь, 123а<br/> Россия, Ростовская область, пос. Успенский" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, ''load'', init_map);\n            </script>\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 11:15:17', '2014-04-30 11:19:54'),
(11, 'request-for-access-to-documents', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container investors">\n		<h1>Заявка на доступ к документам</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			<div class="apply-form">\n			{{ Form::open(array(''route''=>''request-to-access'',''role''=>''form'',''id''=>''request-to-access-form'')) }}\n				<table class="apply-table">\n					<tr class="apply-row">\n						<td><label for="name">ФИО контактного лица</label></td>\n						<td><input type="text" name="name" id="name"></input></td>\n					</tr>\n						<tr class="apply-row">\n						<td><label for="organisation">Название организации</label></td>\n						<td><input type="text" name="organisation" id="organisation"></input></td>\n					</tr>\n					<tr class="apply-row">\n						<td><label for="email">Адрес@электронной.почты</label></td>\n						<td><input type="text" name="email" id="email"></input></td>\n					</tr>\n					<tr class="apply-row">\n						<td><label for="phone">Контактный телефон</label></td>\n						<td><input type="text" name="phone" id="phone"></input></td>\n					</tr>\n				</table>\n			<button class="apply-btn">Отправить заявку</button>\n			{{ Form::close() }}\n			</div>\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 11:23:04', '2014-04-30 11:29:35'),
(12, 'news-on-main-page', '@if(isset($news) && $news->count())\n@foreach($news as $new)\n<div class="block-w-logo" data-date="{{ myDateTime::getDayAndMonth($new->created_at) }}"></div>\n<div class="block-title">Новости</div>\n<div class="block-text">{{ $new->preview }}</div>\n@endforeach\n@endif', 0, '2014-04-30 14:47:11', '2014-05-05 08:03:25');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Администратор', '', 'admin@uspensky-pk.ru', 1, '$2y$10$1hU9pK9AlpiZJzPGyET./.pUqIv2YJzbBTbMG432Tw2t6g3350ehS', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, 'GDFxo5qczOnAEsftdxB6AzCZeGhFaHE4FLS6YBvQa8yfh2h1GG8Z5LDCiXMy', '2014-04-30 05:05:40', '2014-04-30 17:22:06'),
(2, 'Пользователь', '', 'intranet', 1, '$2y$10$3vJkKa6SjZNHYJ/pOjoWMewssEQezo5iA5YjEiuR60GyqKHIq6gO2', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, 'wnA1Jj7ICSJb3CCwvi10FLfIwTJv4jmkLAMszGcCr1uHjKsX2Uhn8iZPyipp', '2014-04-30 05:05:40', '2014-05-05 06:50:51');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
