-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 30 2014 г., 14:58
-- Версия сервера: 5.5.35
-- Версия PHP: 5.3.10-1ubuntu3.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `uspensky-pk`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalogs`
--

DROP TABLE IF EXISTS `catalogs`;
CREATE TABLE IF NOT EXISTS `catalogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `fields` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_parent_id` int(10) unsigned DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `categories_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories_group`
--

DROP TABLE IF EXISTS `categories_group`;
CREATE TABLE IF NOT EXISTS `categories_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `category_product`
--

DROP TABLE IF EXISTS `category_product`;
CREATE TABLE IF NOT EXISTS `category_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_product_category_id_index` (`category_id`),
  KEY `category_product_product_id_index` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'user', 'Пользователи', 'intranet', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'moderator', 'Модераторы', 'moderator', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `group_role`
--

DROP TABLE IF EXISTS `group_role`;
CREATE TABLE IF NOT EXISTS `group_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_role_group_id_index` (`group_id`),
  KEY `group_role_role_id_index` (`role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `group_role`
--

INSERT INTO `group_role` (`id`, `group_id`, `role_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 2, 6),
(13, 2, 8),
(14, 3, 3),
(15, 3, 1),
(16, 3, 2),
(17, 3, 6),
(18, 3, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `group_user`
--

DROP TABLE IF EXISTS `group_user`;
CREATE TABLE IF NOT EXISTS `group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_user_group_id_index` (`group_id`),
  KEY `group_user_user_id_index` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `group_user`
--

INSERT INTO `group_user` (`id`, `group_id`, `user_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `paths` text COLLATE utf8_unicode_ci,
  `attributes` text COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `images_module_id_index` (`module_id`),
  KEY `images_item_id_index` (`item_id`),
  KEY `images_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `default`, `created_at`, `updated_at`) VALUES
(1, 'ru', 'Русский', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_19_104802_create_users_table', 1),
('2014_01_19_104821_create_groups_table', 1),
('2014_01_19_104830_pivot_group_user_table', 1),
('2014_01_19_104934_create_roles_table', 1),
('2014_01_19_104954_pivot_group_role_table', 1),
('2014_01_19_105008_create_pages_table', 1),
('2014_02_08_123907_create_languages_table', 1),
('2014_02_10_125947_create_galleries_table', 1),
('2014_02_10_130103_create_photos_table', 1),
('2014_02_17_105422_create_settings_table', 1),
('2014_02_18_133757_create_news_table', 1),
('2014_02_20_094843_create_templates_table', 1),
('2014_03_03_201446_create_modules_table', 1),
('2014_04_08_142125_create_session_table', 1),
('2014_04_10_085237_create_permissions_table', 1),
('2014_04_10_090423_pivot_user_module_permission', 1),
('2014_04_14_101731_create_articles_table', 1),
('2014_04_18_103249_create_catalogs_table', 1),
('2014_04_21_133950_create_categories_group_table', 1),
('2014_04_22_070606_create_categories_table', 1),
('2014_04_22_143526_create_products_table', 1),
('2014_04_23_103825_create_images_table', 1),
('2014_04_25_101239_create_category_product_table', 1),
('2014_04_25_112828_create_manufacturers_table', 1),
('2014_04_28_115029_create_products_attributes_group_table', 1),
('2014_04_28_115149_create_products_attributes_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `permissions` varchar(255) COLLATE utf8_unicode_ci DEFAULT '[]',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `url`, `on`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'seo', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:44:57'),
(2, 'news', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'articles', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'pages', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'catalogs', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'users', 0, '[1,2,3]', '2014-04-29 09:43:10', '2014-04-29 09:45:09'),
(7, 'downloads', 1, '[3,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:11'),
(8, 'statistic', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'galleries', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(10, 'languages', 0, '[1,2,3,4]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(11, 'settings', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(12, 'templates', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `module_permissions`
--

DROP TABLE IF EXISTS `module_permissions`;
CREATE TABLE IF NOT EXISTS `module_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `module_id` int(10) unsigned DEFAULT NULL,
  `permission_id` int(10) unsigned DEFAULT NULL,
  `value` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `module_permissions_user_id_index` (`user_id`),
  KEY `module_permissions_module_id_index` (`module_id`),
  KEY `module_permissions_permission_id_index` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `sort`, `template`, `title`, `language`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `publication`, `created_at`, `updated_at`) VALUES
(1, 1, 'news', 'Регистрация компании-инициатора проекта', 'ru', '', '<p>\n	Веб-интегратор <strong>DEFA</strong> представляет новый сайт для  международного аэропорта                             Внуково. Столь  сложный проект для нас - лучший показатель                              профессионализма и слаженной работы команды!\n</p>', 'registraciya-kompanii-iniciatora-proekta', 'Регистрация компании-инициатора проекта', '', '', '', 1, '2014-04-29 11:20:05', '2014-04-29 11:20:05'),
(2, 2, 'news', 'Официальный старт проекта', 'ru', '', '<p>\n	Веб-интегратор <strong>DEFA</strong> представляет новый сайт для  международного аэропорта                             Внуково. Столь  сложный проект для нас - лучший показатель                              профессионализма и слаженной работы команды!\n</p>', 'oficialnyiy-start-proekta', 'Официальный старт проекта', '', '', '', 1, '2014-04-29 11:20:25', '2014-04-29 11:20:25'),
(3, 3, 'news', 'Официальный старт проекта', 'ru', '', '<p>\n	Веб-интегратор <strong>DEFA</strong> представляет новый сайт для  международного аэропорта                             Внуково. Столь  сложный проект для нас - лучший показатель                              профессионализма и слаженной работы команды!\n</p>', 'oficialnyiy-start-proekta', 'Официальный старт проекта', '', '', '', 1, '2014-04-29 11:20:47', '2014-04-29 11:20:47');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `in_menu`, `sort_menu`, `template`, `language`, `name`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `content`, `publication`, `start_page`, `created_at`, `updated_at`) VALUES
(1, 0, 40, 'index-page', 'ru', 'Главная', '', 'Главная', '', '', '', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	          Инвестиции в уникальные технологии\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			 [news path="news-on-main-page" limit="1"]\n		</div>\n		<a href="/news" class="block-hover">\n		<div class="block-hv-text">\n			          Все новости УПК\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				          Инвесторам\n			</div>\n			<div class="block-text">\n				                                   Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс».\n			</div>\n		</div>\n		<a href="/investors" class="block-hover">\n		<div class="block-hv-text">\n			          Подробнее\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				          Контакты\n			</div>\n			<div class="block-text">\n				                                   г. Ростов-на-Дону,<br>\n				           ул. Текучева, 162, офис 302<br>\n				           тел. +7 (863) 280-66-56, <br>\n				           E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		<a href="/contacts" class="block-hover">\n		<div class="block-hv-text">\n			          На карте\n		</div>\n		</a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n</section>', 1, 1, '2014-04-29 09:52:33', '2014-04-30 14:47:52'),
(2, 0, 33, 'default', 'ru', 'О компании', 'about', 'О компании', '', '', '', '<main class="container about">\n<h1>О компании</h1>\n<!--<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>-->\n<div class="content">\n	<div class="desc">\n		                         В России очень мало компаний, которые официально занимаются утилизацией                     и переработкой «темных нестандартных нефтепродуктов». Счет производств,                     которые профильно занимаются переработкой подобных нефтепродуктов                     и имеют лицензию на переработку идет на еденицы по всей стране.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                         Специалисты компании — инициатора проекта уже более 3-х лет занимаются исследованиями рынка «темных нестандартных нефтепродуктов», практической реализацией мелких проектов по переработке обводненного мазута.<br>\n			     В процессе накопленного практического опыта, глубокий анализ показал, что на Юге России нет ни одного официального производства по переработке вышеуказанных продуктов несмотря на то, что в России очень много предприятий, которые имеют потребность в заключении долгосрочных контрактов на утилизацию и переработку получаемых ими «темных нестандартных нефтепродуктов», но в силу отсутствия таковых, вынуждены утилизировать НТН, используя различные незаконные схемы сбыта, что влечет за собой огромные риски и снижение рентабельности.<br>\n			     Благодаря такому практическому опыту родилась идея создания <strong>универсального комплекса</strong> по переработке нестандартных темных нефтепродуктов.<br>\n		</div>\n	</div>\n	<h2>                     История                 </h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>                             Зарегистрирована компания                         </h3>\n		<div class="hist-desc">\n			                                  26.12.2012 в целях реализации возникшей идеи была зарегистрирована компания Общество с ограниченной ответственностью «Успенский перерабатывающий комплекс», которая в настоящий момент является инициатором проекта по строительству перерабатывающего комплекса.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="theme/img/icons/rocket.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Официальный старт проекта                         </h3>\n		<div class="hist-desc">\n			                                 В сентябре 2013 года проект официально стартовал, и начались первые шаги по реализации данного проекта.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Включение в реестр инвестиционных проектов Ростовской области                         </h3>\n		<div class="hist-desc">\n			                                 7 Ноября 2013 года в Министерстве промышленности и энергетики Ростовской области состоялось совещание рабочей группы по вопросам развития инвестиционной деятельности. По результатам указанного совещания инвестиционный проект ООО «Успенский перерабатывающий комплекс» был успешно включен в реестр инвестиционных проектов Ростовской области, что позволяет в дальнейшем пользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>                             Предпроектные работы                         </h3>\n		<div class="hist-desc">\n			                                 В настоящее время проект успешно находится в стадии реализации на этапе предпроектных работ и большими шагами движется к заданной цели.\n		</div>\n	</div>\n	</li>\n</ul>\n </main>', 1, 0, '2014-04-29 10:39:11', '2014-04-30 13:12:57'),
(3, 0, 39, 'default', 'ru', 'Пресс-центр', 'news', 'Пресс-центр', '', '', '', '<main class="container news">\n<h1>Новости</h1>\n  [news limit="10"] </main>', 1, 0, '2014-04-29 10:41:30', '2014-04-30 14:39:37'),
(4, 0, 34, 'default', 'ru', 'Услуги', 'services', 'Услуги', '', '', '', '<main class="container services">\n<h1>Услуги</h1>\n<div class="content">\n	<div class="desc">\n		                       Настоящий проект предполагает производство следующих                     продуктов и оказание услуг\n	</div>\n	<div>\n		<div class="col-50">\n			<h2>Производство</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Битум</li>\n				<li>Бензин прямогонный</li>\n				<li>Судовое маловязкое топливо</li>\n				<li>Мазут</li>\n				<li>Керосин</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Услуги</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Перевалка газа</li>\n				<li>Перевалка битума</li>\n				<li>Перевалка мазута</li>\n				<li>Обезвоживание мазута</li>\n				<li>Фильтрация мазута</li>\n				<li>Понижение вязкости и застывания мазута</li>\n				<li>Переработка нефти</li>\n			</ul>\n		</div>\n	</div>\n</div>\n </main>', 1, 0, '2014-04-29 10:44:31', '2014-04-30 13:15:32'),
(6, 0, 19, 'default', 'ru', 'Карьера', 'career', 'Карьера', '', '', '', '<main class="container services">\n            <h1>\n                Карьера\n            </h1>\n            <div class="content">\n                <div class="desc">\n                    Уважаемые соискатели!\n                </div>\n                <div class="more-desc">\n                    <div class="more-desc-part">\n                    <p>Проведение работ по отбору кандидатов на замещение вакантных должностей в ООО «УПК» будет проводиться в 3 квартале 2014 года.\nЗа информацией о списках рабочих мест и количестве необходимых сотрудников, следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.</p>\n                    </div>\n                </div>\n                </div>\n            </div>\n            \n        </main>', 1, 0, '2014-04-29 11:04:34', '2014-04-29 11:04:34'),
(5, 0, 35, 'investors', 'ru', 'Инвесторам', 'investors', 'Инвесторам', '', '', '', '<div class="desc">\n	       Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс». Целью создания комплекса является организация многопрофильного производства по переработке нефти и нестандартных  темных нефтепродуктов, а также оказание большого спектра услуг в нефтяной сфере.\n</div>\n<div class="more-desc">\n	<div class="more-desc-part">\n		       Для организации финансирования  и управления размещением сертификатов участия на рынке капитала наша компания заключила контракт со швейцарской компанией <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a>. По возникшим вопросам, касающимся размещения сертификатов участия, просим обращаться в данную компанию.\n	</div>\n	<div class="more-desc-part">\n		       Для реализации проекта ООО «Успенский перерабатывающий комплекс» выпускает привилегированные сертификаты участия. Принятие участия представляет собой приобретение вышеуказанных сертификатов. Подробные условия изложены в эмиссионном проспекте. Для ознакомления введите логин и пароль.\n	</div>\n	<div class="more-desc-part">\n		      Чтобы получить доступ к загрузке эмисионного проспекта, <a href="/request-to-access">отправьте запрос.</a>\n	</div>\n</div>', 1, 0, '2014-04-29 10:45:30', '2014-04-30 13:22:40'),
(10, 0, 32, 'default', 'ru', 'Интранет', 'intranet', 'Интранет', '', '', '', '<main class="container investors">\n<h1>                 Эммисионный проспект             </h1>\n<div class="content">\n	<div class="desc">\n		                     Для ознакомления с эмиссионным проспектом, пожалуйста, скачайте файл по ссылке.\n	</div>\n	<div class="intranet-desc">\n		<a href="#" class="link-pdf">                         Скачать документ                     </a>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-30 04:07:23', '2014-04-30 12:27:59'),
(7, 0, 20, 'default', 'ru', 'Тендеры', 'tenders', 'Тендеры', '', '', '', '<main class="container services tenders">\n<h1>                 Тендеры             </h1>\n<div class="content">\n	<div class="desc">\n		                     Размещение информации  о работах, товарах и услугах, а также предварительному отбору поставщиков  товаров, услуг и подрядчиков, ООО «Успенский перерабатывающий комплекс» планирует  в конце 2 квартала 2014 года.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                     За информацией следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.<br>\n		</div>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-29 11:07:18', '2014-04-29 11:07:18'),
(8, 0, 30, 'contacts', 'ru', 'Контакты', 'contacts', 'Контакты', '', '', '', '<div class="more-desc">\n	<div class="more-desc-part">\n		                         Россия, Ростовская область, пос. Успенский,                         ул. Красных зорь, 123А\n	</div>\n</div>\n<address>\n<div class="s-phones col-40">\n	<a href="tel:+79283455454">+7 928 345 54 54</a><a href="tel:+79283455455">+7 928 345 54 55</a>\n</div>\n<div class="mails col-40">\n	<a href="mailto:email@gmail.com">email@gmail.com</a>\n</div>\n</address>', 1, 0, '2014-04-29 11:08:20', '2014-04-30 11:18:51'),
(9, 0, 38, 'default', 'ru', 'Карта сайта', 'sitemap', 'Карта сайта', '', '', '', '<main class="container about">\n<h1>                 Карта сайта             </h1>\n<ul class="sitemap">\n	<li class="sitemap-item"><a href="/">Главная</a></li>\n	<li class="sitemap-item"><a href="/about">О компании</a></li>\n	<li class="sitemap-item"><a href="/news">Пресс-центр</a></li>\n	<li class="sitemap-item"><a href="/services">Услуги</a></li>\n	<li class="sitemap-item"><a href="/career">Карьера</a></li>\n	<li class="sitemap-item"><a href="/investors">Инвесторам</a></li>\n	<li class="sitemap-item"><a href="/tenders">Тендеры</a></li>\n	<li class="sitemap-item"><a href="/contacts">Контакты</a></li>\n	<li class="sitemap-item"><a href="/request-to-access">Заявка на доступ к документам</a></li>\n</ul>\n</main>', 1, 0, '2014-04-29 11:09:32', '2014-04-30 14:39:02'),
(11, 0, 31, 'request-for-access-to-documents', 'ru', 'Заявка на доступ к документам', 'request-to-access', 'Заявка на доступ к документам', '', '', '', '<div class="desc">\n	                     Для ознакомления с эмиссионным проспектом, пожалуйста, заполните все поля формы. Мы направим вам логин и пароль на указанный адрес электронной почты.\n</div>', 1, 0, '2014-04-30 11:30:36', '2014-04-30 11:30:36');

-- --------------------------------------------------------

--
-- Структура таблицы `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `desc`, `default`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Создание', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'edit', 'Редактирование', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'delete', 'Удаление', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'publication', 'Публикация', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'download', 'Загрузка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'sort', 'Сортировка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catalog_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_user_id_index` (`user_id`),
  KEY `products_catalog_id_index` (`catalog_id`),
  KEY `products_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes`
--

DROP TABLE IF EXISTS `products_attributes`;
CREATE TABLE IF NOT EXISTS `products_attributes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `product_attribute_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `products_attributes_product_attribute_group_id_index` (`product_attribute_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes_group`
--

DROP TABLE IF EXISTS `products_attributes_group`;
CREATE TABLE IF NOT EXISTS `products_attributes_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'news', 'Управление новостими', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'articles', 'Управление статьями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'pages', 'Управление страницами', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'catalogs', 'Управление каталогами товаров', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'users', 'Управление пользователями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'downloads', 'Управление загрузками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'statistic', 'Управление статистикой', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'galleries', 'Управление галереями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'languages', 'Управление языками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(10, 'settings', 'Управление настройками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(11, 'templates', 'Управление шаблонами', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('f3644cd68f23b406e31df7b9a48e4e2aea50e0cf', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNDkwZkNmMVpMUFhSVW1NbDJldFZncTZPRnJsSHhXN25RU3RCOHRYNyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7czoxOiIxIjtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2OTg0NztzOjE6ImMiO2k6MTM5ODg1NDM0MjtzOjE6ImwiO3M6MToiMCI7fX0=', 1398869847),
('8ce89bde9d455b7b98e4d016e933595fd3e089bc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmlCMGtHWWdIMUVLTFl5Y0dXYkJFYjNoN1k4RkhCUmZ4MjMySm1oUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjcyOTI7czoxOiJjIjtpOjEzOTg4NjcyOTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867292),
('39b464b33924cc4f8f083b82da0b48f7cd70bcc2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaG4zSEZ5a25MdXNjNllVY2FEWVRFTUN6RHpXSXpKOWZmeHVTdG1RTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzU7czoxOiJjIjtpOjEzOTg4Njc1MzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867535),
('1d7e8cf3c49c453de5ccfd9de354550f7d88b544', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV041eEw4bDZKekladThlRmR3ZWYybThsZ0tYR1FteE9oR2FzQzFkZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzU7czoxOiJjIjtpOjEzOTg4Njc1MzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867535),
('25a4678055018c08dca898986fdbfcc467b185b4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV0JsekxLQ1ozam5ZaTJaeWZHa1BnSHR3RE15Z3huMjhsVUJtRDcxcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzQ7czoxOiJjIjtpOjEzOTg4Njc1MzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867534),
('66a967058006ec867d773b9bb3a0330cd159ce5f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibUR3SlpzdmRyOEcweDlqbXhEYllmUVNFM1RUN2ZtTmxVS1ZIbmtzVSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2MjkxMztzOjE6ImMiO2k6MTM5ODg1OTQ4MztzOjE6ImwiO3M6MToiMCI7fX0=', 1398862913),
('9d6f7fc9baa506009c35d5094c8e4fe35e7f151b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibXBQRTdETXBBWWNRRUdseTBWVGp1bHF3dEdhdFROakFIVkdCOVVTeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI2Njg7czoxOiJjIjtpOjEzOTg4NjI2Njg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862668),
('4b1fe4541881539a252f2a5cf3a076943fe6cbf2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTE13SFozSW5ucW1QYmRrdFg0aE5nQWJjMzZGY0RJZFlxZlNqelZHTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI2Njk7czoxOiJjIjtpOjEzOTg4NjI2Njk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862669),
('6eeea0f0e0c8d88e1e744006e47b3bb6c2799726', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib0JsZWd6R2ttYXZvNWR1c0N6M3BMQkRneG9zU05rTXMwenNlQndsZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI3MzE7czoxOiJjIjtpOjEzOTg4NjI3MzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862731),
('af591cc9cd784bed2ce7e526930b9649210bc860', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicXNQbkFSVmtQbzk4TVA1NVRJMFNoWFF1QUtFSThoMVA0WWZPeTIwRCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI3MzI7czoxOiJjIjtpOjEzOTg4NjI3MzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862732),
('42abc0da3ee33a3c16fe5a6e88b0cf647b21444f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzlHcnhZYklZWWNYN3V1Y3M4eGZSN3pnUFA2Z2JWSElKZlpTa21HSSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI3NjE7czoxOiJjIjtpOjEzOTg4NjI3NjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862761),
('4371ccbd72eb74a4aed5d6656938d73051c64fa7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaUc3dGRQeUpQVnVVelV2bk5xalZUWnpBM0RDYk54NFpETlVVUjFnNSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI3NjI7czoxOiJjIjtpOjEzOTg4NjI3NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862762),
('993194d21247866b79d8a2fa8c657e2eac87b469', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUoyTFc2SVBsZHh1UUJ0aWJ6ZU1MdXpheEpwS2c2b1loMWpqaE4xZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI4MDA7czoxOiJjIjtpOjEzOTg4NjI4MDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862800),
('5c0e0ffedd7557437bf7c43cd5a8a6a6cad76ab9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaTBReTFQUThnNUFXQ3k2UDk4TzVJVm5nQVBHcEkyWFVZazJBTXVVNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI4MDI7czoxOiJjIjtpOjEzOTg4NjI4MDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862802),
('76b1ca73e3a040f7e78c15563cc1f05e13d681d0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNFJERUlxbUFIRHNlRkQ3YzRDcThvc1djSmFtNmNtSFZBREdnemhVUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI4Nzc7czoxOiJjIjtpOjEzOTg4NjI4Nzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862877),
('f9a2e231d883611209be12534412c99df852ec03', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiczU1alNxVHNZaENGUm9RU0NSeE96UXc5T0FQYVVrSWdsdDZnZGJEeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjI4Nzg7czoxOiJjIjtpOjEzOTg4NjI4Nzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398862878),
('20277f495d7fcb7fb389b984524c1817104c1fc5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicjNqR1VOWVZEOURIN3JkU05wYVY3ejBJRWVZTEZXaWJmd3RBQU5vMyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMwMTA7czoxOiJjIjtpOjEzOTg4NjMwMTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863010),
('f30538be614af4ccebefc10b8b408c9c9d18dca6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaEg5eWpFZmtSZG9CSDZkUDNTVUcxekhiaTRwQ1VGbzFZMmdING16VSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMwMTE7czoxOiJjIjtpOjEzOTg4NjMwMTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863011),
('fb801c63daddc4d439e7de66d0940c5a7f2e7f09', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3VLMExKTGExZW5kNGJUSXBxSTc3Z3hUOHFsRGNHNWhxNGJxMkdoaCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxMTI7czoxOiJjIjtpOjEzOTg4NjMxMTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863112),
('9759ade9c692230af60c714d0705219c9ea4750b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkJaWnZ4Z3N0TXRMaVNrRDczMVFoSE9vZEN3WEJxV3A2aHBPd0ZxYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxMTM7czoxOiJjIjtpOjEzOTg4NjMxMTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863114),
('cce0b302e55146746bcfab9310ef8e0a0d7b1ae6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVFBLVWUzM1drdVNhMUVYczRCSVZFWWlCY1ZidDJ6bTZNZXR6SjdWcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNTM7czoxOiJjIjtpOjEzOTg4NjMxNTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863153),
('86e1c63c0612454c7fc735f5ceb1a003250bba42', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia1NRME92YXNRZm9hWnlKOWxVOXRnTHk1MjZEVDNZVFgxWWEyNU9QdSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2NzkwMjtzOjE6ImMiO2k6MTM5ODg2MzE1MztzOjE6ImwiO3M6MToiMCI7fX0=', 1398867902),
('bf356353d220cf829e8f050677c3b53fd91fd5bc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHVlWlJPbmtsdWY4R3pkQXFaOGY2MFFuUHRLZ09pWm43dURSUmk3dSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNTQ7czoxOiJjIjtpOjEzOTg4NjMxNTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863154),
('a1e034ffdfe293ba99bd1d5990ac5ef7b8d687f0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkVhWnppSGJyUVp5RVBIM3RGTzZjaWY4UFN3OUdwOWVjTTVseGNRYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNjA7czoxOiJjIjtpOjEzOTg4NjMxNjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863160),
('84dfada64de06a9368e7fd227ed639083fa2e3eb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS0NrMWVSZEpKUWQ3MEdGaW4wRW9TOVY5T1dlbzZOb3RWQlFtMW1tbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNjA7czoxOiJjIjtpOjEzOTg4NjMxNjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863161),
('cf8d4e42340b0dbf96d934623437af3614fdd1bd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVZPNmtDWlJFNUZObDNXYmppSVptcWRacjhNWmdaakNJVEN6NGhmOSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNjI7czoxOiJjIjtpOjEzOTg4NjMxNjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863162),
('07c70c7b777c997ea085063f354921d7e3595eab', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGVSdFJWOTlRQTFnemVjd3NLZGhGRERaMUFvb0Z1SDM3c3V5ZWpIciI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNjM7czoxOiJjIjtpOjEzOTg4NjMxNjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863163),
('db549048b9fdbce6b2f61113bc4c67253178f3c4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTVRbmpGQTJQVEw2UVVhSzFabFZCdW9hZDhTbjZkd3VIakZqcWhlQSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNjU7czoxOiJjIjtpOjEzOTg4NjMxNjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863165),
('dd89362cf7cb46f2cbf074b29b4fc088fc5a213f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiamlOUllyVTRWRFhTdUU3dnE3YktNZVRPd0l6T3B6QlRJb1BmT1BRVSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNjU7czoxOiJjIjtpOjEzOTg4NjMxNjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863165),
('4c8585975a175f29b0ba568bbef6656fc478f6df', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVI4NDlkaFVyMUhEOFV3RmdvWFpSOVNHUVl1SkZQaThTOTZ6bW1VZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxNzQ7czoxOiJjIjtpOjEzOTg4NjMxNzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863174),
('810dcab7cbe57f4ecf2104b69ecf959cb1675b3e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUlLTnNDWFk3YVNkUmN4YmZJdTF0R2kwZ09wQ2tkbUFXN0tWeFFEeSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMxOTA7czoxOiJjIjtpOjEzOTg4NjMxOTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863190),
('f22c1e42bbfd068ada04db7e92fc39fba6b80ade', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjhZdGdhN002NzF2U2FaTloxUzhzYkdUaFJ4d3dqZVdYaWNYWXNxRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyMDk7czoxOiJjIjtpOjEzOTg4NjMyMDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863209),
('d76fe9c50b28505544db4cae09e46dc0a9f1730f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDhOVGlZM1cxaEpEYVlsWW53amFqMkhMZWNjWkt1aDJZR1hkdk96NyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyMTk7czoxOiJjIjtpOjEzOTg4NjMyMTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863219),
('ff148c3efb239fba539fec404a55c3134b9b0e4b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTlrbVZXa0xjNGVha1FFdFhGRWZNVFhPQW9yblV4ejd1UkJEcWhQOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNDQ7czoxOiJjIjtpOjEzOTg4NjMyNDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863244),
('e8a40bfcba4d1221246b7a07b68e9b87c2e3383f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWWZFN3ppdFBHZ0ZycVQ3V1dkVlk4d1dYNWJMQWRKck1sT2YxU2xtQSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNTM7czoxOiJjIjtpOjEzOTg4NjMyNTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863253),
('695d5f182d932f6db74ff06c578a56956a713821', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3JRZkQ3T21ld3pFSnFiZERHNll6VlBJQ0JyTnpOM2ZQNUMyZHBtMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNjA7czoxOiJjIjtpOjEzOTg4NjMyNjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863260),
('91d6c1469622505fe75d78141899c094f00172fc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieVd3cmxkN3JOR1JFb21hYkliMkY2a1pkRFhlR2dLMThmcjBoRkdEdiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNjM7czoxOiJjIjtpOjEzOTg4NjMyNjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863263),
('7710c730bdcc8daa9610ca440be514ca2a2394ee', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidzJJbTBqZDJ4RkFUN3FueGtRNmhwT0VjSHFMWktRVDlIRXR6emlFcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNjc7czoxOiJjIjtpOjEzOTg4NjMyNjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863267),
('2326818b8522c03148b2858695286f6d8b5287ff', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQWhOQjVmOUNKa210MXpYYlZ5d1poaTlXSldxQjhkM1RDNnZWZUp1TSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNjk7czoxOiJjIjtpOjEzOTg4NjMyNjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863270),
('2a4e19373923aea727672e490845d4dc99dfe2b2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlk3M2NnWkZERDRoVmx1UDhEallOVVNMckxPMFBTWkZOYWU4OXJ0WCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMyNzI7czoxOiJjIjtpOjEzOTg4NjMyNzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863272),
('63f384a89c5d4955d3818d2c229b371c0cc67d55', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkFJdmhLdUJ2RnNWeTlsVnhUYVY2WXRRQ3gxM2w1VlZ6VFVOcEQxcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc4NjI7czoxOiJjIjtpOjEzOTg4Njc4NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867862),
('755a269350e755f008ca8af227f8a6e85489a721', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDFLbnpHaWxKcTg5RFhRUGxIZ0hFaE84SElCNjZTb0tFcThPRUZWayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjMzNjk7czoxOiJjIjtpOjEzOTg4NjMzNjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863370),
('cf0c8f08e2c3995476d72969e424468fff42d5ec', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVBmektsSTVJeDZNNDVrdkF5b3BaMEFXNGFXc1hsd3VHbUFNaXlkTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM0MTM7czoxOiJjIjtpOjEzOTg4NjM0MTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863413),
('5bb71cb5c0dfabf4afaa35e7897b07e993b0ba4b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSDRKbWxKc3JNOVoxTjExeUxFcEd6RVRDUnFiOW5VZUJRYzJobFNyWCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM0MTQ7czoxOiJjIjtpOjEzOTg4NjM0MTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863414),
('0a09de2c7c949442253129f2b27ea8c81e111939', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2RoejlWWkV6RzZSMndyRHkyMlRreVo5RTlFU2tqT2F3SGU5T216OSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM0MTU7czoxOiJjIjtpOjEzOTg4NjM0MTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863415),
('698207373e0fcbc18188e2d8fd42e031116c653e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYk9pRm1XV2Y2U1IyNExXdkdmdm9aNGF2MGJzcHg0RHdpeFhGdHByciI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM1ODQ7czoxOiJjIjtpOjEzOTg4NjM1ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863584),
('a62c57d897d0fb8440d5bad3f038fa88c78766ec', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS0tPMzJ0ekQzU0UxOVdEajhGaXVKSDZHTThNd2dhOGp6ODRycWVsWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM3Mzg7czoxOiJjIjtpOjEzOTg4NjM3Mzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863738),
('dac8ca75c6b0c17022ef5835edcfaf5b17092130', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNms1Z2xXQ3hQYnRtQ3hPR3NycHo1NnpiU2psQUJHQm9lZ2hSbU1nMiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM3NDE7czoxOiJjIjtpOjEzOTg4NjM3NDE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863741),
('f20fe3637594c847d5c9d93f4780dca73a8d9224', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibXdKaTU3c1RlNElMMFVVblJiNUE5TzdMRzl5TU9jMEJHaEdLcXBEaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjM4MjU7czoxOiJjIjtpOjEzOTg4NjM4MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398863825),
('2eebb37649ad7f23962591956123bdb6bb86c263', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidkl4QmFLUmVsT0NOVmVUUnozcWNFMjhEWjdybTVsR0k3TXNvanRUbiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQxNjg7czoxOiJjIjtpOjEzOTg4NjQxNjg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864168),
('3331828042aab1823f4d1cfce8a84fbcfc76167e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVJJZjJKRkJCRk14UzZob2FhZ09COXVPb1o3MVl6WmI0a294Z1hOVSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQxNzE7czoxOiJjIjtpOjEzOTg4NjQxNzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864171),
('fd3ce038e5fec1ad03e56867a7fcc356db8c09f2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib2d2MFJZam9tNkg0NUpzT21XZDlvRG8ydVZkelZNVjRzckxaOWFIayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQyNTI7czoxOiJjIjtpOjEzOTg4NjQyNTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864252),
('e37f51ba02911350f90a1f2b25f47741e96c7521', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUWJheWUwVmJ0OVFlU0c1cmY5RDI2SFVoTlNaejh5YzBLZnRBSWdJQyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQyNjE7czoxOiJjIjtpOjEzOTg4NjQyNjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864261),
('54907e80cec0649b3d996e42df3eb88cf6509ca1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlJsMjM2eG5LdUlXTXRGb2x2NXpaNzBBSUNQQktFTjdZNFlFTUtOcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQyOTA7czoxOiJjIjtpOjEzOTg4NjQyOTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864290),
('cb44ee66b56a7a900f276b718ee50021aab17ae5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVZZWnlhVTdZUlJtM3VoYmNKamNwUnA5dWFneHVHdTZuZDZ5cnQ2WiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQyOTE7czoxOiJjIjtpOjEzOTg4NjQyOTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864291),
('7087687f4e5e44e2228f99cf145839dfbbf57d35', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibG1ld0pvZG1YMWYxeHhlYzRURlVLWVRoVm5UamNOMHF2RVJBMXF3RSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQzMDc7czoxOiJjIjtpOjEzOTg4NjQzMDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864307),
('4978db412ac183dfb3e92aefca4142cea5481501', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiakZFVUdKWEtteDlFQTVoV1kzWnZBRU80RU0yRXRZNUQ3Q1dOVHBpSSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQzMDg7czoxOiJjIjtpOjEzOTg4NjQzMDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864308),
('eaaaf595c614035474da1ca791b35ba18cbfc0bb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibm5sMGhNYTdVWHlkcTdNU2VYY0N3VnhqWlNkd0VkY0hzWk93NzFvYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQzNzM7czoxOiJjIjtpOjEzOTg4NjQzNzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864373),
('56c0e5f6f40b1d7d90179531807df612072494b5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDdLYkpROW5PMTc3bW9CVGhHdzN6WTF2ZUE2bHNtYk4ySlpYSzdKRyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQzNzQ7czoxOiJjIjtpOjEzOTg4NjQzNzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864374),
('75fb59df02883b08a5cfc1d130149f4c6ada6f3f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiamp1dGE5VTFpRVZOZUpvQlMzVTcya3ZISHVWZEJRSHdpZ2Zsa1hDMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQ4NDU7czoxOiJjIjtpOjEzOTg4NjQ4NDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864845),
('fbcfb90ef1bc77397034361f7589eff9a3002ac3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVhWWkFjSW9MYUZkU1htSTdVM0VheVpPOFIzM05SNXdnY016YU5YbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjQ4NTY7czoxOiJjIjtpOjEzOTg4NjQ4NTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398864856),
('c94b53f7dd7d0f7e8a63ca200500d862175bc830', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGtUVEhsY1g2eHVVU085RzRreEF3Uk1pZmZkUVRFaTh3THFBckJOTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyNzc7czoxOiJjIjtpOjEzOTg4NjUyNzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865277),
('ac91740ba3d11e7d430aedd77d0d4afca6dd9ec2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFk1UTV5elJ3QTV3N21XakFrUThXbGdWRjRiUHIzbEx6d1RTcXlDSyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyNzg7czoxOiJjIjtpOjEzOTg4NjUyNzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865278),
('d78711e5945ee04bd3c0550103cb682a458cc87a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidENTRTlxcGdnak5FWVBrb2k3d0haWFhFZXNPQ0FBSlVkSGFnVW1EcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODU7czoxOiJjIjtpOjEzOTg4NjUyODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865285),
('5a1e0a5f84c0feed5a27074e150f9c0fc8843dde', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid2ZBWTJHS2x3RUNBRklXWDNoOEhOTHpxVTF4M3B3NGFtVG00akZxdiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODU7czoxOiJjIjtpOjEzOTg4NjUyODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865285),
('3254f52024679ebfe11a1d84d7e6142f2c8fef57', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVE5la0NWNkN3dkR1cm1BRG14b0FDcFFsRWRvcmRDNVYzNnJvQU9ESSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODY7czoxOiJjIjtpOjEzOTg4NjUyODY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865286),
('b5dbbe3b1576e2014670111a7ee7e738e547c5c7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOFRmdEJINTl3OFc4ODZNTFU2R05UQ2JVQWJ2eE9CVmlHdTJPN2VnWSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODY7czoxOiJjIjtpOjEzOTg4NjUyODY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865286),
('8eb279ae905df35ef18dd80aac9a8170f18649e4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia1ZCSmtBaVlhUHN1WE9qMFF4aHdwcWhQdWg5TEcwdGxHUzdXS2pSWCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODc7czoxOiJjIjtpOjEzOTg4NjUyODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865287),
('5b6432f27e6e53a8c568a2e1bc8002ba52bb7b62', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2k0ZmtJR3loVFhCM202cnpUSUtLUWl2c0hBNUpyQk5YOHZOaDJKZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODc7czoxOiJjIjtpOjEzOTg4NjUyODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865287),
('22022fa1004903e81c49b868dbfde713dc2f5734', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMGFrcjVVbDZCOXRweG5OM2JaZDd5bXZCYmdlazhWREZVUDlLZW5wQyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjUyODg7czoxOiJjIjtpOjEzOTg4NjUyODg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865288),
('1a1b879332422d8d0b639a679791b85cb86f7595', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibW1HWDBLRVMxNGNiR0FJWkdBMnFQS3hQQ25WZFJjYXVMUXhrZkFEUSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2NTM5NTtzOjE6ImMiO2k6MTM5ODg2NTM5NDtzOjE6ImwiO3M6MToiMCI7fX0=', 1398865395),
('02d90af784ffcdc2ea20249d1c04806aeb9e9b7e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZDlPZ3Nhd21pZVJCamh5c3BFSWtyVjN0WFRNdkxEcHhTYm9mMmNGNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjU4OTY7czoxOiJjIjtpOjEzOTg4NjU4OTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398865896),
('416d52f15b560a1b44e6f7630e11f05713c46d2f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2lZVms3RmZDb2pYbDh3RXhGVTlBbW94N1lRQVNjQWp5dElSM1QyaSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjcyOTM7czoxOiJjIjtpOjEzOTg4NjcyOTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867293),
('b085a0f25da07f18934d4bd5b43f65ce83beeb0a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRWREdWI4NGtraU9ZTUVLek95WDhYQVB6Z2pVY0QzeVZXNmx3Y2NveiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc2MTA7czoxOiJjIjtpOjEzOTg4Njc2MTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867610),
('c93973f586345082839d43b03a7f0c7148553d86', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicGFWRkQ0TFZJRnQ1MVF1S1liVGxDUk9JVFNTSHVCVVlObDBnVHRaUyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2NzQ2MDtzOjE6ImMiO2k6MTM5ODg2NzM3MDtzOjE6ImwiO3M6MToiMCI7fX0=', 1398867460),
('3d95084e39f8f70af31bed9ef7bead99e028e86c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWjBCRXROTGxRYk1vbWY4N253amNIOGQ0dWlyMzFZemhIT2t2bkR2YyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0MDE7czoxOiJjIjtpOjEzOTg4Njc0MDE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867401),
('0c655161a2e3bb7b755e794de87515a2ff707909', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWlF0MUZ2TlBtMlZaRG55WTZ2ZWJCb2NlOEZOeXM0dEVCZnhwOFYyeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0MDE7czoxOiJjIjtpOjEzOTg4Njc0MDE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867401),
('b140fa54efc02d0ef19a4688c9db889502383b98', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3NYeXAzVWJ5bHVaSXZGc1R2TGhMNU1MNTlGT2ZPY1dKTXVLNXV0UCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0MzY7czoxOiJjIjtpOjEzOTg4Njc0MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867436),
('77714a4b95a296eededcbccaea89c74cb2c0345e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUZSVG4wVFVxYUVwNncyUk9xV3FzN2V3VzNpTEtuOG5BcWUydlBCNiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0MzY7czoxOiJjIjtpOjEzOTg4Njc0MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867436),
('5776ff81f66f1f61babf6c3004a023553288a3a3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWFuSzdVMFREcDBBVFVvazJpM1ZmYUh1Tm5oMnhMZFBvZXlzVktERyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0NzE7czoxOiJjIjtpOjEzOTg4Njc0NzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867471),
('7a6adfa00fd62de116fa413d3623ce54c09998cf', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibngwUWxLN1V6RXVMWElEenNCbzVUdjJEUFQ1UGtiZkdjc3N5OVZJVCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0NzQ7czoxOiJjIjtpOjEzOTg4Njc0NzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867474),
('e064a28d203505996855adbb2a75e4b13aeaab00', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFhOU09WTElUY3lFUXhZQ0lEVGdIYkxpbzNiYUVTbkRrNUc4VFBRVCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0ODk7czoxOiJjIjtpOjEzOTg4Njc0ODk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867490),
('37ed40256ab02da18d8aa48b4631e191881e5a12', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoickRtWThqR2xza25hTTluTGV4QnNXRTRYZnFIanVnaGY3ek1pZ1A4aiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0OTM7czoxOiJjIjtpOjEzOTg4Njc0OTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867493),
('d0b593ccb180845ad6ed3c7596cd36bedbb1be83', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia21tR0FrZzJ5Yk1GZFliZk5FdVdDYWtoVU9TQ2N5Y1U2WThsb2NIaSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0OTk7czoxOiJjIjtpOjEzOTg4Njc0OTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867499),
('9f078100b70b31f1862936aac40aec1c4a94825b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXJnMnNldlZLeHJlZnhLY0taY1RoQUFkd0JJblo2cko5cEo2N2doUyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc0OTk7czoxOiJjIjtpOjEzOTg4Njc0OTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867499),
('bc53a952e070a33ac2fc8c302ad470c3213f3cf1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWENEbkNSY2k5MnR1NFB1eTRSekpiU0dZUFQ1cmU3RWlweXp0WVNiMiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDE7czoxOiJjIjtpOjEzOTg4Njc1MDE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867501),
('ef58bd685c90286169fe0c2c17920b2b9e5cb8bd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieXVySFR6dndEcTFsMWtJWlVRQnhSeUdCclpkdzBmdUxDTkJRaFgwTyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDI7czoxOiJjIjtpOjEzOTg4Njc1MDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867502),
('055da91fbe55db772d8ca665387769dd1dc6bf24', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiblFDSDdnSUlzdVYwZ1BRQ25FUXFZYTJZc3NsanVCOXQ0dnNMcndMUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDI7czoxOiJjIjtpOjEzOTg4Njc1MDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867502),
('dd03387dce1ecccc36be932fe0e1242891ff58b5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUNVdThjeDZkT3lKWkkzbnZMUnd2OHd0d0F1R2w1RzFYTkYxbFNqYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDM7czoxOiJjIjtpOjEzOTg4Njc1MDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867503),
('1e750949003cf811fd2476802419fb038b9f10b6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUFhQQ1pNb2NnNUdxbURvVXY0dDBMZTVwMDRCeE4yTnBtdHlWdUdKbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDU7czoxOiJjIjtpOjEzOTg4Njc1MDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867505),
('0086dde98194ad591ed9819b900fefa533c99745', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTF2VXZPVEFHVnFxNG8zSEhTb1FxMEFrOFo5empMblZLVHhJTE1ySyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDU7czoxOiJjIjtpOjEzOTg4Njc1MDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867505),
('da43c7e308553ce0144565f993aa7191d3df6111', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibDhTZ1RRcVJUalViOXBtTjgzdm03N1RtcUF2aDBpOW9LVnNGVzZHYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDY7czoxOiJjIjtpOjEzOTg4Njc1MDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867506),
('5a99cbe1de573233dad0ae2ac66e8feb67d6c401', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSVRKS0huUzNXVkM2Z1JhV0ZIeTZYbkZJQ0FwUDE2Mnhza3pJNmdCdCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MDc7czoxOiJjIjtpOjEzOTg4Njc1MDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867507),
('542d070ea7366a79186a093c7a28c50a59219bd1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOE1xWE50RXRyc3VjekQ5R3JNRHJFdHBrOURDOW5yRVpkUlNxYm9ZdCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTI7czoxOiJjIjtpOjEzOTg4Njc1MTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867512),
('ad0af2f5cfe9c9df60bbe29e3fe0c69b34869928', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVlA4Nno3SkdETGNiSHV1a0VyejJZdGxTT1h1RjNkTXRIam9KZHVxaCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTM7czoxOiJjIjtpOjEzOTg4Njc1MTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867513),
('84880ad5c97d36a5ca27a3286309f3427d73cf18', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTTRWTWtEdHpXcm5pcjlBTVp0ZVlUcXVQckxHWTl2Y1FITk9adG54NyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTU7czoxOiJjIjtpOjEzOTg4Njc1MTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867515),
('7badc84eaef8f240ea8b5c653792d160b8cf896e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVV5SmdXWVREMzlsQVltdkNtWlBsa2t4SDd2MEo0dHZ0NnF0QkRBayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTU7czoxOiJjIjtpOjEzOTg4Njc1MTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867515),
('6284b65a18ac6f4caa88f3cc6c0707f9ebc9d999', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiajNFUUdiRFhuRzk3R29DNVZZa3lyNTkwUVYxSjBEZ3Z0Q1h4d0tYVyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTc7czoxOiJjIjtpOjEzOTg4Njc1MTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867517),
('c76e822288252fe3bc3aa46865fe1c29ed4b069e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiREhSczQ0NUl5QTlrQ1ZKRTlKdG00bUticHFwMUJIaFJyY0U2SkdlOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTc7czoxOiJjIjtpOjEzOTg4Njc1MTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867518),
('cbe9849e6622bc1914b9c13af0637e608b227609', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ3BEN0dtUFZhbmNmbXZoOHBQR21TOWxya1pNRlJTVW4wd1J0Tjg3YyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTg7czoxOiJjIjtpOjEzOTg4Njc1MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867518),
('841d35976db554f0865baa6756afdaa7f1aaba08', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSERYaGRXUk9HRGRaMTFFSVBQNWxCMm5LR1MxWUZZa0ZBOE1jNG1nRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MTk7czoxOiJjIjtpOjEzOTg4Njc1MTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867519),
('8a3a7b6debb2f2ae1208c05d974c597b873ef451', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTjJ3am1QdWNsU1V4Vlp1V1ZJNnZYY3RYOEF6ZnQ5Q0hnT2Z0c3VwNCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjA7czoxOiJjIjtpOjEzOTg4Njc1MjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867520),
('93214890ff9b1372a9c3f526a120f280ce04c96d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjQ4ZzNrZnJiSFU3eDRLWldZTHp0ajZsbnRVZjZuTEI4Q3V0MGwyWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjE7czoxOiJjIjtpOjEzOTg4Njc1MjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867521),
('318f3ef802008b692e3e21a98d49d4f2176c3b18', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibzFMWEMzNzNlOUJFOUc2QXhMQ29jbjVNSWhTSnBWckZ3NFpNWkVvUSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjI7czoxOiJjIjtpOjEzOTg4Njc1MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867522),
('0b9f329919700dff0f028ceac6b261b3709cb38d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibUxONUVCSmxEOFl1aVdnc0dyWGNrNkdkdzA3eDA4eEZWVXVZeTM2TiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjM7czoxOiJjIjtpOjEzOTg4Njc1MjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867523),
('13ac808d5ef9b01b731579a5c26afbed77e129ca', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiekRiVTdETnMzQ0tmSUk1V2Z0VkR6U1NpZ3F3RU5SY1M4SGJCSXVabyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjQ7czoxOiJjIjtpOjEzOTg4Njc1MjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867524),
('46bacc55597069971df1e0a5394b031a57a0647a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjZnNHlPaVI2UkdWWVVUWnpPTnFsZGhVS2ViWUliSUVBRG5CVzNkZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjQ7czoxOiJjIjtpOjEzOTg4Njc1MjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867524),
('45697c0f6c6e522363e1bc39d971881b4a51110c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHNaeHlUSmVKMHB5Zlp6MWtvak5ENzQwVmVFODAwNmM0QTdHbWlFTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjU7czoxOiJjIjtpOjEzOTg4Njc1MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867525),
('ad43507f50eb144ad6e44b4ec3f1f4e6b6dc5c25', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZDhOWHF2eFpZMG9hZGJSMlBVTVpPV1hNTmU1SEk5bmhGMWQ5R3hSZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjU7czoxOiJjIjtpOjEzOTg4Njc1MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867525),
('fe390fd047c714ea8153a3c83a8f24da09539579', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV1M4NkRPdjE1ejJlMkJETnowaDhqVXZubzhyYWJZWWgwUUVIa0dmUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MjY7czoxOiJjIjtpOjEzOTg4Njc1MjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867526),
('5cd00f4ee935d16a7e08ff56090f42599e7a5236', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieWlhTmhQTVFKc0R5WmRCSmsxZ3VLd3RVUVlndXFoaEU2TTBZajRDeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mjc7czoxOiJjIjtpOjEzOTg4Njc1Mjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867527),
('28c4a2df47ee532afa69a99b75d315ac5833a426', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZkNIZWd1RnNPMFBhdlNEYWJGWlBSTHc2RGRhVElXVHlzNWd0NzQ3ZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mjg7czoxOiJjIjtpOjEzOTg4Njc1Mjg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867528),
('d378eb09fb14d3cb7a2dd10c17f990f2499a3608', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2kwU0tWYnRIaktqOVhyNm4wQzRuRkpZSkM4cFNoMGZtd1RnVVRxNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mjg7czoxOiJjIjtpOjEzOTg4Njc1Mjg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867528),
('d4a3c6d5de6121b9ca01c7c948318926abf5a462', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid21kV3VMQlNXRFl2ZTNTb2JUeVpHYVZhTmtVWFEwbHFMV0x1OUkxeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mjk7czoxOiJjIjtpOjEzOTg4Njc1Mjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867529),
('7f2fd041d1b9280db95b32d5b135c8bbeb53a738', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUW96Zk9OS1FiMHRjdm5qVEdLbFc2anQ0QUkzQUkzSnd6NUJYZGliTiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mjk7czoxOiJjIjtpOjEzOTg4Njc1Mjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867529),
('877edd844045a12a74e4ce6419d1a654bceeeaea', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXd3NmE4dEM4OHVCM0JSZ1lEQnpPcWhUb1U1WEp3VVUwT3BJb28wcyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzA7czoxOiJjIjtpOjEzOTg4Njc1MzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867530),
('ad31ef3d0c2f1506a56ca96980e79b686a02c907', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0dBM3VualVrWXR1bGdLbldoalhiVmpVYVhMZlA2TUIzR2N1T28xUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzA7czoxOiJjIjtpOjEzOTg4Njc1MzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867531),
('b9ed2ca17734f05997296f9bb69cb6ac6646ebc0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkhRcWxabEdGVzg5YWZVaVRodWsxcVA4VjJlMDZIWWpuQ280R1J0dSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzE7czoxOiJjIjtpOjEzOTg4Njc1MzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867531),
('003a72910d160144ff736c726f5c84e24ec18dd1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidnE0WVdMZTBlZFJHTjRyRUIxa0hwV1JQRk9ZM01xaTNDcHlhbHFINCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzE7czoxOiJjIjtpOjEzOTg4Njc1MzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867532),
('b8682c1e368af8d6f3049f185919683bcc8d27e5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibnZlRFhiaFI5ODYza0E0MVppeWczVThYTXhqSFhtQXNWVWRVTGtONCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzI7czoxOiJjIjtpOjEzOTg4Njc1MzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867532),
('dc500b558fe815dc3e85fff04ccaf7784ffb51e2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZmlab2taYnQzZmtyNTZmeDRmRzVudU1CNkxtejRGNEVHTFZQcXY2byI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzI7czoxOiJjIjtpOjEzOTg4Njc1MzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867533),
('837ade49747386b398870ecaec09ebccf0897309', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTG15T0dXMk5lY3ZRdTFyM3dMU29HVmljZmxXdDZFcEw0RDd6d21QUyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzM7czoxOiJjIjtpOjEzOTg4Njc1MzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867533),
('db521d95bad14b1b19699dea5623f80469728e24', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnJHYlUyTkljc3lGeUpyUzVubndzWnZDTjZacnY4RklnS1RCRVVGUSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzQ7czoxOiJjIjtpOjEzOTg4Njc1MzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867534),
('309948bbe7801ca57b2b68e1b6027dd6390eabeb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVW84V2pQbjJwR21xSXlaQmRnbDRjM2E2dGRYdVdjbFVPQmpKcUhwdCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzY7czoxOiJjIjtpOjEzOTg4Njc1MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867536),
('8150f0871ec3b635153b1f7ef6d7b673baea1034', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTJnWm9BRm5Lc2o4ZENIc1RDd2taTE9sWHRwckdSeFNzR09kT3FkQiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1MzY7czoxOiJjIjtpOjEzOTg4Njc1MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867537),
('aeec56edb9beebd01ec3a838bfcaae8b7df11a38', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYm9SNDZpSWpZeVhCRVp6Y01Jb3NLQmd6aDdDYVJpOVBiNGtSQ0NjaCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mzc7czoxOiJjIjtpOjEzOTg4Njc1Mzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867537),
('877f96b571caa6df10d3491cd630d9a0ee9d61e6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1E1dXVhMTRhOFBsNHNEaHZ5MEMxRTB6SFh2bzBteHd3Qk9DTkFsUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mzg7czoxOiJjIjtpOjEzOTg4Njc1Mzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867538),
('1d56ec1aece123da0efbd943b6b3fd2d5938e33c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSVF0MWxSMWo4QzFFQ3ZPY05WdkU1eGdxODlkQTh1bmlBMmN2Skc3TyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc1Mzk7czoxOiJjIjtpOjEzOTg4Njc1Mzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867539),
('153bbac80c058f59f7459bf9989845b10c0464f4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ0d1QWpmaHlvcHdBWTNWU2FiekYyTUZhZVBBdmxDUWZlT09MNWo4SyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc2MTE7czoxOiJjIjtpOjEzOTg4Njc2MTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867611),
('870d70f12626ace25f5fd34903f9e85a98255363', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNG02QVIxU3hqSTNnV3g2R25UQVZLYzJXZVNMMU9QSjU0RnpzYVNtUSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3NTE7czoxOiJjIjtpOjEzOTg4Njc3NTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867751),
('37448f148cdc65d539790812fde909960fa1644e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidDJVeVM2a2VzeTF5dmVqamxWMVcxQ2hPaFoxa2dBM2tTUU9pV1d1cCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc2MjE7czoxOiJjIjtpOjEzOTg4Njc2MjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867621),
('c17401257bef069562aa2a6963418a0b3ef77950', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXFhanNtN3NOVTJKT050SE0zdktOaEJVR3p5dU9Eek52Q2p2NU04UCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc2MjI7czoxOiJjIjtpOjEzOTg4Njc2MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867622),
('186baa5791cca23dd7b57cb7a8ed017716f171a2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRldNNFdWclJWdTNaallvMGhrSzVlY1RqUElLQUZ0SDZNZG5vblU4MCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3NTI7czoxOiJjIjtpOjEzOTg4Njc3NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867752),
('d51426bf6c4767e72cbd99a5ba4f51b7cea78c95', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU3hvYnhtbk9sMEROMERxQk1LbEFzcGFiYWNVTWZFa0hhczBnc1JDaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3NjE7czoxOiJjIjtpOjEzOTg4Njc3NjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867761),
('db88c7d58df34944b29baa1f4c3b31c98c7c4d21', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVFZuR3A4THo1UFFGOE5xZnR1aTkwRHhST01kREtsTmhLQU14NFY2dSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3NjQ7czoxOiJjIjtpOjEzOTg4Njc3NjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867764),
('cfa943c54e5d4bcc990af0546e1a61d37a1247d5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUmIxdjJqVDFubzk0ZUdQUXNpbmR3WHZxemdkVGR6dzBndE5CNUhBQyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3NjY7czoxOiJjIjtpOjEzOTg4Njc3NjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867766),
('24f12db90934aec32b131368dd9707d6837c3de3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUU5PdXVSR00xRzkwbnpGYlB3UWVGR0VJSkt1SXpxYW1mbURFYmNSTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3ODY7czoxOiJjIjtpOjEzOTg4Njc3ODY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867786),
('61cd98e96a7e68d3f64016036d7c4341793826bf', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWlFsN0JYd243RkRLS2lVbDdTQTVsakxvV1NaNU5TdE5FZ2ZKU0xneSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3ODc7czoxOiJjIjtpOjEzOTg4Njc3ODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867787),
('d7eeaba450879c600488d2291ddb188e12127fb4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic2NoTU9EakhEVlNTRVo1cnozT3pQaGJIQzRhNzJtTXI1WnBVVGc0SCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3ODg7czoxOiJjIjtpOjEzOTg4Njc3ODg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867788),
('069863d950d3bd75e7e90aaf968a1cb56e92f9dd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTEJGZ2J3RkthbHJTb09mZGd5dVNXTFgwZ2xtWUttaDRYb1NEdU1kNSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3ODk7czoxOiJjIjtpOjEzOTg4Njc3ODk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867789),
('bbe916895ae0435f1ccde66b53697d61c932dae7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRlZCSjdVYzBQR0pWTVNMVDdSSWhxMmRXcVBQU1Z4N2VVdmZTdTJvUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3ODk7czoxOiJjIjtpOjEzOTg4Njc3ODk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867789),
('119bb7088850c564c2d8c3c8c64f4f2cd7a4998a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic2hwWExjWHliSXRkTUZWTzVYd1ZtWE9nMkdtNnlwa01YcXFWbTdxTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc3OTY7czoxOiJjIjtpOjEzOTg4Njc3OTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867796),
('6284250749e283d92398226e234fe50d84569873', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGtIdE9ybXd4WXkwb1NkUnpaWGtRbk1PQ3JlYXhGdUlEREZwajNyciI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc4MzQ7czoxOiJjIjtpOjEzOTg4Njc4MzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867834),
('24cc4ebd47b31326775e20b67edd7922067a7c97', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2wxNmhiYUt4d3JxR0o5WldxMXN3TFFzWE13V0RrQ1RrSktmTDV6aiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc4NjY7czoxOiJjIjtpOjEzOTg4Njc4NjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867866),
('7b00af84e5e6381df921c3bfcf0b97a5ec53e0e9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicFZHam80ZkJoM0hsVmdhejZxeEFqc1RjdnFYT0FnRWxndzJLVDBodiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc4OTQ7czoxOiJjIjtpOjEzOTg4Njc4OTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867894),
('1e3f74d58492a5c894506336a385f9c664e596dc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWWN6bFBKQkUzREVaS1BYTUhScDJiSjVRWWI4SWI2c055aDQzeENsOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc4ODA7czoxOiJjIjtpOjEzOTg4Njc4ODA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867880),
('9625bf4bdac008765fb4656012b2fe3d560c04eb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidWhkN1JBVnRDVmFZR2RTRG1HR2c5ekczWHNka3ZRd3BJWUlMQjdDWCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njc5MDQ7czoxOiJjIjtpOjEzOTg4Njc5MDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398867904),
('0da4d69acb5c06a827730fd92fa5f7b3dfdb0e5e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1NlTWNJY2J3NkJiWVRpN01UdXNXZjk0UjFScU56WVB1UWYxYU9xMCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2ODExMjtzOjE6ImMiO2k6MTM5ODg2ODAyNztzOjE6ImwiO3M6MToiMCI7fX0=', 1398868113),
('ca8210ee6e4439992844c907a5f73c7bdcda9eb8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzFyQVVmSlJuQlpXcTNZR1N2N2JVQ0VYRGNuM3F3T1pCVWR2T0QxUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgwODE7czoxOiJjIjtpOjEzOTg4NjgwODE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868082),
('8df863b64385f6820f42cb909acc278b2fae8dc0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUmJkajd6UEQwelJ4ZFhKY1N5aVRTZklNbmJndGhaNWxHZUJrNmxydSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgwODU7czoxOiJjIjtpOjEzOTg4NjgwODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868085),
('a90e7112d3bb730425f8006407e6af2eca7ef133', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiT3FDYWhNQmxOamMwaFU3VXlHMjJKSVk5UXFSZVZ2M3pFbk9xbHVlZyI7czozODoibG9naW5fODJlNWQyYzU2YmRkMDgxMTMxOGYwY2YwNzhiNzhiZmMiO3M6MToiMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgwOTc7czoxOiJjIjtpOjEzOTg4NjgwOTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868098),
('896a0082c6dc25e2c0e82f66b93851e7b8c5b9c5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDNhcVFIWk5iVnBiaVRpbm9IbUtKOTJNNlZ2R2YyNUZzR09DSUV4UyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgwOTg7czoxOiJjIjtpOjEzOTg4NjgwOTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868098),
('dccecc74e904ca4d795f4786ccfed74d26e02fc4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZUZVck1PSVJDZFhqbWJLc1pMZ1h3UmJKUVVVcjV5bzRJTVlpWXdpUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgwOTg7czoxOiJjIjtpOjEzOTg4NjgwOTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868098);
INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('f967c72edbc58a9fb86fd03e56ee287881570f73', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNHdwSU5ZT2ZMOTlPZ25KSzh0Tmh6VENYR3NwT0h5cEI0YjlIanNMZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgwOTk7czoxOiJjIjtpOjEzOTg4NjgwOTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868099),
('b0a5d73ee4e7b5aa57dc8eecd80704baa8baf77c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUljdWxURDlnNnBuRUtRSGN6cENrUmJFeWxFSEVmeGdzY3ZEbmM4cyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxMDI7czoxOiJjIjtpOjEzOTg4NjgxMDI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868103),
('c3b7a16a731b7b8ef2e0b61a372d19699e4f5ec5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoialZhNWRQRWJwWDRhRTVMY25jakp3SXJVdFlsWjdHeWozNkVwSkFyOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxMTU7czoxOiJjIjtpOjEzOTg4NjgxMTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868115),
('5d16a56f87bbb804c35bb4b26d97e7d38f8638b8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR085WmtUdE9xc3NmQXJ3QnJ1b3EzdFVqYVlTMWk2MThjZWhzQmZ2NyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxMTY7czoxOiJjIjtpOjEzOTg4NjgxMTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868116),
('cccc99fd0a0e4e865253546d741d5caad1aa302e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzY5VDBlZDBnNjF4UWUzRmhteXA4cGtJRG4xSm41VnBmY2ZkSDl6NyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxMjM7czoxOiJjIjtpOjEzOTg4NjgxMjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868123),
('a9230ad6e84470aa7d933eaf74284882c3f33dc3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVzRGRTRmb25QT203dmkzT21RR2hoOHFwelNPS2tVSXkyM1VaRG5ObCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxNTM7czoxOiJjIjtpOjEzOTg4NjgxNTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868153),
('8effb23cb47cf078f2945ee75e740462f10c3b3c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXE0RHhCTVFzOHk0QXRIQ1BXS3E0SGZrdDgzMlFZaEk4bmljOGdSbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxNTQ7czoxOiJjIjtpOjEzOTg4NjgxNTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868154),
('7f3eb8430b16bf60910785e00ca57c4d50a2d612', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSDhXbjcwVzlBY3psNmdRM1pWdHk0ZXZKY21sT1FnUWZnSDd6dTRONSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODA7czoxOiJjIjtpOjEzOTg4NjgxODA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868180),
('913a505fe498445d312a988e07f9e04042da30cd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVG1zTUZQM002YVRoSUJQQWRTRjFSTDE4MHZ2Z3BWWWlKVlhlck5ubSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODA7czoxOiJjIjtpOjEzOTg4NjgxODA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868180),
('f6f2ea2fefb044860301f8a0d0743d656636b26a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidEZ2RGZUN3hIWElGaVdYekpTOHh1Zm1qWHN3Z2JzSE5GVTYzQzVmeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODI7czoxOiJjIjtpOjEzOTg4NjgxODI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868182),
('e1020c22274d1a1277e3181b589e6d92e9d00ecf', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWnBhdTVhVmhJcEQ2dWx1UGVzdnV2ZmdGRmFzOFZxWUliZjg0Y2QzayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODM7czoxOiJjIjtpOjEzOTg4NjgxODM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868183),
('4e5b24ffd9706c7a674b119df589e9f81651c67e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzREM2I2elhIczBINnVvWDgya0hnN3F1QjV6a0ZSOGIyMEVvVWZoZiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODU7czoxOiJjIjtpOjEzOTg4NjgxODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868186),
('c75e7400ce14b5e2cefe0742aaa555f6c4f6c834', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTmladVRzcUk5ajFrWmdCMmFxczN4Tzc5MTNqS0REMXJwN0pSRWtibSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODY7czoxOiJjIjtpOjEzOTg4NjgxODY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868186),
('cbd748894d5847a2c920493bb0a90a6d5017cc74', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidVJjeUloMnRneUFLVHFYcDZFakczT05YVWQ2RjRDN0xBMkE2VU1RVCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODc7czoxOiJjIjtpOjEzOTg4NjgxODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868187),
('cb27e582c3b609b58a2e9b6d2d383b498d0436e0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzR0eERrOExLQ21HcllLazZVT2NiS1p6dEtmTHlERmY5dlZSVWFDZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODc7czoxOiJjIjtpOjEzOTg4NjgxODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868187),
('ebbe4b9c4640e607c74f26636ca3e77962ef1aea', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQlNrTENHWUNpVFRSRWNBUk5kS3E1QjNnMFU2aElrWFNHT2xIa0JHVCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODc7czoxOiJjIjtpOjEzOTg4NjgxODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868188),
('fc0893091578ccf46f5780bda422abee1215548c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlRCWm81amZWTldGV2t1OFpnZm9JNUJWUnlNdVJPc0JvQlFsdGVwZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODg7czoxOiJjIjtpOjEzOTg4NjgxODg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868188),
('347e3f9a069145f1fe95cbeb32bec6bae665a4aa', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnFLWXJ4Um0xSjJFcTN5aTFkSTF5S0tpVWtyT05IeFBUVUJJT0ZibiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODg7czoxOiJjIjtpOjEzOTg4NjgxODg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868189),
('07a1d69bad0bd0b6445c7467afc1d48c354b540f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRFRXdzd3UVU5aEM3cUJaVHJiN2Y5OWF5QXZ3Q3RhcUhiWFp3TW9QSyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODk7czoxOiJjIjtpOjEzOTg4NjgxODk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868189),
('e2bc80a41853368d4c40a9683f0ea829fb299646', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzdmRHpMM0JldjFYbmxhanh5WUJMcVRTZGFwcmxaV2VIbndtTGk5QSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODk7czoxOiJjIjtpOjEzOTg4NjgxODk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868189),
('a3d24c6fb0f9c9838a7cea57d31361d3b3ada3ed', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVktUMXhhVXFRT2dLSWcwaE9DWE85aXBRN2hVbVRNUlBURDM1aWtwUSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxODk7czoxOiJjIjtpOjEzOTg4NjgxODk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868190),
('ec3baa92efe636fd99274a74a833aeb0168a0be5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiM2lVVW93S3F1U1ZxUktaV0xYRlVyQTZ2MldFOUwzTmlUYnZzeUNtSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTA7czoxOiJjIjtpOjEzOTg4NjgxOTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868190),
('5e587f110ca7e48cdc148c6ea02c20885a6657a3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic0gzd3RUR0tTakFVUHhEeXU2Q3VzOWdlcGFDbFA4TDFsOVpkaXVDSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTE7czoxOiJjIjtpOjEzOTg4NjgxOTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868191),
('ea597666aece5f8f53bef57c41b7c5f8602ff69b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWlhMVBXbUZkeVZCbXZudEtwUTNrRzlkNHZqck9BaVVBd3BlWEkxUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTI7czoxOiJjIjtpOjEzOTg4NjgxOTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868192),
('4d63972cfbbd7da86cb5af5a62212f7654be3899', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1Nxd096RDhUcDMzQzhqNXI1eDZDRjdhSHVOWXVYS2p4ajZ3SUlBNCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTI7czoxOiJjIjtpOjEzOTg4NjgxOTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868192),
('97e59c0a5ed1b08bdeb817ca63fc29a13b49f459', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZXN3dllGdVRxYjZTdjFSZFliRHo5YzdRSXNUNDlhendIRmZXaEhGeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTQ7czoxOiJjIjtpOjEzOTg4NjgxOTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868194),
('e2a6583ad72cbf742f44ef83ce5ac6f4e9006655', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOHNLWUdwSERBS1NyeHVHUmFLQlVYVFVvTDVYdWtRUFZzcXQ3WjBXcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTQ7czoxOiJjIjtpOjEzOTg4NjgxOTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868194),
('fe91db93fd544468879b280c352579d035b03eac', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYm9wb0VadW16bWMwWERaTDlwd0NOd04yOVp4bmo0cmxSTHhGQmZhWSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTU7czoxOiJjIjtpOjEzOTg4NjgxOTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868195),
('32017ea6612047ac0deefc16c67400f84e15416b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU25tVXB4UUl6M3RuR2J0MjI0dWNXdURhSXFyTFp3dXpVQjF2Vkg3QiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4NjgxOTU7czoxOiJjIjtpOjEzOTg4NjgxOTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868195),
('d3f77b25a128a76147b8c94d85dea5402c9d18fd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOG5MdkJib0lvbGhndWsyUjUzRlFmVlZLYWhlaG0yRHdrZEFzN0s1RSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njg0NTc7czoxOiJjIjtpOjEzOTg4Njg0NTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868457),
('18e00b366c87e3c3499f3d92b0f8dfe5d1463a57', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUHZuV1dIZklLaE1VVVZTVGxNWHlncEMxV3JaN1FTTkpTTUhZejU3VyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjEzOTg4Njg0NTg7czoxOiJjIjtpOjEzOTg4Njg0NTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1398868458),
('a0eac3c0869300575a8511e628347e84112c0498', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTm05eHJ5cEJuOHI5dGpqdE81S095c0hKN2Z1SlBOU29FZ1hhck9ZbyI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTM5ODg2ODk0NjtzOjE6ImMiO2k6MTM5ODg2ODk0MztzOjE6ImwiO3M6MToiMCI7fX0=', 1398868947);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `templates`
--

DROP TABLE IF EXISTS `templates`;
CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `static` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `templates`
--

INSERT INTO `templates` (`id`, `name`, `content`, `static`, `created_at`, `updated_at`) VALUES
(1, 'default', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'catalog', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'news', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'articles', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'category', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'product', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'manufacturer', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'index-page', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="row content max-width-class" role="main">\n		@include(''templates.default.sidebar'')\n		<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">\n			@yield(''content'')\n			@if(isset($content))\n				{{ $content }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-29 09:45:45', '2014-04-29 09:45:59'),
(9, 'investors', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container investors">\n		<h1>Инвесторам</h1>\n        <div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			@if(Auth::guest())				\n				{{ Form::open(array(''route''=>''signin'',''role''=>''form'',''class''=>''auth-form'',''id''=>''signin-secure-page-form'')) }}\n					<div class="form-header">Авторизация</div>					\n					<input type="text" name="login" placeholder="логин">\n					<input type="password" name="password" placeholder="пароль">\n					<button type="submit" autocomplete="off">Войти</button>\n				{{ Form::close() }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 06:06:28', '2014-04-30 06:12:15'),
(10, 'contacts', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container services contacts">\n		<h1>Контакты</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:500px;width:600px;"><div id="gmap_canvas" style="height:400px;width:100%;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(40.7056308,-73.9780035),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(40.7056308, -73.9780035)});infowindow = new google.maps.InfoWindow({content:"<b>УПК</b><br/>ул. Красных зорь, 123а<br/> Россия, Ростовская область, пос. Успенский" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, ''load'', init_map);\n            </script>\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 11:15:17', '2014-04-30 11:19:54'),
(11, 'request-for-access-to-documents', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="container investors">\n		<h1>Заявка на доступ к документам</h1>\n		<div class="content">\n			@if(isset($content))\n				{{ $content }}\n			@endif\n			<div class="apply-form">\n			{{ Form::open(array(''route''=>''request-to-access'',''role''=>''form'',''id''=>''request-to-access-form'')) }}\n				<table class="apply-table">\n					<tr class="apply-row">\n						<td><label for="name">ФИО контактного лица</label></td>\n						<td><input type="text" name="name" id="name"></input></td>\n					</tr>\n						<tr class="apply-row">\n						<td><label for="organisation">Название организации</label></td>\n						<td><input type="text" name="organisation" id="organisation"></input></td>\n					</tr>\n					<tr class="apply-row">\n						<td><label for="email">Адрес@электронной.почты</label></td>\n						<td><input type="text" name="email" id="email"></input></td>\n					</tr>\n					<tr class="apply-row">\n						<td><label for="phone">Контактный телефон</label></td>\n						<td><input type="text" name="phone" id="phone"></input></td>\n					</tr>\n				</table>\n			<button class="apply-btn">Отправить заявку</button>\n			{{ Form::close() }}\n			</div>\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-30 11:23:04', '2014-04-30 11:29:35'),
(12, 'news-on-main-page', '@if(isset($news) && $news->count())\n@foreach($news as $new)\n<div class="block-w-logo" data-date="{{ myDateTime::getDayAndMonth($new->created_at) }}"></div>\n<div class="block-title">Новости</div>\n<div class="block-text">{{ Str::limit($new->content,200) }}</div>\n@endforeach\n@endif', 0, '2014-04-30 14:47:11', '2014-04-30 14:56:49');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Администратор', '', 'admin@uspensky-pk.ru', 1, '$2y$10$1hU9pK9AlpiZJzPGyET./.pUqIv2YJzbBTbMG432Tw2t6g3350ehS', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, 'xZvIMnctLG9VXJ5cgdi1zkQD4l9VJhpqZxErMKRDfyerZrXfhfDYzaOa5Nx4', '2014-04-30 05:05:40', '2014-04-30 14:24:20'),
(2, 'Пользователь', '', 'intranet', 1, '$2y$10$3vJkKa6SjZNHYJ/pOjoWMewssEQezo5iA5YjEiuR60GyqKHIq6gO2', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, '04U6o3nEWrwHUEmCdJz37vCe14FHf6WBdmO5s1zfi3X0z7UyDKdYnuQm4NRG', '2014-04-30 05:05:40', '2014-04-30 14:24:52');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
