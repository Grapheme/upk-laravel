-- phpMyAdmin SQL Dump
-- version 4.1.13
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 29 2014 г., 15:59
-- Версия сервера: 5.1.40-community
-- Версия PHP: 5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `upk`
--
CREATE DATABASE IF NOT EXISTS `upk` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `upk`;

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `catalogs`
--

DROP TABLE IF EXISTS `catalogs`;
CREATE TABLE IF NOT EXISTS `catalogs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `fields` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_parent_id` int(10) unsigned DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `categories_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `categories_group`
--

DROP TABLE IF EXISTS `categories_group`;
CREATE TABLE IF NOT EXISTS `categories_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `category_product`
--

DROP TABLE IF EXISTS `category_product`;
CREATE TABLE IF NOT EXISTS `category_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_product_category_id_index` (`category_id`),
  KEY `category_product_product_id_index` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'user', 'Пользователи', 'dashboard', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'moderator', 'Модераторы', 'moderator', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `group_role`
--

DROP TABLE IF EXISTS `group_role`;
CREATE TABLE IF NOT EXISTS `group_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_role_group_id_index` (`group_id`),
  KEY `group_role_role_id_index` (`role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `group_role`
--

INSERT INTO `group_role` (`id`, `group_id`, `role_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 2, 6),
(13, 2, 8),
(14, 3, 3),
(15, 3, 1),
(16, 3, 2),
(17, 3, 6),
(18, 3, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `group_user`
--

DROP TABLE IF EXISTS `group_user`;
CREATE TABLE IF NOT EXISTS `group_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_user_group_id_index` (`group_id`),
  KEY `group_user_user_id_index` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `group_user`
--

INSERT INTO `group_user` (`id`, `group_id`, `user_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `paths` text COLLATE utf8_unicode_ci,
  `attributes` text COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `images_module_id_index` (`module_id`),
  KEY `images_item_id_index` (`item_id`),
  KEY `images_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `default`, `created_at`, `updated_at`) VALUES
(1, 'ru', 'Русский', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `logo` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_19_104802_create_users_table', 1),
('2014_01_19_104821_create_groups_table', 1),
('2014_01_19_104830_pivot_group_user_table', 1),
('2014_01_19_104934_create_roles_table', 1),
('2014_01_19_104954_pivot_group_role_table', 1),
('2014_01_19_105008_create_pages_table', 1),
('2014_02_08_123907_create_languages_table', 1),
('2014_02_10_125947_create_galleries_table', 1),
('2014_02_10_130103_create_photos_table', 1),
('2014_02_17_105422_create_settings_table', 1),
('2014_02_18_133757_create_news_table', 1),
('2014_02_20_094843_create_templates_table', 1),
('2014_03_03_201446_create_modules_table', 1),
('2014_04_08_142125_create_session_table', 1),
('2014_04_10_085237_create_permissions_table', 1),
('2014_04_10_090423_pivot_user_module_permission', 1),
('2014_04_14_101731_create_articles_table', 1),
('2014_04_18_103249_create_catalogs_table', 1),
('2014_04_21_133950_create_categories_group_table', 1),
('2014_04_22_070606_create_categories_table', 1),
('2014_04_22_143526_create_products_table', 1),
('2014_04_23_103825_create_images_table', 1),
('2014_04_25_101239_create_category_product_table', 1),
('2014_04_25_112828_create_manufacturers_table', 1),
('2014_04_28_115029_create_products_attributes_group_table', 1),
('2014_04_28_115149_create_products_attributes_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `permissions` varchar(255) COLLATE utf8_unicode_ci DEFAULT '[]',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `url`, `on`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'seo', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:44:57'),
(2, 'news', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'articles', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'pages', 1, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'catalogs', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'users', 0, '[1,2,3]', '2014-04-29 09:43:10', '2014-04-29 09:45:09'),
(7, 'downloads', 1, '[3,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:11'),
(8, 'statistic', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'galleries', 0, '[1,2,3,4,5,6]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(10, 'languages', 0, '[1,2,3,4]', '2014-04-29 09:43:10', '2014-04-29 09:45:03'),
(11, 'settings', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(12, 'templates', 1, '[]', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `module_permissions`
--

DROP TABLE IF EXISTS `module_permissions`;
CREATE TABLE IF NOT EXISTS `module_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `module_id` int(10) unsigned DEFAULT NULL,
  `permission_id` int(10) unsigned DEFAULT NULL,
  `value` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `module_permissions_user_id_index` (`user_id`),
  KEY `module_permissions_module_id_index` (`module_id`),
  KEY `module_permissions_permission_id_index` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `sort`, `template`, `title`, `language`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `publication`, `created_at`, `updated_at`) VALUES
(1, 1, 'news', 'Регистрация компании-инициатора проекта', 'ru', '', '<p>\n	Веб-интегратор <strong>DEFA</strong> представляет новый сайт для  международного аэропорта                             Внуково. Столь  сложный проект для нас - лучший показатель                              профессионализма и слаженной работы команды!\n</p>', 'registraciya-kompanii-iniciatora-proekta', 'Регистрация компании-инициатора проекта', '', '', '', 1, '2014-04-29 11:20:05', '2014-04-29 11:20:05'),
(2, 2, 'news', 'Официальный старт проекта', 'ru', '', '<p>\n	Веб-интегратор <strong>DEFA</strong> представляет новый сайт для  международного аэропорта                             Внуково. Столь  сложный проект для нас - лучший показатель                              профессионализма и слаженной работы команды!\n</p>', 'oficialnyiy-start-proekta', 'Официальный старт проекта', '', '', '', 1, '2014-04-29 11:20:25', '2014-04-29 11:20:25'),
(3, 3, 'news', 'Официальный старт проекта', 'ru', '', '<p>\n	Веб-интегратор <strong>DEFA</strong> представляет новый сайт для  международного аэропорта                             Внуково. Столь  сложный проект для нас - лучший показатель                              профессионализма и слаженной работы команды!\n</p>', 'oficialnyiy-start-proekta', 'Официальный старт проекта', '', '', '', 1, '2014-04-29 11:20:47', '2014-04-29 11:20:47');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `in_menu`, `sort_menu`, `template`, `language`, `name`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `content`, `publication`, `start_page`, `created_at`, `updated_at`) VALUES
(1, 0, 7, 'index-page', 'ru', 'Главная', '', 'Главная', '', '', '', '<section class="slideshow">\n<div class="slideshow-after">\n</div>\n<div class="wrapper-abs">\n	<div class="slideshow-over">\n	</div>\n</div>\n<div class="fotorama" data-width="100%" data-height="800px" data-navposition="top" data-transition="crossfade" data-arrows="false" data-loop="true" data-nav="false">\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n	<div class="fotorama-slide" style="background-image: url(theme/img/index_back.jpg)">\n	</div>\n</div>\n<div class="slide-title">\n	      Инвестиции в уникальные технологии\n</div>\n<div class="index-blocks">\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo" data-date="27.03">\n			</div>\n			<div class="block-title">\n				      Новости\n			</div>\n			<div class="block-text">\n				                               Руководство компании приняло участие в программе повышения квалификации  руководителей  mini MBA\n			</div>\n		</div>\n		<a href="/news" class="block-hover">\n		<div class="block-hv-text">\n			      Все новости УПК\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo invest">\n			</div>\n			<div class="block-title">\n				      Инвесторам\n			</div>\n			<div class="block-text">\n				                               Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс».\n			</div>\n		</div>\n		<a href="/investors" class="block-hover">\n		<div class="block-hv-text">\n			      Подробнее\n		</div>\n		</a>\n	</div>\n	<div class="index-block">\n		<div class="block-top">\n			<div class="block-w-logo contacts">\n			</div>\n			<div class="block-title">\n				      Контакты\n			</div>\n			<div class="block-text">\n				                               г. Ростов-на-Дону,<br>\n				       ул. Текучева, 162, офис 302<br>\n				       тел. +7 (863) 280-66-56, <br>\n				       E-mail: rdo2009@mail.ru\n			</div>\n		</div>\n		<a href="/map" class="block-hover">\n		<div class="block-hv-text">\n			      На карте\n		</div>\n		</a>\n	</div>\n	<!-- <div class="index-block" style="visibility: hidden;"></div> -->\n</div>\n</section>', 1, 1, '2014-04-29 09:52:33', '2014-04-29 10:35:12'),
(2, 0, 15, 'default', 'ru', 'О компании', 'about', 'О компании', '', '', '', ' <main class="container about"><h1>О компании</h1>\n<a href="#" class="link-pdf">                 Скачать презентацию проекта             </a>\n<div class="content">\n	<div class="desc">\n		                       В России очень мало компаний: которые официально занимаются утилизацией                     и переработкой «темных нестандартных нефтепродуктов». Счет производств,                     которые профильно занимаются переработкой подобных нефтепродуктов                     и имеют лицензию на переработку идет на еденицы по всей стране.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                       Специалисты компании — инициатора проекта уже более 3-х лет занимаются исследованиями рынка «темных нестандартных нефтепродуктов», практической реализацией мелких проектов по переработке обводненного мазута.<br>\n			   В процессе накопленного практического опыта, глубокий анализ показал, что на Юге России нет ни одного официального производства по переработке вышеуказанных продуктов несмотря на то, что в России очень много предприятий, которые имеют потребность в заключении долгосрочных контрактов на утилизацию и переработку получаемых ими «темных нестандартных нефтепродуктов», но в силу отсутствия таковых, вынуждены утилизировать НТН, используя различные незаконные схемы сбыта, что влечет за собой огромные риски и снижение рентабельности.<br>\n			   Благодаря такому практическому опыту родилась идея создания <strong>универсального комплекса</strong> по переработке нестандартных темных нефтепродуктов.<br>\n		</div>\n	</div>\n	<h2>                     История                 </h2>\n</div>\n<ul class="hist-list">\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2012</a>\n		</div>\n		<h3>                             Зарегистрирована компания                         </h3>\n		<div class="hist-desc">\n			                                26.12.2012 в целях реализации возникшей идеи была зарегистрирована компания Общество с ограниченной ответственностью «Успенский перерабатывающий комплекс», которая в настоящий момент является инициатором проекта по строительству перерабатывающего комплекса.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img style="opacity: 1;" src="theme/img/icons/rocket.png"><a href="#">2014</a>\n		</div>\n		<h3>                             Официальный старт проекта                         </h3>\n		<div class="hist-desc">\n			                               В сентябре 2013 года проект официально стартовал, и начались первые шаги по реализации данного проекта.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/cert.png"><a href="#">2013</a>\n		</div>\n		<h3>                             Включение в реестр инвестиционных проектов Ростовской области                         </h3>\n		<div class="hist-desc">\n			                               7 Ноября 2013 года в Министерстве промышленности и энергетики Ростовской области состоялось совещание рабочей группы по вопросам развития инвестиционной деятельности. По результатам указанного совещания инвестиционный проект ООО «Успенский перерабатывающий комплекс» был успешно включен в реестр инвестиционных проектов Ростовской области, что позволяет в дальнейшем пользоваться системой государственно-частного партнёрства, предусматривающей обширные льготы.\n		</div>\n	</div>\n	</li>\n	<li class="hist-item">\n	<div class="hist-item-cont">\n		<div class="hist-date">\n			<img src="theme/img/icons/map.png"><a href="#">2014</a>\n		</div>\n		<h3>                             Предпроектные работы                         </h3>\n		<div class="hist-desc">\n			                               В настоящее время проект успешно находится в стадии реализации на этапе предпроектных работ и большими шагами движется к заданной цели.\n		</div>\n	</div>\n	</li>\n</ul></main>', 1, 0, '2014-04-29 10:39:11', '2014-04-29 10:55:21'),
(3, 0, 25, 'default', 'ru', 'Пресс-центр', 'news', 'Пресс-центр', '', '', '', '<main class="container news">\n<h1>Новости</h1>\n [news limit="1"] </main>', 1, 0, '2014-04-29 10:41:30', '2014-04-29 11:23:59'),
(4, 0, 17, 'default', 'ru', 'Услуги', 'services', 'Услуги', '', '', '', ' <main class="container services"><h1>Услуги</h1>\n<div class="content">\n	<div class="desc">\n		                     Настоящий проект предполагает производство следующих                     продуктов и оказание услуг\n	</div>\n	<div>\n		<div class="col-50">\n			<h2>Производство</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Битум</li>\n				<li>Бензин прямогонный</li>\n				<li>Судовое маловязкое топливо</li>\n				<li>Мазут</li>\n				<li>Керосин</li>\n			</ul>\n		</div>\n		<div class="col-50">\n			<h2>Услуги</h2>\n			<ul class="list-unstyled typical-list">\n				<li>Перевалка газа</li>\n				<li>Перевалка битума</li>\n				<li>Перевалка мазута</li>\n				<li>Обезжиривание мазута</li>\n				<li>Фильтрация мазута</li>\n				<li>Понижение вязкости и застывания мазута</li>\n				<li>Переработка нефти</li>\n			</ul>\n		</div>\n	</div>\n</div></main>', 1, 0, '2014-04-29 10:44:31', '2014-04-29 10:56:31'),
(6, 0, 19, 'default', 'ru', 'Карьера', 'career', 'Карьера', '', '', '', '<main class="container services">\n            <h1>\n                Карьера\n            </h1>\n            <div class="content">\n                <div class="desc">\n                    Уважаемые соискатели!\n                </div>\n                <div class="more-desc">\n                    <div class="more-desc-part">\n                    <p>Проведение работ по отбору кандидатов на замещение вакантных должностей в ООО «УПК» будет проводиться в 3 квартале 2014 года.\nЗа информацией о списках рабочих мест и количестве необходимых сотрудников, следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.</p>\n                    </div>\n                </div>\n                </div>\n            </div>\n            \n        </main>', 1, 0, '2014-04-29 11:04:34', '2014-04-29 11:04:34'),
(5, 0, 18, 'default', 'ru', 'Инвесторам', 'investors', 'Инвесторам', '', '', '', ' <main class="container investors"><h1>Инвесторам</h1>\n<div class="content">\n	<div class="desc">\n		  Предлагаем Вам принять участие в реализации инвестиционного проекта «Успенский перерабатывающий комплекс». Целью создания комплекса является организация многопрофильного производства по переработке нефти и нестандартных  темных нефтепродуктов, а также оказание большого спектра услуг в нефтяной сфере.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			  Для организации финансирования  и управления размещением сертификатов участия на рынке капитала наша компания заключила контракт со швейцарской компанией <a href="http://ifm-ag.ch/" target="_blank">IFM AG</a>. По возникшим вопросам, касающимся размещения сертификатов участия, просим обращаться в данную компанию.\n		</div>\n		<div class="more-desc-part">\n			  Для реализации проекта ООО «Успенский перерабатывающий комплекс» выпускает привилегированные сертификаты участия. Принятие участия представляет собой приобретение вышеуказанных сертификатов. Подробные условия изложены в эмиссионном проспекте. Для ознакомления введите логин и пароль.\n		</div>\n		<div class="more-desc-part">\n			 Чтобы получить доступ к загрузке эмисионного проспекта, <a href="#">отправьте запрос.</a>\n		</div>\n	</div>\n	<form class="auth-form">\n		<div class="form-header">\n			 Авторизация\n		</div>\n		<input placeholder="логин" type="text"><input placeholder="пароль" type="text"><button type="submit">Войти</button>\n	</form>\n</div></main>', 1, 0, '2014-04-29 10:45:30', '2014-04-29 10:56:58'),
(7, 0, 20, 'default', 'ru', 'Тендеры', 'tenders', 'Тендеры', '', '', '', '<main class="container services tenders">\n<h1>                 Тендеры             </h1>\n<div class="content">\n	<div class="desc">\n		                     Размещение информации  о работах, товарах и услугах, а также предварительному отбору поставщиков  товаров, услуг и подрядчиков, ООО «Успенский перерабатывающий комплекс» планирует  в конце 2 квартала 2014 года.\n	</div>\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                     За информацией следите на нашем сайте в разделе <a class="typical-link" href="/news">«новости»</a>.<br>\n		</div>\n	</div>\n</div>\n</main>', 1, 0, '2014-04-29 11:07:18', '2014-04-29 11:07:18'),
(8, 0, 21, 'default', 'ru', 'Контакты', 'contacts', 'Контакты', '', '', '', '<main class="container services tenders">\n<h1>                 Контакты             </h1>\n<div class="content">\n	<div class="more-desc">\n		<div class="more-desc-part">\n			                         Россия, Ростовская область, пос. Успенский,                         ул. Красных зорь, 123А\n		</div>\n	</div>\n	<address>\n	<div>\n		<a href="tel:+79283455454">+7 928 345 54 54</a>\n	</div>\n	<div>\n		<a href="mailto:email@gmail.com">email@gmail.com</a>\n	</div>\n	<div>\n		<a href="tel:+79283455455">+7 928 345 54 55</a>\n	</div>\n	</address>\n</div>\n</main>', 1, 0, '2014-04-29 11:08:20', '2014-04-29 11:08:20'),
(9, 0, 23, 'default', 'ru', 'Карта сайта', 'map', 'Карта сайта', '', '', '', '<main class="container services tenders">\n<h1>Карта сайта</h1>\n</main>', 1, 0, '2014-04-29 11:09:32', '2014-04-29 11:10:30');

-- --------------------------------------------------------

--
-- Структура таблицы `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `desc`, `default`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Создание', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'edit', 'Редактирование', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'delete', 'Удаление', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'publication', 'Публикация', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'download', 'Загрузка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'sort', 'Сортировка', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catalog_id` int(10) unsigned NOT NULL DEFAULT '0',
  `category_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `products_user_id_index` (`user_id`),
  KEY `products_catalog_id_index` (`catalog_id`),
  KEY `products_category_group_id_index` (`category_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes`
--

DROP TABLE IF EXISTS `products_attributes`;
CREATE TABLE IF NOT EXISTS `products_attributes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT '0',
  `product_attribute_group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `products_attributes_product_attribute_group_id_index` (`product_attribute_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `products_attributes_group`
--

DROP TABLE IF EXISTS `products_attributes_group`;
CREATE TABLE IF NOT EXISTS `products_attributes_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'news', 'Управление новостими', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'articles', 'Управление статьями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'pages', 'Управление страницами', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'catalogs', 'Управление каталогами товаров', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'users', 'Управление пользователями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'downloads', 'Управление загрузками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'statistic', 'Управление статистикой', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'galleries', 'Управление галереями', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(9, 'languages', 'Управление языками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(10, 'settings', 'Управление настройками', '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(11, 'templates', 'Управление шаблонами', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('5ce7ae628ed7f4124d442066809560b7ee131197', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoibGlWMU4zWGxsNXF1N0wwMGJPUE5qejNKUWdOa1Y2eThtUlpRUmUxRSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7aToxO3M6OToiX3NmMl9tZXRhIjthOjM6e3M6MToidSI7aToxMzk4Nzg3MDg2O3M6MToiYyI7aToxMzk4Nzc4OTk1O3M6MToibCI7czoxOiIwIjt9fQ==', 1398787086);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-04-29 09:43:10', '2014-04-29 09:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `templates`
--

DROP TABLE IF EXISTS `templates`;
CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `static` tinyint(1) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `templates`
--

INSERT INTO `templates` (`id`, `name`, `content`, `static`, `created_at`, `updated_at`) VALUES
(1, 'default', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(2, 'catalog', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(3, 'news', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(4, 'articles', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(5, 'category', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(6, 'product', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(7, 'manufacturer', '', 1, '2014-04-29 09:43:10', '2014-04-29 09:43:10'),
(8, 'index-page', '<!DOCTYPE html>\n<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->\n<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->\n<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->\n<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->\n <head>\n	@include(''templates.default.head'')\n	@yield(''style'')\n</head>\n<body>\n	<!--[if lt IE 7]>\n		<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>\n	<![endif]-->\n	@include(''templates.default.header'')\n	<main class="row content max-width-class" role="main">\n		@include(''templates.default.sidebar'')\n		<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10">\n			@yield(''content'')\n			@if(isset($content))\n				{{ $content }}\n			@endif\n		</div>\n	</main>\n	@include(''templates.default.footer'')\n	@include(''templates.default.scripts'')\n	@yield(''scripts'')\n</body>\n</html>', 0, '2014-04-29 09:45:45', '2014-04-29 09:45:59');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Администратор', '', 'admin@upk.ru', 1, '$2y$10$.3UP6AGgBfYWy1PIvwI3TugcGi5RBTn8l03ToQzvOe5K3Q/OEUVd2', 'img/avatars/male.png', 'img/avatars/male.png', '', 0, 'NYrpGYyVAxkQHOCxrAnDmt5JkPDPdUveLxinJB0wSYLGRA6gyg0y7A1IFPC3', '2014-04-29 09:43:10', '2014-04-29 09:43:25');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
